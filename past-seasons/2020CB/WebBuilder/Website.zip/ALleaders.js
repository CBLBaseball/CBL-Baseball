leaderName0 = new Array( "W.Merrifield", "A.Verdugo", "J.Davis", "X.Bogaerts", "K.Marte", "M.Cabrera", "M.Olson", "L.Arraez", "N.Cruz", "Y.Gurriel" );
leaderTeam0 = new Array( "KCA", "BAA", "CLA", "BOA", "SEA", "DEA", "OAA", "MNA", "NYA", "NYA" );
leaderData0 = new Array( ".350", ".346", ".346", ".345", ".342", ".337", ".326", ".318", ".305", ".304" );

leaderName1 = new Array( "F.Lindor", "R.Devers", "A.Garcia", "C.Biggio", "F.Galvis", "M.Brantley", "E.Rosario", "J.Abreu", "N.Castellanos", "Y.Puig" );
leaderTeam1 = new Array( "CLA", "BOA", "BAA", "TOA", "MNA", "CLA", "MNA", "CHA", "DEA", "CLA" );
leaderData1 = new Array( "134", "133", "127", "125", "124", "123", "123", "122", "121", "120" );

leaderName2 = new Array( "K.Marte", "A.Garcia", "M.Betts", "F.Lindor", "N.Cruz", "M.Trout", "G.Torres", "X.Bogaerts", "M.Brantley", "T.Hernandez" );
leaderTeam2 = new Array( "SEA", "BAA", "BOA", "CLA", "NYA", "DEA", "NYA", "BOA", "CLA", "TOA" );
leaderData2 = new Array( "30", "26", "25", "23", "23", "22", "22", "21", "21", "21" );

leaderName3 = new Array( "W.Merrifield", "X.Bogaerts", "K.Marte", "F.Lindor", "R.Devers", "A.Garcia", "M.Brantley", "A.Verdugo", "J.Davis", "T.Mancini" );
leaderTeam3 = new Array( "KCA", "BOA", "SEA", "CLA", "BOA", "BAA", "CLA", "BAA", "CLA", "BAA" );
leaderData3 = new Array( "42", "41", "41", "40", "38", "37", "37", "36", "36", "35" );

leaderName4 = new Array( "M.Brantley", "W.Merrifield", "J.Polanco", "M.Kepler", "F.Lindor", "N.Castellanos", "Y.Gurriel", "K.Marte", "L.Arraez", "T.Mancini" );
leaderTeam4 = new Array( "CLA", "KCA", "SEA", "SEA", "CLA", "DEA", "NYA", "SEA", "MNA", "BAA" );
leaderData4 = new Array( "12", "12", "12", "12", "11", "11", "11", "11", "9", "8" );

leaderName5 = new Array( "H.Ramirez", "V.Reyes", "H.Castro", "E.Escobar", "A.Meadows", "A.Benintendi", "F.Mejia", "A.Rizzo", "S.Ohtani", "D.Santana" );
leaderTeam5 = new Array( "BOA", "DEA", "DEA", "LAA", "TOA", "BOA", "CLA", "KCA", "LAA", "LAA" );
leaderData5 = new Array( "4", "3", "3", "3", "3", "2", "2", "2", "2", "2" );

leaderName6 = new Array( "M.Olson", "D.Santana", "G.Torres", "T.Hernandez", "K.Marte", "A.Garcia", "S.Ohtani", "M.Garver", "N.Cruz", "A.Santander" );
leaderTeam6 = new Array( "OAA", "LAA", "NYA", "TOA", "SEA", "BAA", "LAA", "MNA", "NYA", "BAA" );
leaderData6 = new Array( "14", "13", "12", "12", "11", "10", "10", "10", "10", "9" );

leaderName7 = new Array( "G.Torres", "K.Marte", "X.Bogaerts", "T.Mancini", "D.Santana", "N.Cruz", "R.Devers", "S.Ohtani", "M.Olson", "A.Meadows" );
leaderTeam7 = new Array( "NYA", "SEA", "BOA", "BAA", "LAA", "NYA", "BOA", "LAA", "OAA", "TOA" );
leaderData7 = new Array( "36", "31", "29", "24", "24", "24", "23", "23", "23", "23" );

leaderName8 = new Array( "M.Trout", "Y.Alvarez", "M.Betts", "P.Goldschmidt", "X.Bogaerts", "J.Smoak", "M.Kepler", "M.Garver", "M.Freeman", "C.Biggio" );
leaderTeam8 = new Array( "DEA", "BAA", "BOA", "OAA", "BOA", "TOA", "SEA", "MNA", "OAA", "TOA" );
leaderData8 = new Array( "28", "24", "22", "22", "20", "20", "18", "17", "16", "16" );

leaderName9 = new Array( "M.Trout", "Y.Alvarez", "H.Ramirez", "E.Rosario", "M.Garver", "J.Martinez", "D.Solano", "R.Devers", "X.Bogaerts", "K.Kiermaier" );
leaderTeam9 = new Array( "DEA", "BAA", "BOA", "MNA", "MNA", "NYA", "NYA", "BOA", "BOA", "CHA" );
leaderData9 = new Array( "4", "3", "3", "3", "3", "3", "3", "2", "2", "2" );

leaderName10 = new Array( "M.Adams", "G.Sanchez", "R.Grichuk", "T.Hernandez", "C.Biggio", "N.Castellanos", "P.Goldschmidt", "P.Dejong", "Y.Puig", "B.Lowe" );
leaderTeam10 = new Array( "MNA", "NYA", "MNA", "TOA", "TOA", "DEA", "OAA", "BAA", "CLA", "MNA" );
leaderData10 = new Array( "49", "41", "40", "37", "35", "34", "34", "33", "33", "33" );

leaderName11 = new Array( "A.Rizzo", "T.Frazier", "T.Mancini", "R.Braun", "J.Abreu", "M.Brantley", "G.Springer", "R.Laureano", "M.Olson", "T.Locastro" );
leaderTeam11 = new Array( "KCA", "MNA", "BAA", "CHA", "CHA", "CLA", "NYA", "OAA", "OAA", "OAA" );
leaderData11 = new Array( "11", "5", "4", "4", "4", "4", "4", "4", "4", "4" );

leaderName12 = new Array( "N.Lopez", "R.Perez", "O.Arcia", "J.Kipnis", "A.Gordon", "A.Rizzo", "N.Ahmed", "A.Nola", "C.Vazquez", "M.Brantley" );
leaderTeam12 = new Array( "KCA", "KCA", "KCA", "CLA", "KCA", "KCA", "LAA", "SEA", "BOA", "CLA" );
leaderData12 = new Array( "7", "5", "5", "3", "3", "2", "2", "2", "1", "1" );

leaderName13 = new Array( "B.Buxton", "T.Locastro", "F.Lindor", "L.Cain", "A.Garcia", "A.Benintendi", "J.Wendle", "D.Gordon", "K.Hiura", "M.Betts" );
leaderTeam13 = new Array( "MNA", "OAA", "CLA", "KCA", "BAA", "BOA", "DEA", "OAA", "BAA", "BOA" );
leaderData13 = new Array( "8", "7", "6", "6", "4", "4", "4", "4", "3", "3" );

leaderName14 = new Array( "A.Garcia", "A.Benintendi", "F.Lindor", "B.Buxton", "D.Gordon", "T.Locastro", "L.Cain", "T.Anderson", "V.Reyes", "J.Iglesias" );
leaderTeam14 = new Array( "BAA", "BOA", "CLA", "MNA", "OAA", "OAA", "KCA", "CHA", "DEA", "DEA" );
leaderData14 = new Array( "1.00", "1.00", "1.00", "1.00", "1.00", ".88", ".86", ".75", ".75", ".75" );

leaderName15 = new Array( "R.Grichuk", "T.Mancini", "J.Abreu", "A.Santander", "J.Altuve", "F.Lindor", "O.Mercado", "S.Ohtani", "K.Calhoun", "M.Chapman" );
leaderTeam15 = new Array( "MNA", "BAA", "CHA", "BAA", "CHA", "CLA", "CLA", "LAA", "LAA", "OAA" );
leaderData15 = new Array( "8", "6", "6", "5", "5", "5", "5", "5", "5", "5" );

leaderName16 = new Array( "A.Santander", "A.Garcia", "T.Mancini", "R.Nunez", "C.Kelly", "K.Hiura", "F.Mejia", "M.Adams", "G.Torres", "G.Urshela" );
leaderTeam16 = new Array( "BAA", "BAA", "BAA", "BAA", "BAA", "BAA", "CLA", "MNA", "NYA", "NYA" );
leaderData16 = new Array( "8", "6", "5", "3", "3", "3", "3", "3", "3", "3" );

leaderName17 = new Array( "J.Luplow", "C.Maybin", "M.Brosseau", "A.Romine", "D.Dietrich", "H.Castro", "M.Sano", "M.Canha", "R.O'Hearn", "C.Cron" );
leaderTeam17 = new Array( "CLA", "LAA", "DEA", "LAA", "CHA", "DEA", "MNA", "CLA", "KCA", "LAA" );
leaderData17 = new Array( ".750", ".571", ".500", ".500", ".429", ".400", ".400", ".250", ".250", ".250" );

leaderName18 = new Array( "M.Olson", "K.Marte", "G.Torres", "D.Santana", "N.Cruz", "T.Hernandez", "S.Ohtani", "X.Bogaerts", "M.Trout", "M.Cabrera" );
leaderTeam18 = new Array( "OAA", "SEA", "NYA", "LAA", "NYA", "TOA", "LAA", "BOA", "DEA", "DEA" );
leaderData18 = new Array( ".848", ".708", ".708", ".690", ".663", ".642", ".621", ".597", ".582", ".570" );

leaderName19 = new Array( "Y.Alvarez", "X.Bogaerts", "M.Trout", "M.Olson", "P.Goldschmidt", "M.Cabrera", "K.Marte", "M.Betts", "W.Merrifield", "J.Polanco" );
leaderTeam19 = new Array( "BAA", "BOA", "DEA", "OAA", "OAA", "DEA", "SEA", "BOA", "KCA", "SEA" );
leaderData19 = new Array( ".438", ".436", ".422", ".417", ".416", ".404", ".403", ".400", ".392", ".386" );

leaderName20 = new Array( "M.Olson", "X.Bogaerts", "K.Marte", "G.Torres", "M.Trout", "N.Cruz", "Y.Alvarez", "W.Merrifield", "P.Goldschmidt", "M.Betts" );
leaderTeam20 = new Array( "OAA", "BOA", "SEA", "NYA", "DEA", "NYA", "BAA", "KCA", "OAA", "BOA" );
leaderData20 = new Array( "12.6", "11.0", "11.0", "10.5", "10.1", " 8.8", " 8.7", " 8.4", " 8.4", " 8.2" );

leaderName21 = new Array( "M.Olson", "M.Trout", "G.Torres", "K.Marte", "X.Bogaerts", "Y.Alvarez", "N.Cruz", "D.Santana", "M.Betts", "P.Goldschmidt" );
leaderTeam21 = new Array( "OAA", "DEA", "NYA", "SEA", "BOA", "BAA", "NYA", "LAA", "BOA", "OAA" );
leaderData21 = new Array( "1.409", "1.219", "1.200", "1.195", "1.152", "1.076", "1.072", "1.034", "1.024", "1.000" );

leaderName22 = new Array( "K.Marte", "D.Santana", "M.Olson", "G.Torres", "S.Ohtani", "A.Garcia", "X.Bogaerts", "T.Hernandez", "W.Merrifield", "F.Lindor" );
leaderTeam22 = new Array( "SEA", "LAA", "OAA", "NYA", "LAA", "BAA", "BOA", "TOA", "KCA", "CLA" );
leaderData22 = new Array( "85", "78", "78", "75", "72", "71", "71", "70", "68", "66" );

leaderName23 = new Array( "M.Cabrera", "M.Garver", "N.Cruz", "L.Gurriel", "J.Abreu", "H.Alberto", "R.Perez", "R.Braun", "J.Martinez", "T.Frazier" );
leaderTeam23 = new Array( "DEA", "MNA", "NYA", "TOA", "CHA", "BAA", "KCA", "CHA", "CLA", "MNA" );
leaderData23 = new Array( ".480", ".450", ".414", ".382", ".378", ".372", ".370", ".368", ".368", ".368" );

leaderName24 = new Array( "N.Cruz", "J.Martinez", "C.Kelly", "M.Olson", "K.Marte", "A.Garcia", "M.Cabrera", "C.Cron", "M.Sano", "Y.Diaz" );
leaderTeam24 = new Array( "NYA", "NYA", "BAA", "OAA", "SEA", "BAA", "DEA", "LAA", "MNA", "SEA" );
leaderData24 = new Array( "8", "7", "5", "5", "5", "4", "4", "4", "4", "4" );

leaderName25 = new Array( "W.Merrifield", "K.Marte", "E.Jimenez", "G.Cooper", "M.Brantley", "X.Bogaerts", "S.Ohtani", "A.Verdugo", "F.Mejia", "V.Reyes" );
leaderTeam25 = new Array( "KCA", "SEA", "CHA", "CHA", "CLA", "BOA", "LAA", "BAA", "CLA", "DEA" );
leaderData25 = new Array( ".405", ".389", ".381", ".379", ".372", ".372", ".366", ".365", ".364", ".364" );

leaderName26 = new Array( "D.Santana", "T.Hernandez", "S.Ohtani", "G.Torres", "M.Olson", "E.Rosario", "F.Galvis", "M.Garver", "A.Santander", "A.Garcia" );
leaderTeam26 = new Array( "LAA", "TOA", "LAA", "NYA", "OAA", "MNA", "MNA", "MNA", "BAA", "BAA" );
leaderData26 = new Array( "12", "11", "9", "9", "9", "7", "7", "7", "6", "6" );

leaderName27 = new Array( "S.Bieber", "R.Yarbrough", "D.German", "M.Fiers", "W.Harris", "Z.Plesac", "M.Gonzales", "T.Glasnow", "J.Means", "S.Brault" );
leaderTeam27 = new Array( "CLA", "NYA", "NYA", "BOA", "BOA", "CLA", "SEA", "BAA", "BAA", "BOA" );
leaderData27 = new Array( "6", "5", "5", "4", "4", "4", "4", "3", "3", "3" );

leaderName28 = new Array( "D.Pomeranz", "J.Lester", "P.Lopez", "M.Pineda", "Y.Petit", "Y.Kikuchi", "J.Kelly", "N.Eovaldi", "L.Lynn", "C.Sale" );
leaderTeam28 = new Array( "TOA", "BOA", "CHA", "MNA", "OAA", "TOA", "BAA", "BOA", "CHA", "CHA" );
leaderData28 = new Array( "5", "4", "4", "4", "4", "4", "3", "3", "3", "3" );

leaderName29 = new Array( "J.Chacin", "S.Bieber", "J.Berrios", "D.German", "R.Yarbrough", "M.Gonzales", "T.Glasnow", "J.Means", "S.Brault", "S.Cishek" );
leaderTeam29 = new Array( "CLA", "CLA", "MNA", "NYA", "NYA", "SEA", "BAA", "BAA", "BOA", "CLA" );
leaderData29 = new Array( "1.000", "1.000", "1.000", "1.000", ".833", ".800", ".750", ".750", ".750", ".750" );

leaderName30 = new Array( "Z.Davies", "S.Bieber", "R.Yarbrough", "T.Skaggs", "D.German", "J.Berrios", "G.Canning", "S.Turnbull", "S.Gray", "S.Alcantara" );
leaderTeam30 = new Array( "SEA", "CLA", "NYA", "LAA", "NYA", "MNA", "LAA", "DEA", "OAA", "BAA" );
leaderData30 = new Array( " 1.51", " 1.88", " 2.01", " 2.43", " 2.47", " 2.50", " 2.59", " 2.70", " 3.06", " 3.09" );

leaderName31 = new Array( "R.Yarbrough", "L.Lynn", "T.Bauer", "M.Boyd", "E.Rodriguez", "S.Turnbull", "D.German", "C.McHugh", "D.Keuchel", "M.Gonzales" );
leaderTeam31 = new Array( "NYA", "CHA", "MNA", "DEA", "BOA", "DEA", "NYA", "CLA", "DEA", "SEA" );
leaderData31 = new Array( " 49.1", " 45.2", " 43.2", " 41.0", " 40.1", " 40.0", " 40.0", " 39.1", " 39.0", " 39.0" );

leaderName32 = new Array( "L.Lynn", "R.Yarbrough", "T.Bauer", "E.Rodriguez", "S.Turnbull", "M.Leake", "D.Keuchel", "C.McHugh", "R.Porcello", "Z.Greinke" );
leaderTeam32 = new Array( "CHA", "NYA", "MNA", "BOA", "DEA", "SEA", "DEA", "CLA", "DEA", "KCA" );
leaderData32 = new Array( "192", "187", "176", "174", "173", "172", "171", "169", "166", "164" );

leaderName33 = new Array( "L.Bard", "H.Hembree", "Y.Petit", "Z.Eflin", "N.Wittgren", "T.Duffey", "R.Pressly", "T.Rogers", "B.Parker", "T.Hill" );
leaderTeam33 = new Array( "LAA", "KCA", "OAA", "SEA", "CLA", "KCA", "LAA", "BOA", "CLA", "KCA" );
leaderData33 = new Array( "22", "17", "17", "17", "16", "16", "16", "15", "15", "15" );

leaderName34 = new Array( "M.Fiers", "J.Lester", "E.Rodriguez", "N.Eovaldi", "S.Brault", "P.Lopez", "T.Richards", "L.Lynn", "C.Sale", "R.Lopez" );
leaderTeam34 = new Array( "BOA", "BOA", "BOA", "BOA", "BOA", "CHA", "CHA", "CHA", "CHA", "CHA" );
leaderData34 = new Array( "6", "6", "6", "6", "6", "6", "6", "6", "6", "6" );

leaderName35 = new Array( "T.Bauer", "L.Lynn", "C.Sale", "C.McHugh", "B.Keller", "B.Woodruff", "M.Pineda", "R.Yarbrough", "I.Nova", "A.Sanchez" );
leaderTeam35 = new Array( "MNA", "CHA", "CHA", "CLA", "KCA", "MNA", "MNA", "NYA", "NYA", "TOA" );
leaderData35 = new Array( "4", "2", "1", "1", "1", "1", "1", "1", "1", "1" );

leaderName36 = new Array( "T.Rogers", "N.Wittgren", "F.Vazquez", "L.Hendriks", "Z.Eflin", "A.Colome", "M.Givens", "H.Robles", "K.Giles", "J.Beeks" );
leaderTeam36 = new Array( "BOA", "CLA", "LAA", "OAA", "SEA", "CHA", "BAA", "KCA", "NYA", "BAA" );
leaderData36 = new Array( "15", "15", "11", "11", "11", "10", "9", "8", "8", "7" );

leaderName37 = new Array( "F.Vazquez", "L.Hendriks", "A.Colome", "N.Wittgren", "K.Giles", "T.Rogers", "M.Givens", "H.Robles", "B.Hand", "L.Jackson" );
leaderTeam37 = new Array( "LAA", "OAA", "CHA", "CLA", "NYA", "BOA", "BAA", "KCA", "MNA", "TOA" );
leaderData37 = new Array( "9", "9", "8", "8", "7", "6", "5", "4", "4", "4" );

leaderName38 = new Array( "M.Givens", "L.Hendriks", "K.Giles", "T.Rogers", "F.Vazquez", "A.Colome", "N.Wittgren", "Z.Eflin", "T.May", "E.Pagan" );
leaderTeam38 = new Array( "BAA", "OAA", "NYA", "BOA", "LAA", "CHA", "CLA", "SEA", "DEA", "NYA" );
leaderData38 = new Array( "1.000", ".900", ".875", ".857", ".818", ".800", ".800", ".750", ".667", ".667" );

leaderName39 = new Array( "T.Bauer", "", "", "", "", "", "", "", "", "" );
leaderTeam39 = new Array( "MNA", "", "", "", "", "", "", "", "", "" );
leaderData39 = new Array( "1", "", "", "", "", "", "", "", "", "" );

leaderName40 = new Array( "M.Tanaka", "J.Lester", "M.Leake", "K.Gausman", "L.Lynn", "Z.Greinke", "I.Nova", "D.Keuchel", "E.Rodriguez", "R.Lopez" );
leaderTeam40 = new Array( "NYA", "BOA", "SEA", "BAA", "CHA", "KCA", "NYA", "DEA", "BOA", "CHA" );
leaderData40 = new Array( "51", "50", "48", "46", "46", "45", "45", "43", "41", "41" );

leaderName41 = new Array( "J.Lester", "B.Keller", "T.Thornton", "R.Lopez", "J.Lyles", "N.Eovaldi", "M.Wacha", "Y.Kikuchi", "C.McHugh", "I.Nova" );
leaderTeam41 = new Array( "BOA", "KCA", "TOA", "CHA", "DEA", "BOA", "DEA", "TOA", "CLA", "NYA" );
leaderData41 = new Array( "34", "32", "31", "29", "29", "28", "28", "28", "27", "27" );

leaderName42 = new Array( "J.Lester", "B.Keller", "T.Thornton", "R.Lopez", "C.McHugh", "N.Eovaldi", "D.Pomeranz", "S.Matz", "Y.Kikuchi", "D.Duffy" );
leaderTeam42 = new Array( "BOA", "KCA", "TOA", "CHA", "CLA", "BOA", "TOA", "TOA", "TOA", "KCA" );
leaderData42 = new Array( "33", "32", "29", "28", "27", "25", "25", "25", "25", "24" );

leaderName43 = new Array( "J.Lester", "B.Keller", "D.Pomeranz", "R.Lopez", "T.Cahill", "Z.Greinke", "D.Holland", "Y.Kikuchi", "D.Duffy", "A.Heaney" );
leaderTeam43 = new Array( "BOA", "KCA", "TOA", "CHA", "CLA", "KCA", "SEA", "TOA", "KCA", "LAA" );
leaderData43 = new Array( "12", "11", "11", "10", "10", "10", "10", "10", "9", "9" );

leaderName44 = new Array( "S.Brault", "C.Anderson", "B.Keller", "T.Bauer", "N.Eovaldi", "D.Keuchel", "I.Nova", "S.Turnbull", "D.Holland", "Y.Kikuchi" );
leaderTeam44 = new Array( "BOA", "LAA", "KCA", "MNA", "BOA", "DEA", "NYA", "DEA", "SEA", "TOA" );
leaderData44 = new Array( "23", "21", "20", "20", "19", "17", "17", "16", "16", "16" );

leaderName45 = new Array( "T.Bauer", "C.Sale", "M.Boyd", "S.Turnbull", "R.Yarbrough", "L.Lynn", "S.Bieber", "E.Rodriguez", "B.Woodruff", "D.German" );
leaderTeam45 = new Array( "MNA", "CHA", "DEA", "DEA", "NYA", "CHA", "CLA", "BOA", "MNA", "NYA" );
leaderData45 = new Array( "58", "53", "50", "48", "48", "47", "47", "43", "43", "43" );

leaderName46 = new Array( "N.Eovaldi", "S.Brault", "T.Cahill", "S.Bieber", "D.Keuchel", "M.Boyd", "T.Buttrey", "J.Leclerc", "J.Junis", "K.Gibson" );
leaderTeam46 = new Array( "BOA", "BOA", "CLA", "CLA", "DEA", "DEA", "TOA", "CLA", "KCA", "MNA" );
leaderData46 = new Array( "4", "4", "4", "4", "4", "4", "4", "3", "3", "3" );

leaderName47 = new Array( "B.Woodruff", "M.Castro", "R.Porcello", "T.Duffey", "L.Bard", "Y.Garcia", "D.Pomeranz", "A.Ottavino", "", "" );
leaderTeam47 = new Array( "MNA", "BAA", "DEA", "KCA", "LAA", "SEA", "TOA", "TOA", "", "" );
leaderData47 = new Array( "2", "1", "1", "1", "1", "1", "1", "1", "", "" );

leaderName48 = new Array( "J.Means", "E.Rodriguez", "S.Brault", "S.Bieber", "D.Keuchel", "R.Porcello", "M.Boyd", "S.Turnbull", "D.Duffy", "T.Skaggs" );
leaderTeam48 = new Array( "BAA", "BOA", "BOA", "CLA", "DEA", "DEA", "DEA", "DEA", "KCA", "LAA" );
leaderData48 = new Array( "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00" );

leaderName49 = new Array( "S.Turnbull", "T.Bauer", "L.Lynn", "T.Cahill", "A.Sanchez", "K.Gausman", "S.Brault", "R.Lopez", "L.Bard", "C.Bassitt" );
leaderTeam49 = new Array( "DEA", "MNA", "CHA", "CLA", "TOA", "BAA", "BOA", "CHA", "LAA", "OAA" );
leaderData49 = new Array( "7", "6", "5", "5", "5", "4", "4", "4", "4", "3" );

leaderName50 = new Array( "S.Bieber", "C.Anderson", "T.Bauer", "C.Bassitt", "R.Lopez", "L.Lynn", "A.Sanchez", "S.Turnbull", "K.Gausman", "S.Brault" );
leaderTeam50 = new Array( "CLA", "LAA", "MNA", "OAA", "CHA", "CHA", "TOA", "DEA", "BAA", "BOA" );
leaderData50 = new Array( ".50", ".50", ".60", ".75", ".80", ".83", ".83", ".88", "1.00", "1.00" );

leaderName51 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderTeam51 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderData51 = new Array( "", "", "", "", "", "", "", "", "", "" );

leaderName52 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderTeam52 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderData52 = new Array( "", "", "", "", "", "", "", "", "", "" );

leaderName53 = new Array( "G.Canning", "M.Minor", "J.Berrios", "C.Bassitt", "M.Boyd", "R.Yarbrough", "T.Bauer", "D.German", "Z.Davies", "M.Gonzales" );
leaderTeam53 = new Array( "LAA", "KCA", "MNA", "OAA", "DEA", "NYA", "MNA", "NYA", "SEA", "SEA" );
leaderData53 = new Array( " 4.6", " 5.9", " 6.0", " 6.1", " 6.4", " 6.4", " 6.4", " 6.5", " 6.6", " 6.9" );

leaderName54 = new Array( "M.Fiers", "J.Berrios", "R.Yarbrough", "B.Woodruff", "C.Quantrill", "S.Bieber", "T.Milone", "S.Alcantara", "Z.Greinke", "J.Musgrove" );
leaderTeam54 = new Array( "BOA", "MNA", "NYA", "MNA", "OAA", "CLA", "OAA", "BAA", "KCA", "SEA" );
leaderData54 = new Array( " 1.2", " 1.3", " 1.3", " 1.3", " 1.4", " 1.4", " 1.7", " 1.8", " 1.9", " 1.9" );

leaderName55 = new Array( "C.Sale", "T.Bauer", "B.Woodruff", "S.Bieber", "M.Boyd", "S.Turnbull", "L.Giolito", "G.Canning", "S.Gray", "S.Matz" );
leaderTeam55 = new Array( "CHA", "MNA", "MNA", "CLA", "DEA", "DEA", "LAA", "LAA", "OAA", "TOA" );
leaderData55 = new Array( "12.6", "12.0", "11.5", "11.0", "11.0", "10.8", "10.7", "10.3", "10.3", "10.0" );

leaderName56 = new Array( "Z.Davies", "B.Anderson", "T.Skaggs", "G.Canning", "C.Anderson", "D.German", "R.Yarbrough", "T.Bauer", "E.Rodriguez", "S.Bieber" );
leaderTeam56 = new Array( "SEA", "OAA", "LAA", "LAA", "LAA", "NYA", "NYA", "MNA", "BOA", "CLA" );
leaderData56 = new Array( " 0.25", " 0.52", " 0.54", " 0.57", " 0.59", " 0.68", " 0.73", " 0.82", " 0.89", " 0.94" );

