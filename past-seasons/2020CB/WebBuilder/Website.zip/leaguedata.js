sub = new Array( "AL", "NL" );
sublong = new Array( "American League", "National League" );

AL = new Array( "ALEast", "ALCentral", "ALWest" );
NL = new Array( "NLEast", "NLCentral", "NLWest" );

ALALEast = new Array( "BAA", "BOA", "NYA", "TOA" );

BAA = new Array("ALEast", "Baltimore", "Orioles", "Baltimore Orioles (BAA)", "2020", "30", "16", "14", ".533", ".467", ".600" );
BOA = new Array("ALEast", "Boston", "Red Sox", "Boston Red Sox (BOA)", "2020", "30", "15", "15", ".500", ".467", ".533" );
NYA = new Array("ALEast", "New York (AL)", "Yankees", "New York (AL) Yankees (NYA)", "2020", "30", "23", "7", ".767", ".867", ".667" );
TOA = new Array("ALEast", "Toronto", "Blue Jays", "Toronto Blue Jays (TOA)", "2020", "30", "9", "21", ".300", ".333", ".267" );
ALALCentral = new Array( "CHA", "CLA", "DEA", "MNA" );

CHA = new Array("ALCentral", "Chicago (AL)", "White Sox", "Chicago (AL) White Sox (CHA)", "2020", "30", "14", "16", ".467", ".533", ".400" );
CLA = new Array("ALCentral", "Cleveland", "Indians", "Cleveland Indians (CLA)", "2020", "30", "20", "10", ".667", ".667", ".667" );
DEA = new Array("ALCentral", "Detroit", "Tigers", "Detroit Tigers (DEA)", "2020", "30", "10", "20", ".333", ".267", ".400" );
MNA = new Array("ALCentral", "Minnesota", "Twins", "Minnesota Twins (MNA)", "2020", "30", "11", "19", ".367", ".467", ".267" );
ALALWest = new Array( "KCA", "LAA", "OAA", "SEA" );

KCA = new Array("ALWest", "Kansas City", "Royals", "Kansas City Royals (KCA)", "2020", "30", "12", "18", ".400", ".467", ".333" );
LAA = new Array("ALWest", "Los Angeles(AL)", "Angels", "Los Angeles(AL) Angels (LAA)", "2020", "30", "17", "13", ".567", ".600", ".533" );
OAA = new Array("ALWest", "Oakland", "Athletics", "Oakland Athletics (OAA)", "2020", "30", "15", "15", ".500", ".600", ".400" );
SEA = new Array("ALWest", "Seattle", "Mariners", "Seattle Mariners (SEA)", "2020", "30", "18", "12", ".600", ".400", ".800" );
NLNLEast = new Array( "ATN", "NYN", "PHN", "WAN" );

ATN = new Array("NLEast", "Atlanta", "Braves", "Atlanta Braves (ATN)", "2020", "30", "20", "10", ".667", ".467", ".867" );
NYN = new Array("NLEast", "New York (NL)", "Mets", "New York (NL) Mets (NYN)", "2020", "30", "21", "9", ".700", ".733", ".667" );
PHN = new Array("NLEast", "Philadelphia", "Phillies", "Philadelphia Phillies (PHN)", "2020", "30", "11", "19", ".367", ".333", ".400" );
WAN = new Array("NLEast", "Washington", "Nationals", "Washington Nationals (WAN)", "2020", "30", "14", "16", ".467", ".467", ".467" );
NLNLCentral = new Array( "CHN", "CIN", "PIN", "SLN" );

CHN = new Array("NLCentral", "Chicago (NL)", "Cubs", "Chicago (NL) Cubs (CHN)", "2020", "30", "15", "15", ".500", ".600", ".400" );
CIN = new Array("NLCentral", "Cincinnati", "Reds", "Cincinnati Reds (CIN)", "2020", "30", "17", "13", ".567", ".600", ".533" );
PIN = new Array("NLCentral", "Pittsburgh", "Pirates", "Pittsburgh Pirates (PIN)", "2020", "30", "11", "19", ".367", ".267", ".467" );
SLN = new Array("NLCentral", "St. Louis", "Cardinals", "St. Louis Cardinals (SLN)", "2020", "30", "6", "24", ".200", ".200", ".200" );
NLNLWest = new Array( "CON", "LAN", "SDN", "SFN" );

CON = new Array("NLWest", "Colorado", "Rockies", "Colorado Rockies (CON)", "2020", "30", "17", "13", ".567", ".467", ".667" );
LAN = new Array("NLWest", "Los Angeles(NL)", "Dodgers", "Los Angeles(NL) Dodgers (LAN)", "2020", "30", "19", "11", ".633", ".600", ".667" );
SDN = new Array("NLWest", "San Diego", "Padres", "San Diego Padres (SDN)", "2020", "30", "11", "19", ".367", ".400", ".333" );
SFN = new Array("NLWest", "San Francisco", "Giants", "San Francisco Giants (SFN)", "2020", "30", "18", "12", ".600", ".467", ".733" );
