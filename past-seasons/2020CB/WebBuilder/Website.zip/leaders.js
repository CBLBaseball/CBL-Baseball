leaderName0 = new Array( "Y.Moncada", "W.Merrifield", "A.Verdugo", "J.Davis", "X.Bogaerts", "N.Arenado", "K.Marte", "R.Tapia", "M.Cabrera", "A.Bregman" );
leaderTeam0 = new Array( "SDN", "KCA", "BAA", "CLA", "BOA", "CON", "SEA", "CHN", "DEA", "CIN" );
leaderData0 = new Array( ".379", ".350", ".346", ".346", ".345", ".342", ".342", ".339", ".337", ".333" );

leaderName1 = new Array( "F.Lindor", "R.Devers", "D.Lemahieu", "A.Garcia", "D.Dahl", "C.Bellinger", "A.Rosario", "C.Biggio", "J.Baez", "F.Galvis" );
leaderTeam1 = new Array( "CLA", "BOA", "CON", "BAA", "CON", "LAN", "NYN", "TOA", "CHN", "MNA" );
leaderData1 = new Array( "134", "133", "132", "127", "127", "127", "127", "125", "124", "124" );

leaderName2 = new Array( "F.Freeman", "K.Marte", "P.Alonso", "A.Garcia", "D.Lemahieu", "M.Betts", "C.Blackmon", "A.Bregman", "J.Donaldson", "C.Yelich" );
leaderTeam2 = new Array( "ATN", "SEA", "NYN", "BAA", "CON", "BOA", "ATN", "CIN", "WAN", "ATN" );
leaderData2 = new Array( "32", "30", "28", "26", "26", "25", "24", "24", "24", "23" );

leaderName3 = new Array( "Y.Moncada", "D.Lemahieu", "W.Merrifield", "X.Bogaerts", "R.Tapia", "N.Arenado", "K.Marte", "F.Lindor", "D.Dahl", "R.Devers" );
leaderTeam3 = new Array( "SDN", "CON", "KCA", "BOA", "CHN", "CON", "SEA", "CLA", "CON", "BOA" );
leaderData3 = new Array( "44", "43", "42", "41", "41", "41", "41", "40", "39", "38" );

leaderName4 = new Array( "R.Tapia", "D.Swanson", "M.Brantley", "W.Merrifield", "J.McNeil", "J.Polanco", "M.Kepler", "F.Lindor", "N.Castellanos", "Y.Gurriel" );
leaderTeam4 = new Array( "CHN", "ATN", "CLA", "KCA", "NYN", "SEA", "SEA", "CLA", "DEA", "NYA" );
leaderData4 = new Array( "17", "12", "12", "12", "12", "12", "12", "11", "11", "11" );

leaderName5 = new Array( "H.Ramirez", "J.Realmuto", "V.Reyes", "H.Castro", "E.Escobar", "F.Tatis Jr", "A.Meadows", "A.Benintendi", "R.Tapia", "F.Mejia" );
leaderTeam5 = new Array( "BOA", "ATN", "DEA", "DEA", "LAA", "SDN", "TOA", "BOA", "CHN", "CLA" );
leaderData5 = new Array( "4", "3", "3", "3", "3", "3", "3", "2", "2", "2" );

leaderName6 = new Array( "M.Olson", "D.Santana", "E.Encarnacion", "G.Torres", "T.Hernandez", "N.Arenado", "J.Bell", "K.Marte", "A.Garcia", "R.Odor" );
leaderTeam6 = new Array( "OAA", "LAA", "LAN", "NYA", "TOA", "CON", "PIN", "SEA", "BAA", "CIN" );
leaderData6 = new Array( "14", "13", "13", "12", "12", "11", "11", "11", "10", "10" );

leaderName7 = new Array( "G.Torres", "K.Marte", "C.Blackmon", "X.Bogaerts", "J.Bell", "C.Bellinger", "J.Donaldson", "J.Realmuto", "N.Arenado", "J.McNeil" );
leaderTeam7 = new Array( "NYA", "SEA", "ATN", "BOA", "PIN", "LAN", "WAN", "ATN", "CON", "NYN" );
leaderData7 = new Array( "36", "31", "30", "29", "29", "26", "26", "25", "25", "25" );

leaderName8 = new Array( "F.Freeman", "M.Trout", "B.Harper", "J.Donaldson", "Y.Alvarez", "M.Betts", "C.Santana", "P.Goldschmidt", "C.Yelich", "O.Albies" );
leaderTeam8 = new Array( "ATN", "DEA", "WAN", "WAN", "BAA", "BOA", "NYN", "OAA", "ATN", "ATN" );
leaderData8 = new Array( "28", "28", "28", "27", "24", "22", "22", "22", "21", "20" );

leaderName9 = new Array( "F.Freeman", "C.Blackmon", "M.Trout", "A.Rendon", "Y.Alvarez", "H.Ramirez", "N.Arenado", "A.Hechavarria", "E.Rosario", "M.Garver" );
leaderTeam9 = new Array( "ATN", "ATN", "DEA", "SFN", "BAA", "BOA", "CON", "LAN", "MNA", "MNA" );
leaderData9 = new Array( "4", "4", "4", "4", "3", "3", "3", "3", "3", "3" );

leaderName10 = new Array( "M.Adams", "J.Soler", "D.Dahl", "E.Suarez", "G.Sanchez", "R.Odor", "R.Grichuk", "P.Alonso", "T.Story", "T.Hernandez" );
leaderTeam10 = new Array( "MNA", "CIN", "CON", "CIN", "NYA", "CIN", "MNA", "NYN", "CON", "TOA" );
leaderData10 = new Array( "49", "46", "45", "41", "41", "40", "40", "40", "39", "37" );

leaderName11 = new Array( "A.Rizzo", "J.Turner", "T.Frazier", "V.Robles", "B.Anderson", "T.Mancini", "R.Braun", "J.Abreu", "K.Bryant", "J.Cave" );
leaderTeam11 = new Array( "KCA", "LAN", "MNA", "SDN", "SDN", "BAA", "CHA", "CHA", "CHN", "CHN" );
leaderData11 = new Array( "11", "5", "5", "5", "5", "4", "4", "4", "4", "4" );

leaderName12 = new Array( "N.Lopez", "R.Perez", "O.Arcia", "J.Kipnis", "A.Gordon", "B.Drury", "C.Cuthbert", "A.Frazier", "D.Deshields", "A.Rizzo" );
leaderTeam12 = new Array( "KCA", "KCA", "KCA", "CLA", "KCA", "PHN", "PHN", "PIN", "WAN", "KCA" );
leaderData12 = new Array( "7", "5", "5", "3", "3", "3", "3", "3", "3", "2" );

leaderName13 = new Array( "R.Acuna", "J.Villar", "B.Buxton", "T.Locastro", "J.Heyward", "F.Lindor", "L.Cain", "R.Tapia", "O.Albies", "A.Garcia" );
leaderTeam13 = new Array( "ATN", "SFN", "MNA", "OAA", "CHN", "CLA", "KCA", "CHN", "ATN", "BAA" );
leaderData13 = new Array( "12", "9", "8", "7", "6", "6", "6", "5", "4", "4" );

leaderName14 = new Array( "O.Albies", "R.Acuna", "A.Garcia", "A.Benintendi", "J.Heyward", "F.Lindor", "B.Buxton", "D.Gordon", "S.Kingery", "Y.Moncada" );
leaderTeam14 = new Array( "ATN", "ATN", "BAA", "BOA", "CHN", "CLA", "MNA", "OAA", "PHN", "SDN" );
leaderData14 = new Array( "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00" );

leaderName15 = new Array( "R.Grichuk", "J.McCann", "T.Mancini", "J.Abreu", "C.Cuthbert", "A.Santander", "J.Altuve", "W.Calhoun", "J.Soler", "F.Lindor" );
leaderTeam15 = new Array( "MNA", "WAN", "BAA", "CHA", "PHN", "BAA", "CHA", "CIN", "CIN", "CLA" );
leaderData15 = new Array( "8", "8", "6", "6", "6", "5", "5", "5", "5", "5" );

leaderName16 = new Array( "A.Santander", "A.Garcia", "T.Mancini", "D.Dahl", "D.Lemahieu", "C.Dickerson", "R.Nunez", "C.Kelly", "K.Hiura", "M.Conforto" );
leaderTeam16 = new Array( "BAA", "BAA", "BAA", "CON", "CON", "CON", "BAA", "BAA", "BAA", "CIN" );
leaderData16 = new Array( "8", "6", "5", "5", "4", "4", "3", "3", "3", "3" );

leaderName17 = new Array( "J.Luplow", "D.Bote", "C.Maybin", "M.Brosseau", "A.Romine", "D.Dietrich", "H.Kendrick", "H.Castro", "M.Sano", "K.Davis" );
leaderTeam17 = new Array( "CLA", "CHN", "LAA", "DEA", "LAA", "CHA", "SDN", "DEA", "MNA", "PIN" );
leaderData17 = new Array( ".750", ".600", ".571", ".500", ".500", ".429", ".429", ".400", ".400", ".400" );

leaderName18 = new Array( "M.Olson", "K.Marte", "G.Torres", "J.Bell", "N.Arenado", "D.Santana", "E.Encarnacion", "M.Muncy", "N.Cruz", "A.Bregman" );
leaderTeam18 = new Array( "OAA", "SEA", "NYA", "PIN", "CON", "LAA", "LAN", "LAN", "NYA", "CIN" );
leaderData18 = new Array( ".848", ".708", ".708", ".694", ".692", ".690", ".681", ".667", ".663", ".658" );

leaderName19 = new Array( "F.Freeman", "Y.Alvarez", "X.Bogaerts", "Y.Moncada", "A.Bregman", "M.Trout", "B.Harper", "M.Muncy", "M.Olson", "P.Goldschmidt" );
leaderTeam19 = new Array( "ATN", "BAA", "BOA", "SDN", "CIN", "DEA", "WAN", "LAN", "OAA", "OAA" );
leaderData19 = new Array( ".449", ".438", ".436", ".434", ".432", ".422", ".421", ".421", ".417", ".416" );

leaderName20 = new Array( "M.Olson", "Y.Moncada", "A.Bregman", "M.Muncy", "F.Freeman", "X.Bogaerts", "K.Marte", "N.Arenado", "G.Torres", "M.Trout" );
leaderTeam20 = new Array( "OAA", "SDN", "CIN", "LAN", "ATN", "BOA", "SEA", "CON", "NYA", "DEA" );
leaderData20 = new Array( "12.6", "12.2", "11.7", "11.5", "11.1", "11.0", "11.0", "10.5", "10.5", "10.1" );

leaderName21 = new Array( "M.Olson", "A.Bregman", "F.Freeman", "M.Trout", "Y.Moncada", "M.Muncy", "G.Torres", "K.Marte", "N.Arenado", "X.Bogaerts" );
leaderTeam21 = new Array( "OAA", "CIN", "ATN", "DEA", "SDN", "LAN", "NYA", "SEA", "CON", "BOA" );
leaderData21 = new Array( "1.409", "1.250", "1.247", "1.219", "1.219", "1.218", "1.200", "1.195", "1.171", "1.152" );

leaderName22 = new Array( "K.Marte", "N.Arenado", "D.Santana", "M.Olson", "E.Encarnacion", "J.Bell", "G.Torres", "R.Tapia", "A.Bregman", "D.Lemahieu" );
leaderTeam22 = new Array( "SEA", "CON", "LAA", "OAA", "LAN", "PIN", "NYA", "CHN", "CIN", "CON" );
leaderData22 = new Array( "85", "83", "78", "78", "77", "77", "75", "74", "73", "73" );

leaderName23 = new Array( "A.Bregman", "M.Cabrera", "R.Tapia", "M.Garver", "C.Cuthbert", "F.Freeman", "R.Zimmerman", "N.Cruz", "R.Hoskins", "N.Arenado" );
leaderTeam23 = new Array( "CIN", "DEA", "CHN", "MNA", "PHN", "ATN", "CHN", "NYA", "PHN", "CON" );
leaderData23 = new Array( ".560", ".480", ".450", ".450", ".441", ".421", ".421", ".414", ".407", ".400" );

leaderName24 = new Array( "N.Cruz", "J.Martinez", "C.Kelly", "N.Arenado", "A.Hechavarria", "M.Olson", "J.Bell", "K.Pillar", "K.Marte", "A.Garcia" );
leaderTeam24 = new Array( "NYA", "NYA", "BAA", "CON", "LAN", "OAA", "PIN", "SFN", "SEA", "BAA" );
leaderData24 = new Array( "8", "7", "5", "5", "5", "5", "5", "5", "5", "4" );

leaderName25 = new Array( "W.Merrifield", "K.Marte", "J.McNeil", "E.Jimenez", "G.Cooper", "Y.Moncada", "M.Brantley", "X.Bogaerts", "S.Ohtani", "A.Verdugo" );
leaderTeam25 = new Array( "KCA", "SEA", "NYN", "CHA", "CHA", "SDN", "CLA", "BOA", "LAA", "BAA" );
leaderData25 = new Array( ".405", ".389", ".384", ".381", ".379", ".373", ".372", ".372", ".366", ".365" );

leaderName26 = new Array( "D.Santana", "T.Hernandez", "P.Alonso", "J.Realmuto", "C.Yelich", "S.Ohtani", "E.Encarnacion", "D.Freese", "G.Torres", "M.Olson" );
leaderTeam26 = new Array( "LAA", "TOA", "NYN", "ATN", "ATN", "LAA", "LAN", "LAN", "NYA", "OAA" );
leaderData26 = new Array( "12", "11", "10", "9", "9", "9", "9", "9", "9", "9" );

leaderName27 = new Array( "S.Bieber", "D.Price", "R.Yarbrough", "D.German", "M.Fiers", "W.Harris", "R.Ray", "Z.Plesac", "C.Kershaw", "J.Samardzija" );
leaderTeam27 = new Array( "CLA", "ATN", "NYA", "NYA", "BOA", "BOA", "CIN", "CLA", "LAN", "LAN" );
leaderData27 = new Array( "6", "5", "5", "5", "4", "4", "4", "4", "4", "4" );

leaderName28 = new Array( "G.Sparkman", "D.Peters", "C.Sabathia", "M.Scherzer", "D.Pomeranz", "M.Soroka", "J.Lester", "P.Lopez", "K.Hendricks", "A.Sanchez" );
leaderTeam28 = new Array( "PHN", "WAN", "PIN", "SLN", "TOA", "ATN", "BOA", "CHA", "CHN", "CHN" );
leaderData28 = new Array( "6", "6", "5", "5", "5", "4", "4", "4", "4", "4" );

leaderName29 = new Array( "D.Price", "C.Smith", "C.Poche", "J.Happ", "J.Chacin", "S.Bieber", "J.Diaz", "J.Samardzija", "J.Berrios", "D.German" );
leaderTeam29 = new Array( "ATN", "ATN", "ATN", "CHN", "CLA", "CLA", "CON", "LAN", "MNA", "NYA" );
leaderData29 = new Array( "1.000", "1.000", "1.000", "1.000", "1.000", "1.000", "1.000", "1.000", "1.000", "1.000" );

leaderName30 = new Array( "Z.Davies", "J.Flaherty", "S.Strasburg", "H.Ryu", "S.Bieber", "J.Degrom", "C.Morton", "R.Yarbrough", "T.Skaggs", "D.German" );
leaderTeam30 = new Array( "SEA", "SLN", "WAN", "SFN", "CLA", "NYN", "NYN", "NYA", "LAA", "NYA" );
leaderData30 = new Array( " 1.51", " 1.57", " 1.66", " 1.84", " 1.88", " 1.95", " 2.00", " 2.01", " 2.43", " 2.47" );

leaderName31 = new Array( "R.Yarbrough", "H.Ryu", "G.Cole", "L.Lynn", "Z.Wheeler", "T.Bauer", "P.Corbin", "L.Castillo", "J.Verlander", "J.Samardzija" );
leaderTeam31 = new Array( "NYA", "SFN", "PIN", "CHA", "SFN", "MNA", "SFN", "CIN", "LAN", "LAN" );
leaderData31 = new Array( " 49.1", " 49.0", " 47.1", " 45.2", " 45.1", " 43.2", " 43.2", " 43.0", " 42.1", " 41.2" );

leaderName32 = new Array( "Z.Wheeler", "L.Lynn", "R.Yarbrough", "G.Sparkman", "L.Castillo", "G.Cole", "H.Ryu", "P.Corbin", "J.Samardzija", "M.Bumgarner" );
leaderTeam32 = new Array( "SFN", "CHA", "NYA", "PHN", "CIN", "PIN", "SFN", "SFN", "LAN", "SFN" );
leaderData32 = new Array( "195", "192", "187", "187", "185", "182", "182", "180", "177", "177" );

leaderName33 = new Array( "L.Bard", "B.Shaw", "H.Hembree", "J.Soria", "Y.Petit", "H.Rondon", "Z.Eflin", "J.Guerra", "N.Wittgren", "T.Duffey" );
leaderTeam33 = new Array( "LAA", "WAN", "KCA", "NYN", "OAA", "PIN", "SEA", "WAN", "CLA", "KCA" );
leaderData33 = new Array( "22", "18", "17", "17", "17", "17", "17", "17", "16", "16" );

leaderName34 = new Array( "M.Fried", "D.Price", "C.Smith", "M.Soroka", "J.Teheran", "M.Fiers", "J.Lester", "E.Rodriguez", "N.Eovaldi", "S.Brault" );
leaderTeam34 = new Array( "ATN", "ATN", "ATN", "ATN", "ATN", "BOA", "BOA", "BOA", "BOA", "BOA" );
leaderData34 = new Array( "6", "6", "6", "6", "6", "6", "6", "6", "6", "6" );

leaderName35 = new Array( "T.Bauer", "H.Ryu", "L.Lynn", "C.Sale", "W.Miley", "A.Sanchez", "C.McHugh", "J.Gray", "B.Keller", "J.Samardzija" );
leaderTeam35 = new Array( "MNA", "SFN", "CHA", "CHA", "CHN", "CHN", "CLA", "CON", "KCA", "LAN" );
leaderData35 = new Array( "4", "3", "2", "1", "1", "1", "1", "1", "1", "1" );

leaderName36 = new Array( "T.Rogers", "N.Wittgren", "F.Vazquez", "A.Chapman", "L.Hendriks", "Z.Eflin", "A.Colome", "M.Givens", "J.Hader", "S.Newcomb" );
leaderTeam36 = new Array( "BOA", "CLA", "LAA", "LAN", "OAA", "SEA", "CHA", "BAA", "SDN", "ATN" );
leaderData36 = new Array( "15", "15", "11", "11", "11", "11", "10", "9", "9", "8" );

leaderName37 = new Array( "F.Vazquez", "A.Chapman", "L.Hendriks", "A.Colome", "N.Wittgren", "K.Giles", "H.Neris", "T.Rogers", "S.Greene", "S.Lugo" );
leaderTeam37 = new Array( "LAA", "LAN", "OAA", "CHA", "CLA", "NYA", "PHN", "BOA", "CIN", "NYN" );
leaderData37 = new Array( "9", "9", "9", "8", "8", "7", "7", "6", "6", "6" );

leaderName38 = new Array( "M.Givens", "A.Miller", "C.Stammen", "A.Chapman", "S.Lugo", "K.Yates", "R.Osuna", "S.Doolittle", "L.Hendriks", "K.Giles" );
leaderTeam38 = new Array( "BAA", "CHN", "CIN", "LAN", "NYN", "SDN", "SFN", "WAN", "OAA", "NYA" );
leaderData38 = new Array( "1.000", "1.000", "1.000", "1.000", "1.000", "1.000", "1.000", "1.000", ".900", ".875" );

leaderName39 = new Array( "J.Gray", "T.Bauer", "H.Ryu", "", "", "", "", "", "", "" );
leaderTeam39 = new Array( "CON", "MNA", "SFN", "", "", "", "", "", "", "" );
leaderData39 = new Array( "1", "1", "1", "", "", "", "", "", "", "" );

leaderName40 = new Array( "G.Sparkman", "M.Tanaka", "J.Lester", "M.Mikolas", "M.Leake", "K.Gausman", "L.Lynn", "Z.Greinke", "J.Samardzija", "I.Nova" );
leaderTeam40 = new Array( "PHN", "NYA", "BOA", "SLN", "SEA", "BAA", "CHA", "KCA", "LAN", "NYA" );
leaderData40 = new Array( "61", "51", "50", "50", "48", "46", "46", "45", "45", "45" );

leaderName41 = new Array( "G.Sparkman", "J.Lester", "B.Keller", "T.Thornton", "R.Lopez", "J.Lyles", "M.Mikolas", "J.Lucchesi", "N.Eovaldi", "M.Wacha" );
leaderTeam41 = new Array( "PHN", "BOA", "KCA", "TOA", "CHA", "DEA", "SLN", "SDN", "BOA", "DEA" );
leaderData41 = new Array( "49", "34", "32", "31", "29", "29", "29", "29", "28", "28" );

leaderName42 = new Array( "G.Sparkman", "J.Lester", "B.Keller", "T.Thornton", "R.Lopez", "T.Williams", "M.Mikolas", "C.McHugh", "J.Lucchesi", "N.Eovaldi" );
leaderTeam42 = new Array( "PHN", "BOA", "KCA", "TOA", "CHA", "PIN", "SLN", "CLA", "SDN", "BOA" );
leaderData42 = new Array( "49", "33", "32", "29", "28", "28", "28", "27", "27", "25" );

leaderName43 = new Array( "G.Sparkman", "G.Ynoa", "J.Samardzija", "J.Lester", "L.Castillo", "B.Keller", "V.Velasquez", "D.Pomeranz", "R.Lopez", "T.Cahill" );
leaderTeam43 = new Array( "PHN", "PHN", "LAN", "BOA", "CIN", "KCA", "PHN", "TOA", "CHA", "CLA" );
leaderData43 = new Array( "17", "16", "14", "12", "11", "11", "11", "11", "10", "10" );

leaderName44 = new Array( "Z.Gallen", "D.Hudson", "S.Brault", "C.Anderson", "B.Keller", "T.Bauer", "N.Eovaldi", "V.Velasquez", "J.Jimenez", "M.Soroka" );
leaderTeam44 = new Array( "SFN", "SDN", "BOA", "LAA", "KCA", "MNA", "BOA", "PHN", "SLN", "ATN" );
leaderData44 = new Array( "28", "27", "23", "21", "20", "20", "19", "19", "19", "17" );

leaderName45 = new Array( "G.Cole", "T.Bauer", "P.Corbin", "Z.Wheeler", "Y.Darvish", "C.Sale", "M.Boyd", "C.Kershaw", "J.Verlander", "J.Degrom" );
leaderTeam45 = new Array( "PIN", "MNA", "SFN", "SFN", "CIN", "CHA", "DEA", "LAN", "LAN", "NYN" );
leaderData45 = new Array( "71", "58", "57", "57", "55", "53", "50", "49", "49", "49" );

leaderName46 = new Array( "N.Eovaldi", "S.Brault", "T.Cahill", "S.Bieber", "D.Keuchel", "M.Boyd", "N.Pivetta", "T.Buttrey", "T.Chatwood", "Y.Darvish" );
leaderTeam46 = new Array( "BOA", "BOA", "CLA", "CLA", "DEA", "DEA", "PHN", "TOA", "CHN", "CIN" );
leaderData46 = new Array( "4", "4", "4", "4", "4", "4", "4", "4", "3", "3" );

leaderName47 = new Array( "M.Andriese", "M.Mikolas", "B.Woodruff", "M.Baez", "M.Castro", "W.Miley", "R.Porcello", "T.Duffey", "L.Bard", "C.Kershaw" );
leaderTeam47 = new Array( "PIN", "SLN", "MNA", "SDN", "BAA", "CHN", "DEA", "KCA", "LAA", "LAN" );
leaderData47 = new Array( "3", "3", "2", "2", "1", "1", "1", "1", "1", "1" );

leaderName48 = new Array( "D.Price", "M.Soroka", "J.Teheran", "J.Means", "E.Rodriguez", "S.Brault", "K.Hendricks", "A.Desclafani", "L.Castillo", "T.Mahle" );
leaderTeam48 = new Array( "ATN", "ATN", "ATN", "BAA", "BOA", "BOA", "CHN", "CIN", "CIN", "CIN" );
leaderData48 = new Array( "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00" );

leaderName49 = new Array( "S.Turnbull", "J.Degrom", "Y.Darvish", "T.Bauer", "L.Lynn", "T.Cahill", "J.Vargas", "A.Sanchez", "K.Gausman", "S.Brault" );
leaderTeam49 = new Array( "DEA", "NYN", "CIN", "MNA", "CHA", "CLA", "NYN", "TOA", "BAA", "BOA" );
leaderData49 = new Array( "7", "7", "6", "6", "5", "5", "5", "5", "4", "4" );

leaderName50 = new Array( "R.Ray", "S.Bieber", "C.Anderson", "M.Bumgarner", "T.Bauer", "A.Nola", "C.Bassitt", "N.Pivetta", "R.Lopez", "B.Snell" );
leaderTeam50 = new Array( "CIN", "CLA", "LAA", "SFN", "MNA", "PHN", "OAA", "PHN", "CHA", "CON" );
leaderData50 = new Array( ".50", ".50", ".50", ".50", ".60", ".60", ".75", ".75", ".80", ".80" );

leaderName51 = new Array( "J.Jimenez", "H.Neris", "V.Velasquez", "", "", "", "", "", "", "" );
leaderTeam51 = new Array( "SLN", "PHN", "PHN", "", "", "", "", "", "", "" );
leaderData51 = new Array( ".500", ".400", ".250", "", "", "", "", "", "", "" );

leaderName52 = new Array( "V.Velasquez", "", "", "", "", "", "", "", "", "" );
leaderTeam52 = new Array( "PHN", "", "", "", "", "", "", "", "", "" );
leaderData52 = new Array( "1", "", "", "", "", "", "", "", "", "" );

leaderName53 = new Array( "J.Degrom", "C.Smith", "G.Canning", "G.Cole", "H.Ryu", "M.Minor", "J.Berrios", "C.Morton", "C.Kershaw", "C.Bassitt" );
leaderTeam53 = new Array( "NYN", "ATN", "LAA", "PIN", "SFN", "KCA", "MNA", "NYN", "LAN", "OAA" );
leaderData53 = new Array( " 4.1", " 4.5", " 4.6", " 5.1", " 5.5", " 5.9", " 6.0", " 6.0", " 6.1", " 6.1" );

leaderName54 = new Array( "M.Fried", "M.Fiers", "J.Berrios", "R.Yarbrough", "B.Woodruff", "W.Buehler", "C.Quantrill", "S.Bieber", "S.Strasburg", "K.Hendricks" );
leaderTeam54 = new Array( "ATN", "BOA", "MNA", "NYA", "MNA", "LAN", "OAA", "CLA", "WAN", "CHN" );
leaderData54 = new Array( " 1.1", " 1.2", " 1.3", " 1.3", " 1.3", " 1.4", " 1.4", " 1.4", " 1.4", " 1.4" );

leaderName55 = new Array( "G.Cole", "Y.Darvish", "C.Sale", "T.Bauer", "J.Degrom", "P.Corbin", "B.Woodruff", "C.Kershaw", "Z.Wheeler", "W.Miley" );
leaderTeam55 = new Array( "PIN", "CIN", "CHA", "MNA", "NYN", "SFN", "MNA", "LAN", "SFN", "CHN" );
leaderData55 = new Array( "13.5", "12.6", "12.6", "12.0", "11.9", "11.7", "11.5", "11.4", "11.3", "11.1" );

leaderName56 = new Array( "Z.Davies", "D.Hudson", "C.Morton", "B.Anderson", "J.Odorizzi", "T.Skaggs", "H.Ryu", "B.Snell", "G.Canning", "C.Anderson" );
leaderTeam56 = new Array( "SEA", "SDN", "NYN", "OAA", "PHN", "LAA", "SFN", "CON", "LAA", "LAA" );
leaderData56 = new Array( " 0.25", " 0.47", " 0.50", " 0.52", " 0.52", " 0.54", " 0.55", " 0.57", " 0.57", " 0.59" );

