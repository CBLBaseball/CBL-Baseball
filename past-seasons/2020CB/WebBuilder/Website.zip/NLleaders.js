leaderName0 = new Array( "Y.Moncada", "N.Arenado", "R.Tapia", "A.Bregman", "M.Muncy", "J.McNeil", "D.Lemahieu", "D.Dahl", "C.Blackmon", "F.Freeman" );
leaderTeam0 = new Array( "SDN", "CON", "CHN", "CIN", "LAN", "NYN", "CON", "CON", "ATN", "ATN" );
leaderData0 = new Array( ".379", ".342", ".339", ".333", ".333", ".327", ".326", ".307", ".307", ".306" );

leaderName1 = new Array( "D.Lemahieu", "D.Dahl", "C.Bellinger", "A.Rosario", "J.Baez", "J.Villar", "O.Albies", "R.Tapia", "E.Suarez", "N.Arenado" );
leaderTeam1 = new Array( "CON", "CON", "LAN", "NYN", "CHN", "SFN", "ATN", "CHN", "CIN", "CON" );
leaderData1 = new Array( "132", "127", "127", "127", "124", "123", "121", "121", "120", "120" );

leaderName2 = new Array( "F.Freeman", "P.Alonso", "D.Lemahieu", "C.Blackmon", "A.Bregman", "J.Donaldson", "C.Yelich", "D.Dahl", "J.Baez", "C.Bellinger" );
leaderTeam2 = new Array( "ATN", "NYN", "CON", "ATN", "CIN", "WAN", "ATN", "CON", "CHN", "LAN" );
leaderData2 = new Array( "32", "28", "26", "24", "24", "24", "23", "23", "22", "21" );

leaderName3 = new Array( "Y.Moncada", "D.Lemahieu", "R.Tapia", "N.Arenado", "D.Dahl", "A.Bregman", "C.Blackmon", "P.Alonso", "J.Baez", "J.Realmuto" );
leaderTeam3 = new Array( "SDN", "CON", "CHN", "CON", "CON", "CIN", "ATN", "NYN", "CHN", "ATN" );
leaderData3 = new Array( "44", "43", "41", "41", "39", "37", "35", "35", "34", "33" );

leaderName4 = new Array( "R.Tapia", "D.Swanson", "J.McNeil", "J.Bell", "C.Blackmon", "J.Baez", "D.Lemahieu", "D.Dahl", "C.Dickerson", "N.Arenado" );
leaderTeam4 = new Array( "CHN", "ATN", "NYN", "PIN", "ATN", "CHN", "CON", "CON", "CON", "CON" );
leaderData4 = new Array( "17", "12", "12", "11", "10", "9", "9", "9", "9", "9" );

leaderName5 = new Array( "J.Realmuto", "F.Tatis Jr", "R.Tapia", "I.Desmond", "E.Andrus", "M.Zunino", "J.Marisnick", "E.Longoria", "J.Bradley Jr", "W.Myers" );
leaderTeam5 = new Array( "ATN", "SDN", "CHN", "CON", "CON", "CON", "LAN", "NYN", "NYN", "NYN" );
leaderData5 = new Array( "3", "3", "2", "2", "2", "2", "2", "2", "2", "2" );

leaderName6 = new Array( "E.Encarnacion", "N.Arenado", "J.Bell", "R.Odor", "P.Alonso", "J.Realmuto", "F.Freeman", "C.Yelich", "A.Bregman", "E.Suarez" );
leaderTeam6 = new Array( "LAN", "CON", "PIN", "CIN", "NYN", "ATN", "ATN", "ATN", "CIN", "CIN" );
leaderData6 = new Array( "13", "11", "11", "10", "10", "9", "9", "9", "9", "9" );

leaderName7 = new Array( "C.Blackmon", "J.Bell", "C.Bellinger", "J.Donaldson", "J.Realmuto", "N.Arenado", "J.McNeil", "A.Bregman", "R.Odor", "P.Alonso" );
leaderTeam7 = new Array( "ATN", "PIN", "LAN", "WAN", "ATN", "CON", "NYN", "CIN", "CIN", "NYN" );
leaderData7 = new Array( "30", "29", "26", "26", "25", "25", "25", "24", "24", "24" );

leaderName8 = new Array( "F.Freeman", "B.Harper", "J.Donaldson", "C.Santana", "C.Yelich", "O.Albies", "A.Bregman", "Y.Grandal", "P.Alonso", "T.Story" );
leaderTeam8 = new Array( "ATN", "WAN", "WAN", "NYN", "ATN", "ATN", "CIN", "LAN", "NYN", "CON" );
leaderData8 = new Array( "28", "28", "27", "22", "21", "20", "19", "19", "18", "17" );

leaderName9 = new Array( "F.Freeman", "C.Blackmon", "A.Rendon", "N.Arenado", "A.Hechavarria", "F.Tatis Jr", "K.Pillar", "C.Yelich", "A.Dickerson", "J.Soler" );
leaderTeam9 = new Array( "ATN", "ATN", "SFN", "CON", "LAN", "SDN", "SFN", "ATN", "ATN", "CIN" );
leaderData9 = new Array( "4", "4", "4", "3", "3", "3", "3", "2", "2", "2" );

leaderName10 = new Array( "J.Soler", "D.Dahl", "E.Suarez", "R.Odor", "P.Alonso", "T.Story", "J.Villar", "T.Turner", "R.Acuna", "W.Contreras" );
leaderTeam10 = new Array( "CIN", "CON", "CIN", "CIN", "NYN", "CON", "SFN", "WAN", "ATN", "CHN" );
leaderData10 = new Array( "46", "45", "41", "40", "40", "39", "35", "35", "34", "34" );

leaderName11 = new Array( "J.Turner", "V.Robles", "B.Anderson", "K.Bryant", "J.Cave", "J.Marisnick", "J.McNeil", "M.Gonzalez", "J.Bell", "R.Martin" );
leaderTeam11 = new Array( "LAN", "SDN", "SDN", "CHN", "CHN", "LAN", "NYN", "PIN", "PIN", "SDN" );
leaderData11 = new Array( "5", "5", "5", "4", "4", "4", "4", "4", "4", "4" );

leaderName12 = new Array( "B.Drury", "C.Cuthbert", "A.Frazier", "D.Deshields", "J.Marisnick", "A.Rosario", "J.Bradley Jr", "M.Franco", "S.Wilkerson", "J.Jones" );
leaderTeam12 = new Array( "PHN", "PHN", "PIN", "WAN", "LAN", "NYN", "NYN", "PHN", "PHN", "SLN" );
leaderData12 = new Array( "3", "3", "3", "3", "2", "2", "2", "2", "2", "2" );

leaderName13 = new Array( "R.Acuna", "J.Villar", "J.Heyward", "R.Tapia", "O.Albies", "S.Kingery", "K.Wong", "Y.Moncada", "V.Robles", "F.Tatis Jr" );
leaderTeam13 = new Array( "ATN", "SFN", "CHN", "CHN", "ATN", "PHN", "SLN", "SDN", "SDN", "SDN" );
leaderData13 = new Array( "12", "9", "6", "5", "4", "4", "4", "4", "4", "4" );

leaderName14 = new Array( "O.Albies", "R.Acuna", "J.Heyward", "S.Kingery", "Y.Moncada", "J.Villar", "K.Wong", "F.Tatis Jr", "A.Eaton", "R.Tapia" );
leaderTeam14 = new Array( "ATN", "ATN", "CHN", "PHN", "SDN", "SFN", "SLN", "SDN", "WAN", "CHN" );
leaderData14 = new Array( "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", ".80", ".80", ".80", ".71" );

leaderName15 = new Array( "J.McCann", "C.Cuthbert", "W.Calhoun", "J.Soler", "R.Grossman", "M.Machado", "M.Ozuna", "R.Acuna", "C.Blackmon", "J.Baez" );
leaderTeam15 = new Array( "WAN", "PHN", "CIN", "CIN", "PIN", "SLN", "SFN", "ATN", "ATN", "CHN" );
leaderData15 = new Array( "8", "6", "5", "5", "5", "5", "5", "4", "4", "4" );

leaderName16 = new Array( "D.Dahl", "D.Lemahieu", "C.Dickerson", "M.Conforto", "E.Andrus", "J.Pederson", "J.Turner", "C.Hernandez", "J.Crawford", "Y.Moncada" );
leaderTeam16 = new Array( "CON", "CON", "CON", "CIN", "CON", "LAN", "LAN", "PHN", "PHN", "SDN" );
leaderData16 = new Array( "5", "4", "4", "3", "3", "3", "3", "3", "3", "3" );

leaderName17 = new Array( "D.Bote", "H.Kendrick", "K.Davis", "B.Dixon", "P.Sandoval", "T.Edman", "", "", "", "" );
leaderTeam17 = new Array( "CHN", "SDN", "PIN", "SLN", "ATN", "SLN", "", "", "", "" );
leaderData17 = new Array( ".600", ".429", ".400", ".250", ".200", ".200", "0", "0", "0", "0" );

leaderName18 = new Array( "J.Bell", "N.Arenado", "E.Encarnacion", "M.Muncy", "A.Bregman", "J.Realmuto", "P.Alonso", "Y.Moncada", "R.Tapia", "F.Freeman" );
leaderTeam18 = new Array( "PIN", "CON", "LAN", "LAN", "CIN", "ATN", "NYN", "SDN", "CHN", "ATN" );
leaderData18 = new Array( ".694", ".692", ".681", ".667", ".658", ".655", ".629", ".629", ".612", ".611" );

leaderName19 = new Array( "F.Freeman", "Y.Moncada", "A.Bregman", "B.Harper", "M.Muncy", "P.Alonso", "N.Arenado", "C.Yelich", "C.Blackmon", "J.Donaldson" );
leaderTeam19 = new Array( "ATN", "SDN", "CIN", "WAN", "LAN", "NYN", "CON", "ATN", "ATN", "WAN" );
leaderData19 = new Array( ".449", ".434", ".432", ".421", ".421", ".409", ".400", ".393", ".392", ".391" );

leaderName20 = new Array( "Y.Moncada", "A.Bregman", "M.Muncy", "F.Freeman", "N.Arenado", "P.Alonso", "J.Bell", "J.McNeil", "R.Tapia", "C.Yelich" );
leaderTeam20 = new Array( "SDN", "CIN", "LAN", "ATN", "CON", "NYN", "PIN", "NYN", "CHN", "ATN" );
leaderData20 = new Array( "12.2", "11.7", "11.5", "11.1", "10.5", " 9.8", " 9.7", " 9.4", " 9.0", " 8.9" );

leaderName21 = new Array( "A.Bregman", "F.Freeman", "Y.Moncada", "M.Muncy", "N.Arenado", "J.Bell", "P.Alonso", "C.Yelich", "R.Tapia", "E.Encarnacion" );
leaderTeam21 = new Array( "CIN", "ATN", "SDN", "LAN", "CON", "PIN", "NYN", "ATN", "CHN", "LAN" );
leaderData21 = new Array( "1.250", "1.247", "1.219", "1.218", "1.171", "1.139", "1.119", "1.106", "1.036", "1.034" );

leaderName22 = new Array( "N.Arenado", "E.Encarnacion", "J.Bell", "R.Tapia", "A.Bregman", "D.Lemahieu", "P.Alonso", "Y.Moncada", "J.Realmuto", "D.Dahl" );
leaderTeam22 = new Array( "CON", "LAN", "PIN", "CHN", "CIN", "CON", "NYN", "SDN", "ATN", "CON" );
leaderData22 = new Array( "83", "77", "77", "74", "73", "73", "73", "73", "72", "72" );

leaderName23 = new Array( "A.Bregman", "R.Tapia", "C.Cuthbert", "F.Freeman", "R.Zimmerman", "R.Hoskins", "N.Arenado", "E.Longoria", "M.Cabrera", "Y.Moncada" );
leaderTeam23 = new Array( "CIN", "CHN", "PHN", "ATN", "CHN", "PHN", "CON", "NYN", "SLN", "SDN" );
leaderData23 = new Array( ".560", ".450", ".441", ".421", ".421", ".407", ".400", ".400", ".400", ".394" );

leaderName24 = new Array( "N.Arenado", "A.Hechavarria", "J.Bell", "K.Pillar", "A.Bregman", "R.Odor", "Y.Grandal", "E.Encarnacion", "W.Myers", "C.Cuthbert" );
leaderTeam24 = new Array( "CON", "LAN", "PIN", "SFN", "CIN", "CIN", "LAN", "LAN", "NYN", "PHN" );
leaderData24 = new Array( "5", "5", "5", "5", "4", "4", "4", "4", "4", "4" );

leaderName25 = new Array( "J.McNeil", "Y.Moncada", "P.Alonso", "J.Bell", "A.Pujols", "C.Blackmon", "M.Beaty", "D.Lemahieu", "M.Muncy", "J.Turner" );
leaderTeam25 = new Array( "NYN", "SDN", "NYN", "PIN", "CHN", "ATN", "LAN", "CON", "LAN", "LAN" );
leaderData25 = new Array( ".384", ".373", ".357", ".352", ".338", ".337", ".333", ".330", ".328", ".327" );

leaderName26 = new Array( "P.Alonso", "J.Realmuto", "C.Yelich", "E.Encarnacion", "D.Freese", "A.Almora Jr", "J.Pederson", "C.Blackmon", "K.Schwarber", "E.Suarez" );
leaderTeam26 = new Array( "NYN", "ATN", "ATN", "LAN", "LAN", "CHN", "LAN", "ATN", "CHN", "CIN" );
leaderData26 = new Array( "10", "9", "9", "9", "9", "8", "8", "7", "7", "7" );

leaderName27 = new Array( "D.Price", "R.Ray", "C.Kershaw", "J.Samardzija", "J.Degrom", "A.Cashner", "J.Odorizzi", "M.Kelly", "M.Bumgarner", "H.Ryu" );
leaderTeam27 = new Array( "ATN", "CIN", "LAN", "LAN", "NYN", "NYN", "PHN", "PIN", "SFN", "SFN" );
leaderData27 = new Array( "5", "4", "4", "4", "4", "4", "4", "4", "4", "4" );

leaderName28 = new Array( "G.Sparkman", "D.Peters", "C.Sabathia", "M.Scherzer", "M.Soroka", "K.Hendricks", "A.Sanchez", "P.Lambert", "W.Buehler", "N.Pivetta" );
leaderTeam28 = new Array( "PHN", "WAN", "PIN", "SLN", "ATN", "CHN", "CHN", "CON", "LAN", "PHN" );
leaderData28 = new Array( "6", "6", "5", "5", "4", "4", "4", "4", "4", "4" );

leaderName29 = new Array( "D.Price", "C.Smith", "C.Poche", "J.Happ", "J.Diaz", "J.Samardzija", "J.Degrom", "R.Ray", "C.Kershaw", "M.Kelly" );
leaderTeam29 = new Array( "ATN", "ATN", "ATN", "CHN", "CON", "LAN", "NYN", "CIN", "LAN", "PIN" );
leaderData29 = new Array( "1.000", "1.000", "1.000", "1.000", "1.000", "1.000", "1.000", ".800", ".800", ".800" );

leaderName30 = new Array( "J.Flaherty", "S.Strasburg", "H.Ryu", "J.Degrom", "C.Morton", "C.Smith", "A.Cashner", "Y.Chirinos", "J.Happ", "R.Ray" );
leaderTeam30 = new Array( "SLN", "WAN", "SFN", "NYN", "NYN", "ATN", "NYN", "SDN", "CHN", "CIN" );
leaderData30 = new Array( " 1.57", " 1.66", " 1.84", " 1.95", " 2.00", " 2.75", " 2.75", " 2.83", " 2.87", " 3.03" );

leaderName31 = new Array( "H.Ryu", "G.Cole", "Z.Wheeler", "P.Corbin", "L.Castillo", "J.Verlander", "J.Samardzija", "M.Bumgarner", "A.Sanchez", "Y.Darvish" );
leaderTeam31 = new Array( "SFN", "PIN", "SFN", "SFN", "CIN", "LAN", "LAN", "SFN", "CHN", "CIN" );
leaderData31 = new Array( " 49.0", " 47.1", " 45.1", " 43.2", " 43.0", " 42.1", " 41.2", " 41.2", " 40.0", " 39.1" );

leaderName32 = new Array( "Z.Wheeler", "G.Sparkman", "L.Castillo", "G.Cole", "H.Ryu", "P.Corbin", "J.Samardzija", "M.Bumgarner", "M.Soroka", "J.Verlander" );
leaderTeam32 = new Array( "SFN", "PHN", "CIN", "PIN", "SFN", "SFN", "LAN", "SFN", "ATN", "LAN" );
leaderData32 = new Array( "195", "187", "185", "182", "182", "180", "177", "177", "174", "173" );

leaderName33 = new Array( "B.Shaw", "J.Soria", "H.Rondon", "J.Guerra", "J.Jimenez", "S.Newcomb", "J.Diaz", "S.Dyson", "N.Ramirez", "N.Anderson" );
leaderTeam33 = new Array( "WAN", "NYN", "PIN", "WAN", "SLN", "ATN", "CON", "NYN", "SDN", "WAN" );
leaderData33 = new Array( "18", "17", "17", "17", "16", "15", "15", "15", "15", "15" );

leaderName34 = new Array( "M.Fried", "D.Price", "C.Smith", "M.Soroka", "J.Teheran", "W.Miley", "J.Happ", "K.Hendricks", "J.Quintana", "A.Sanchez" );
leaderTeam34 = new Array( "ATN", "ATN", "ATN", "ATN", "ATN", "CHN", "CHN", "CHN", "CHN", "CHN" );
leaderData34 = new Array( "6", "6", "6", "6", "6", "6", "6", "6", "6", "6" );

leaderName35 = new Array( "H.Ryu", "W.Miley", "A.Sanchez", "J.Gray", "J.Samardzija", "G.Cole", "Z.Wheeler", "Z.Gallen", "", "" );
leaderTeam35 = new Array( "SFN", "CHN", "CHN", "CON", "LAN", "PIN", "SFN", "SFN", "", "" );
leaderData35 = new Array( "3", "1", "1", "1", "1", "1", "1", "1", "", "" );

leaderName36 = new Array( "A.Chapman", "J.Hader", "S.Newcomb", "S.Gaviglio", "S.Greene", "S.Lugo", "J.Guerra", "G.Gallegos", "G.Soto", "R.Osuna" );
leaderTeam36 = new Array( "LAN", "SDN", "ATN", "ATN", "CIN", "NYN", "NYN", "SLN", "SLN", "SFN" );
leaderData36 = new Array( "11", "9", "8", "8", "8", "8", "8", "8", "8", "8" );

leaderName37 = new Array( "A.Chapman", "H.Neris", "S.Greene", "S.Lugo", "K.Yates", "R.Osuna", "B.Workman", "Z.Britton", "A.Miller", "C.Stammen" );
leaderTeam37 = new Array( "LAN", "PHN", "CIN", "NYN", "SDN", "SFN", "PIN", "ATN", "CHN", "CIN" );
leaderData37 = new Array( "9", "7", "6", "6", "6", "6", "5", "4", "3", "3" );

leaderName38 = new Array( "A.Miller", "C.Stammen", "A.Chapman", "S.Lugo", "K.Yates", "R.Osuna", "S.Doolittle", "H.Neris", "Z.Britton", "S.Greene" );
leaderTeam38 = new Array( "CHN", "CIN", "LAN", "NYN", "SDN", "SFN", "WAN", "PHN", "ATN", "CIN" );
leaderData38 = new Array( "1.000", "1.000", "1.000", "1.000", "1.000", "1.000", "1.000", ".875", ".800", ".750" );

leaderName39 = new Array( "J.Gray", "H.Ryu", "", "", "", "", "", "", "", "" );
leaderTeam39 = new Array( "CON", "SFN", "", "", "", "", "", "", "", "" );
leaderData39 = new Array( "1", "1", "", "", "", "", "", "", "", "" );

leaderName40 = new Array( "G.Sparkman", "M.Mikolas", "J.Samardzija", "M.Bumgarner", "J.Guerra", "M.Soroka", "L.Castillo", "Z.Wheeler", "T.Mahle", "K.Hendricks" );
leaderTeam40 = new Array( "PHN", "SLN", "LAN", "SFN", "WAN", "ATN", "CIN", "SFN", "CIN", "CHN" );
leaderData40 = new Array( "61", "50", "45", "44", "43", "42", "42", "42", "41", "40" );

leaderName41 = new Array( "G.Sparkman", "M.Mikolas", "J.Lucchesi", "T.Williams", "P.Lambert", "J.Verlander", "V.Velasquez", "G.Ynoa", "C.Sabathia", "J.Guerra" );
leaderTeam41 = new Array( "PHN", "SLN", "SDN", "PIN", "CON", "LAN", "PHN", "PHN", "PIN", "WAN" );
leaderData41 = new Array( "49", "29", "29", "28", "27", "26", "26", "25", "25", "25" );

leaderName42 = new Array( "G.Sparkman", "T.Williams", "M.Mikolas", "J.Lucchesi", "P.Lambert", "G.Ynoa", "J.Gray", "A.Jurado", "A.Sanchez", "G.Marquez" );
leaderTeam42 = new Array( "PHN", "PIN", "SLN", "SDN", "CON", "PHN", "CON", "WAN", "CHN", "CON" );
leaderData42 = new Array( "49", "28", "28", "27", "25", "25", "24", "24", "23", "23" );

leaderName43 = new Array( "G.Sparkman", "G.Ynoa", "J.Samardzija", "L.Castillo", "V.Velasquez", "J.Verlander", "T.Williams", "G.Cole", "J.Jimenez", "J.Lucchesi" );
leaderTeam43 = new Array( "PHN", "PHN", "LAN", "CIN", "PHN", "LAN", "PIN", "PIN", "SLN", "SDN" );
leaderData43 = new Array( "17", "16", "14", "11", "11", "10", "10", "9", "9", "9" );

leaderName44 = new Array( "Z.Gallen", "D.Hudson", "V.Velasquez", "J.Jimenez", "M.Soroka", "J.Teheran", "L.Castillo", "N.Goody", "A.Nola", "Z.Wheeler" );
leaderTeam44 = new Array( "SFN", "SDN", "PHN", "SLN", "ATN", "ATN", "CIN", "CON", "PHN", "SFN" );
leaderData44 = new Array( "28", "27", "19", "19", "17", "17", "17", "17", "17", "17" );

leaderName45 = new Array( "G.Cole", "P.Corbin", "Z.Wheeler", "Y.Darvish", "C.Kershaw", "J.Verlander", "J.Degrom", "W.Miley", "L.Castillo", "R.Ray" );
leaderTeam45 = new Array( "PIN", "SFN", "SFN", "CIN", "LAN", "LAN", "NYN", "CHN", "CIN", "CIN" );
leaderData45 = new Array( "71", "57", "57", "55", "49", "49", "49", "47", "45", "45" );

leaderName46 = new Array( "N.Pivetta", "T.Chatwood", "Y.Darvish", "K.Freeland", "P.Lambert", "G.Sparkman", "M.Mikolas", "J.Garcia", "R.Ray", "J.Tomlin" );
leaderTeam46 = new Array( "PHN", "CHN", "CIN", "CON", "CON", "PHN", "SLN", "CHN", "CIN", "CIN" );
leaderData46 = new Array( "4", "3", "3", "3", "3", "3", "3", "2", "2", "2" );

leaderName47 = new Array( "M.Andriese", "M.Mikolas", "M.Baez", "W.Miley", "C.Kershaw", "", "", "", "", "" );
leaderTeam47 = new Array( "PIN", "SLN", "SDN", "CHN", "LAN", "", "", "", "", "" );
leaderData47 = new Array( "3", "3", "2", "1", "1", "", "", "", "", "" );

leaderName48 = new Array( "D.Price", "M.Soroka", "J.Teheran", "K.Hendricks", "A.Desclafani", "L.Castillo", "T.Mahle", "R.Ray", "J.Samardzija", "C.Morton" );
leaderTeam48 = new Array( "ATN", "ATN", "ATN", "CHN", "CIN", "CIN", "CIN", "CIN", "LAN", "NYN" );
leaderData48 = new Array( "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00" );

leaderName49 = new Array( "J.Degrom", "Y.Darvish", "J.Vargas", "B.Snell", "P.Baez", "A.Garrett", "B.Shaw", "A.Nola", "N.Pivetta", "R.Ray" );
leaderTeam49 = new Array( "NYN", "CIN", "NYN", "CON", "NYN", "PIN", "WAN", "PHN", "PHN", "CIN" );
leaderData49 = new Array( "7", "6", "5", "4", "4", "4", "4", "3", "3", "2" );

leaderName50 = new Array( "R.Ray", "M.Bumgarner", "A.Nola", "N.Pivetta", "B.Snell", "J.Vargas", "Y.Darvish", "J.Degrom", "P.Baez", "A.Garrett" );
leaderTeam50 = new Array( "CIN", "SFN", "PHN", "PHN", "CON", "NYN", "CIN", "NYN", "NYN", "PIN" );
leaderData50 = new Array( ".50", ".50", ".60", ".75", ".80", ".83", "1.00", "1.00", "1.00", "1.00" );

leaderName51 = new Array( "J.Jimenez", "H.Neris", "V.Velasquez", "", "", "", "", "", "", "" );
leaderTeam51 = new Array( "SLN", "PHN", "PHN", "", "", "", "", "", "", "" );
leaderData51 = new Array( ".500", ".400", ".250", "", "", "", "", "", "", "" );

leaderName52 = new Array( "V.Velasquez", "", "", "", "", "", "", "", "", "" );
leaderTeam52 = new Array( "PHN", "", "", "", "", "", "", "", "", "" );
leaderData52 = new Array( "1", "", "", "", "", "", "", "", "", "" );

leaderName53 = new Array( "J.Degrom", "C.Smith", "G.Cole", "H.Ryu", "C.Morton", "C.Kershaw", "J.Flaherty", "J.Happ", "A.Nola", "W.Miley" );
leaderTeam53 = new Array( "NYN", "ATN", "PIN", "SFN", "NYN", "LAN", "SLN", "CHN", "PHN", "CHN" );
leaderData53 = new Array( " 4.1", " 4.5", " 5.1", " 5.5", " 6.0", " 6.1", " 6.3", " 6.7", " 6.8", " 6.9" );

leaderName54 = new Array( "M.Fried", "W.Buehler", "S.Strasburg", "K.Hendricks", "D.Price", "H.Ryu", "J.Verlander", "M.Bumgarner", "J.Flaherty", "P.Corbin" );
leaderTeam54 = new Array( "ATN", "LAN", "WAN", "CHN", "ATN", "SFN", "LAN", "SFN", "SLN", "SFN" );
leaderData54 = new Array( " 1.1", " 1.4", " 1.4", " 1.4", " 1.5", " 1.5", " 1.5", " 1.5", " 1.6", " 1.6" );

leaderName55 = new Array( "G.Cole", "Y.Darvish", "J.Degrom", "P.Corbin", "C.Kershaw", "Z.Wheeler", "W.Miley", "C.Smith", "R.Ray", "S.Strasburg" );
leaderTeam55 = new Array( "PIN", "CIN", "NYN", "SFN", "LAN", "SFN", "CHN", "ATN", "CIN", "WAN" );
leaderData55 = new Array( "13.5", "12.6", "11.9", "11.7", "11.4", "11.3", "11.1", "11.0", "10.5", "10.4" );

leaderName56 = new Array( "D.Hudson", "C.Morton", "J.Odorizzi", "H.Ryu", "B.Snell", "J.Teheran", "S.Strasburg", "D.Price", "A.Desclafani", "A.Cashner" );
leaderTeam56 = new Array( "SDN", "NYN", "PHN", "SFN", "CON", "ATN", "WAN", "ATN", "CIN", "NYN" );
leaderData56 = new Array( " 0.47", " 0.50", " 0.52", " 0.55", " 0.57", " 0.71", " 0.71", " 0.73", " 0.74", " 0.75" );

