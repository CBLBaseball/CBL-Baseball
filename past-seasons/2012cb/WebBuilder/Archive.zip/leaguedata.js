sub = new Array( "AL", "NL" );
sublong = new Array( "American League", "National League" );

AL = new Array( "ALEast", "ALCentral", "ALWest" );
NL = new Array( "NLEast", "NLCentral", "NLWest" );

ALALEast = new Array( "BAA", "BOA", "NYA", "TOA" );

BAA = new Array("ALEast", "Baltimore", "Orioles", "Baltimore Orioles (BAA)", "2012", "162", "85", "77", ".525", ".506", ".543" );
BOA = new Array("ALEast", "Boston", "Red Sox", "Boston Red Sox (BOA)", "2012", "162", "103", "59", ".636", ".605", ".667" );
NYA = new Array("ALEast", "New York (AL)", "Yankees", "New York (AL) Yankees (NYA)", "2012", "162", "69", "93", ".426", ".407", ".444" );
TOA = new Array("ALEast", "Toronto", "Blue Jays", "Toronto Blue Jays (TOA)", "2012", "162", "66", "96", ".407", ".432", ".383" );
ALALCentral = new Array( "CHA", "CLA", "DEA", "MNA" );

CHA = new Array("ALCentral", "Chicago (AL)", "White Sox", "Chicago (AL) White Sox (CHA)", "2012", "162", "88", "74", ".543", ".543", ".543" );
CLA = new Array("ALCentral", "Cleveland", "Indians", "Cleveland Indians (CLA)", "2012", "162", "84", "78", ".519", ".444", ".593" );
DEA = new Array("ALCentral", "Detroit", "Tigers", "Detroit Tigers (DEA)", "2012", "162", "89", "73", ".549", ".506", ".593" );
MNA = new Array("ALCentral", "Minnesota", "Twins", "Minnesota Twins (MNA)", "2012", "162", "66", "96", ".407", ".346", ".469" );
ALALWest = new Array( "KCA", "LAA", "OAA", "SEA" );

KCA = new Array("ALWest", "Kansas City", "Royals", "Kansas City Royals (KCA)", "2012", "162", "76", "86", ".469", ".383", ".556" );
LAA = new Array("ALWest", "Los Angeles(AL)", "Angels", "Los Angeles(AL) Angels (LAA)", "2012", "162", "67", "95", ".414", ".432", ".395" );
OAA = new Array("ALWest", "Oakland", "A's", "Oakland A's (OAA)", "2012", "162", "73", "89", ".451", ".444", ".457" );
SEA = new Array("ALWest", "Seattle", "Mariners", "Seattle Mariners (SEA)", "2012", "162", "105", "57", ".648", ".617", ".679" );
NLNLEast = new Array( "ATN", "NYN", "PHN", "WAN" );

ATN = new Array("NLEast", "Atlanta", "Braves", "Atlanta Braves (ATN)", "2012", "162", "112", "50", ".691", ".642", ".741" );
NYN = new Array("NLEast", "New York (NL)", "Mets", "New York (NL) Mets (NYN)", "2012", "162", "86", "76", ".531", ".494", ".568" );
PHN = new Array("NLEast", "Philadelphia", "Phillies", "Philadelphia Phillies (PHN)", "2012", "162", "108", "54", ".667", ".679", ".654" );
WAN = new Array("NLEast", "Washington", "Nationals", "Washington Nationals (WAN)", "2012", "162", "75", "87", ".463", ".407", ".519" );
NLNLCentral = new Array( "CHN", "CIN", "PIN", "SLN" );

CHN = new Array("NLCentral", "Chicago (NL)", "Cubs", "Chicago (NL) Cubs (CHN)", "2012", "162", "86", "76", ".531", ".395", ".667" );
CIN = new Array("NLCentral", "Cincinnati", "Reds", "Cincinnati Reds (CIN)", "2012", "162", "68", "94", ".420", ".321", ".519" );
PIN = new Array("NLCentral", "Pittsburgh", "Pirates", "Pittsburgh Pirates (PIN)", "2012", "162", "67", "95", ".414", ".420", ".407" );
SLN = new Array("NLCentral", "St. Louis", "Cardinals", "St. Louis Cardinals (SLN)", "2012", "162", "82", "80", ".506", ".469", ".543" );
NLNLWest = new Array( "HON", "LAN", "SDN", "SFN" );

HON = new Array("NLWest", "Houston", "Astros", "Houston Astros (HON)", "2012", "162", "82", "80", ".506", ".481", ".531" );
LAN = new Array("NLWest", "Los Angeles(NL)", "Dodgers", "Los Angeles(NL) Dodgers (LAN)", "2012", "162", "75", "87", ".463", ".420", ".506" );
SDN = new Array("NLWest", "San Diego", "Padres", "San Diego Padres (SDN)", "2012", "162", "51", "111", ".315", ".259", ".370" );
SFN = new Array("NLWest", "San Francisco", "Giants", "San Francisco Giants (SFN)", "2012", "162", "81", "81", ".500", ".420", ".580" );
