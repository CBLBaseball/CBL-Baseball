leaderName0 = new Array( "H.Pence", "V.Martinez", "M.Kemp", "M.Bourn", "M.Young", "F.Freeman", "M.Cabrera", "E.Aybar", "E.Bonifacio", "J.Bautista" );
leaderTeam0 = new Array( "HON", "PHN", "LAN", "HON", "PHN", "ATN", "SLN", "SLN", "ATN", "PHN" );
leaderData0 = new Array( ".345", ".341", ".325", ".324", ".324", ".319", ".317", ".312", ".306", ".303" );

leaderName1 = new Array( "S.Castro", "M.Cabrera", "M.Bourn", "M.Young", "B.Phillips", "M.Kemp", "H.Pence", "J.Votto", "D.Stubbs", "F.Freeman" );
leaderTeam1 = new Array( "CHN", "SFN", "HON", "PHN", "CIN", "LAN", "HON", "CIN", "CIN", "ATN" );
leaderData1 = new Array( "663", "657", "642", "633", "630", "622", "609", "596", "591", "587" );

leaderName2 = new Array( "J.Votto", "J.Bautista", "M.Kemp", "M.Bourn", "M.Young", "A.Pujols", "M.Cabrera", "F.Freeman", "H.Pence", "M.Stanton" );
leaderTeam2 = new Array( "CIN", "PHN", "LAN", "HON", "PHN", "PIN", "SLN", "ATN", "HON", "ATN" );
leaderData2 = new Array( "114", "112", "108", "100", "100", "97", "96", "93", "92", "91" );

leaderName3 = new Array( "H.Pence", "M.Bourn", "M.Young", "M.Kemp", "M.Cabrera", "F.Freeman", "S.Castro", "M.Cabrera", "B.Phillips", "J.Votto" );
leaderTeam3 = new Array( "HON", "HON", "PHN", "LAN", "SFN", "ATN", "CHN", "SLN", "CIN", "CIN" );
leaderData3 = new Array( "210", "208", "205", "202", "196", "187", "187", "185", "181", "177" );

leaderName4 = new Array( "M.Bourn", "M.Young", "M.Cabrera", "V.Martinez", "F.Freeman", "H.Pence", "J.Votto", "C.Pena", "M.Joyce", "T.Tulowitzki" );
leaderTeam4 = new Array( "HON", "PHN", "SLN", "PHN", "ATN", "HON", "CIN", "LAN", "CHN", "HON" );
leaderData4 = new Array( "49", "49", "45", "42", "41", "41", "40", "39", "38", "38" );

leaderName5 = new Array( "S.Victorino", "C.Maybin", "D.Fowler", "M.Bourn", "O.Infante", "M.Stanton", "H.Kendrick", "E.Aybar", "M.Cabrera", "I.Desmond" );
leaderTeam5 = new Array( "PHN", "SLN", "WAN", "HON", "ATN", "ATN", "SFN", "SLN", "SFN", "SFN" );
leaderData5 = new Array( "20", "13", "12", "11", "10", "10", "10", "8", "8", "8" );

leaderName6 = new Array( "A.Pujols", "M.Kemp", "J.Bautista", "J.Bruce", "P.Fielder", "J.Votto", "M.Stanton", "F.Freeman", "A.Beltre", "J.Willingham" );
leaderTeam6 = new Array( "PIN", "LAN", "PHN", "CIN", "WAN", "CIN", "ATN", "ATN", "HON", "SFN" );
leaderData6 = new Array( "47", "38", "38", "36", "35", "34", "33", "30", "30", "30" );

leaderName7 = new Array( "J.Bautista", "A.Pujols", "H.Pence", "P.Fielder", "M.Stanton", "R.Howard", "J.Bruce", "M.Kemp", "F.Freeman", "J.Votto" );
leaderTeam7 = new Array( "PHN", "PIN", "HON", "WAN", "ATN", "PHN", "CIN", "LAN", "ATN", "CIN" );
leaderData7 = new Array( "121", "117", "110", "109", "104", "103", "101", "101", "100", "96" );

leaderName8 = new Array( "J.Votto", "J.Bautista", "C.Pena", "M.Cabrera", "R.Howard", "B.Zobrist", "A.McCutchen", "E.Longoria", "M.Kemp", "H.Pence" );
leaderTeam8 = new Array( "CIN", "PHN", "LAN", "SLN", "PHN", "SLN", "PIN", "SDN", "LAN", "HON" );
leaderData8 = new Array( "117", "117", "92", "91", "84", "84", "81", "76", "75", "72" );

leaderName9 = new Array( "V.Martinez", "H.Pence", "M.Kemp", "M.Young", "M.Cabrera", "M.Bourn", "J.Rollins", "M.Stanton", "S.Castro", "B.Phillips" );
leaderTeam9 = new Array( "PHN", "HON", "LAN", "PHN", "SLN", "HON", "PHN", "ATN", "CHN", "CIN" );
leaderData9 = new Array( "16", "14", "13", "13", "11", "9", "8", "7", "7", "7" );

leaderName10 = new Array( "D.Stubbs", "B.Upton", "M.Stanton", "J.Bruce", "M.Kemp", "D.Espinosa", "C.Pena", "R.Howard", "N.Cruz", "D.Fowler" );
leaderTeam10 = new Array( "CIN", "SFN", "ATN", "CIN", "LAN", "WAN", "LAN", "PHN", "SDN", "WAN" );
leaderData10 = new Array( "197", "170", "169", "169", "168", "168", "163", "158", "141", "141" );

leaderName11 = new Array( "D.Espinosa", "C.Utley", "J.Upton", "C.Quentin", "A.Rowand", "J.Willingham", "N.Morgan", "P.Fielder", "M.Byrd", "E.Aybar" );
leaderTeam11 = new Array( "WAN", "PHN", "WAN", "HON", "WAN", "SFN", "***", "WAN", "CHN", "SLN" );
leaderData11 = new Array( "21", "17", "17", "16", "16", "14", "13", "13", "11", "11" );

leaderName12 = new Array( "A.Torres", "K.Fukudome", "J.Carroll", "C.Maybin", "E.Aybar", "D.Descalso", "C.Denorfia", "O.Infante", "D.Espinosa", "J.Rollins" );
leaderTeam12 = new Array( "NYN", "NYN", "SDN", "SLN", "SLN", "SLN", "SDN", "ATN", "WAN", "PHN" );
leaderData12 = new Array( "28", "23", "21", "19", "18", "17", "17", "16", "16", "14" );

leaderName13 = new Array( "M.Bourn", "E.Andrus", "M.Kemp", "C.Maybin", "S.Castro", "E.Aybar", "M.Cabrera", "E.Bonifacio", "R.Davis", "D.Stubbs" );
leaderTeam13 = new Array( "HON", "WAN", "LAN", "SLN", "CHN", "SLN", "SFN", "ATN", "ATN", "CIN" );
leaderData13 = new Array( "79", "53", "50", "49", "43", "41", "40", "35", "34", "34" );

leaderName14 = new Array( "C.Gentry", "E.Bonifacio", "X.Paul", "T.Gwynn Jr", "H.Kendrick", "J.Rollins", "S.Castro", "J.Bartlett", "E.Aybar", "T.Campana" );
leaderTeam14 = new Array( "CHN", "ATN", "LAN", "PHN", "SFN", "PHN", "CHN", "CIN", "SLN", "CHN" );
leaderData14 = new Array( ".95", ".90", ".87", ".87", ".86", ".85", ".83", ".83", ".82", ".81" );

leaderName15 = new Array( "A.Pujols", "M.Young", "M.Cabrera", "S.Castro", "M.Joyce", "E.Encarnacion", "M.Montero", "J.Hamilton", "M.Stanton", "H.Pence" );
leaderTeam15 = new Array( "PIN", "PHN", "SLN", "CHN", "CHN", "LAN", "WAN", "ATN", "ATN", "HON" );
leaderData15 = new Array( "29", "28", "25", "24", "22", "22", "22", "21", "21", "21" );

leaderName16 = new Array( "M.Byrd", "A.Callaspo", "E.Bonifacio", "S.Castro", "D.Stubbs", "M.Olivo", "H.Pence", "E.Aybar", "E.Andrus", "O.Infante" );
leaderTeam16 = new Array( "CHN", "CHN", "ATN", "CHN", "CIN", "HON", "HON", "SLN", "WAN", "ATN" );
leaderData16 = new Array( "8", "8", "6", "6", "6", "6", "6", "6", "6", "5" );

leaderName17 = new Array( "J.Constanza", "R.Doumit", "G.Jones", "", "", "", "", "", "", "" );
leaderTeam17 = new Array( "CIN", "PIN", "PIN", "", "", "", "", "", "", "" );
leaderData17 = new Array( ".429", ".192", ".190", "0", "0", "0", "0", "0", "0", "0" );

leaderName18 = new Array( "A.Pujols", "M.Kemp", "H.Pence", "J.Bautista", "F.Freeman", "P.Fielder", "J.Votto", "M.Stanton", "M.Cabrera", "M.Joyce" );
leaderTeam18 = new Array( "PIN", "LAN", "HON", "PHN", "ATN", "WAN", "CIN", "ATN", "SLN", "CHN" );
leaderData18 = new Array( ".604", ".577", ".571", ".566", ".555", ".545", ".539", ".531", ".526", ".511" );

leaderName19 = new Array( "J.Bautista", "J.Votto", "H.Pence", "M.Cabrera", "M.Kemp", "V.Martinez", "F.Freeman", "M.Bourn", "P.Fielder", "Y.Escobar" );
leaderTeam19 = new Array( "PHN", "CIN", "HON", "SLN", "LAN", "PHN", "ATN", "HON", "WAN", "ATN" );
leaderData19 = new Array( ".427", ".412", ".412", ".408", ".399", ".397", ".378", ".376", ".376", ".375" );

leaderName20 = new Array( "J.Bautista", "H.Pence", "M.Kemp", "J.Votto", "F.Freeman", "M.Cabrera", "V.Martinez", "P.Fielder", "A.Pujols", "S.Victorino" );
leaderTeam20 = new Array( "PHN", "HON", "LAN", "CIN", "ATN", "SLN", "PHN", "WAN", "PIN", "PHN" );
leaderData20 = new Array( " 9.7", " 8.7", " 8.5", " 8.4", " 7.9", " 7.7", " 7.4", " 7.2", " 6.9", " 6.5" );

leaderName21 = new Array( "J.Bautista", "M.Kemp", "J.Votto", "H.Pence", "M.Cabrera", "F.Freeman", "A.Pujols", "P.Fielder", "M.Bourn", "S.Victorino" );
leaderTeam21 = new Array( "PHN", "LAN", "CIN", "HON", "SLN", "ATN", "PIN", "WAN", "HON", "PHN" );
leaderData21 = new Array( "1.127", "1.086", "1.018", ".993", ".948", ".935", ".929", ".918", ".889", ".878" );

leaderName22 = new Array( "M.Kemp", "H.Pence", "A.Pujols", "F.Freeman", "J.Votto", "M.Cabrera", "P.Fielder", "M.Cabrera", "M.Young", "J.Bautista" );
leaderTeam22 = new Array( "LAN", "HON", "PIN", "ATN", "CIN", "SLN", "WAN", "SFN", "PHN", "PHN" );
leaderData22 = new Array( "359", "348", "330", "326", "321", "307", "306", "305", "296", "293" );

leaderName23 = new Array( "H.Pence", "J.Sands", "E.Bonifacio", "J.Lowrie", "C.Headley", "J.Carroll", "A.Ramirez", "R.Zimmerman", "M.Kemp", "A.Soriano" );
leaderTeam23 = new Array( "HON", "LAN", "ATN", "SLN", "ATN", "SDN", "CHN", "WAN", "LAN", "CHN" );
leaderData23 = new Array( ".400", ".374", ".364", ".350", ".347", ".344", ".344", ".343", ".340", ".339" );

leaderName24 = new Array( "G.Soto", "M.Kemp", "J.Bautista", "J.Upton", "H.Pence", "A.Ellis", "F.Freeman", "J.Bruce", "J.Rollins", "M.Stanton" );
leaderTeam24 = new Array( "CHN", "LAN", "PHN", "WAN", "HON", "LAN", "ATN", "CIN", "PHN", "ATN" );
leaderData24 = new Array( "13", "12", "12", "12", "11", "11", "10", "10", "10", "9" );

leaderName25 = new Array( "P.Sandoval", "V.Martinez", "E.Aybar", "M.Bourn", "F.Freeman", "M.Cabrera", "M.Young", "H.Pence", "D.Murphy", "J.Loney" );
leaderTeam25 = new Array( "SFN", "PHN", "SLN", "HON", "ATN", "SLN", "PHN", "HON", "NYN", "LAN" );
leaderData25 = new Array( ".381", ".371", ".345", ".339", ".339", ".336", ".333", ".330", ".325", ".323" );

leaderName26 = new Array( "A.Pujols", "J.Votto", "P.Fielder", "J.Bruce", "M.Kemp", "J.Bautista", "M.Stanton", "R.Howard", "M.Cabrera", "J.Willingham" );
leaderTeam26 = new Array( "PIN", "CIN", "WAN", "CIN", "LAN", "PHN", "ATN", "PHN", "SLN", "SFN" );
leaderData26 = new Array( "38", "28", "28", "26", "26", "26", "24", "23", "23", "23" );

leaderName27 = new Array( "I.Kennedy", "C.Lee", "C.Hamels", "T.Hudson", "J.Vazquez", "J.Tomlin", "D.Holland", "K.Lohse", "T.Hanson", "R.Oswalt" );
leaderTeam27 = new Array( "PHN", "PHN", "PHN", "ATN", "ATN", "CHN", "ATN", "SLN", "ATN", "HON" );
leaderData27 = new Array( "20", "20", "19", "18", "16", "16", "15", "15", "14", "14" );

leaderName28 = new Array( "T.Stauffer", "Y.Gallardo", "C.Billingsley", "E.Jackson", "B.Colon", "B.Arroyo", "J.Chacin", "M.Pelfrey", "A.Harang", "R.Dempster" );
leaderTeam28 = new Array( "SDN", "HON", "LAN", "SDN", "SDN", "CIN", "HON", "PIN", "SDN", "CHN" );
leaderData28 = new Array( "19", "16", "16", "16", "15", "14", "14", "14", "14", "13" );

leaderName29 = new Array( "T.Hudson", "T.Hanson", "I.Kennedy", "J.Tomlin", "C.Hamels", "C.Lee", "C.Carrasco", "R.Oswalt", "J.Vazquez", "K.Lohse" );
leaderTeam29 = new Array( "ATN", "ATN", "PHN", "CHN", "PHN", "PHN", "CIN", "HON", "ATN", "SLN" );
leaderData29 = new Array( ".818", ".778", ".769", ".762", ".760", ".741", ".722", ".700", ".696", ".652" );

leaderName30 = new Array( "C.Hamels", "T.Lincecum", "C.Kershaw", "J.Tomlin", "T.Hudson", "K.Lohse", "G.Floyd", "J.Hellickson", "J.Vazquez", "M.Cain" );
leaderTeam30 = new Array( "PHN", "SFN", "LAN", "CHN", "ATN", "SLN", "SLN", "WAN", "ATN", "SFN" );
leaderData30 = new Array( " 2.68", " 2.71", " 2.81", " 2.97", " 3.00", " 3.12", " 3.14", " 3.14", " 3.21", " 3.26" );

leaderName31 = new Array( "C.Carpenter", "C.Kershaw", "C.Lee", "I.Kennedy", "D.Price", "C.Hamels", "M.Cain", "T.Lincecum", "T.Hudson", "E.Santana" );
leaderTeam31 = new Array( "LAN", "LAN", "PHN", "PHN", "HON", "PHN", "SFN", "SFN", "ATN", "HON" );
leaderData31 = new Array( "242.0", "240.1", "240.0", "229.1", "226.2", "225.1", "221.0", "216.0", "212.2", "206.1" );

leaderName32 = new Array( "C.Carpenter", "C.Kershaw", "C.Lee", "D.Price", "I.Kennedy", "M.Cain", "R.Dempster", "H.Kuroda", "C.Hamels", "T.Lincecum" );
leaderTeam32 = new Array( "LAN", "LAN", "PHN", "HON", "PHN", "SFN", "CHN", "LAN", "PHN", "SFN" );
leaderData32 = new Array( "1029", "1006", "976", "955", "931", "921", "906", "899", "899", "889" );

leaderName33 = new Array( "T.Gorzelanny", "C.Marmol", "D.Storen", "N.Masset", "J.Venters", "G.Balfour", "S.Marshall", "C.Martinez", "J.Hanrahan", "J.Benoit" );
leaderTeam33 = new Array( "CHN", "CHN", "WAN", "CIN", "ATN", "HON", "SLN", "ATN", "PIN", "HON" );
leaderData33 = new Array( "67", "62", "61", "60", "56", "55", "55", "54", "54", "53" );

leaderName34 = new Array( "D.Price", "C.Carpenter", "T.Hudson", "R.Dempster", "Y.Gallardo", "E.Santana", "C.Kershaw", "H.Kuroda", "M.Scherzer", "D.Holland" );
leaderTeam34 = new Array( "HON", "LAN", "ATN", "CHN", "HON", "HON", "LAN", "LAN", "***", "ATN" );
leaderData34 = new Array( "34", "34", "33", "33", "33", "33", "33", "33", "33", "32" );

leaderName35 = new Array( "C.Carpenter", "C.Lee", "C.Hamels", "I.Kennedy", "T.Lincecum", "C.Kershaw", "M.Cain", "J.Reyes", "R.Dempster", "J.Collmenter" );
leaderTeam35 = new Array( "LAN", "PHN", "PHN", "PHN", "SFN", "LAN", "SFN", "SFN", "CHN", "CHN" );
leaderData35 = new Array( "12", "12", "10", "10", "10", "9", "9", "8", "7", "7" );

leaderName36 = new Array( "D.Storen", "J.Hanrahan", "C.Kimbrel", "C.Marmol", "F.Rodriguez", "J.Valverde", "J.Putz", "J.Axford", "H.Takahashi", "J.Venters" );
leaderTeam36 = new Array( "WAN", "PIN", "ATN", "CHN", "NYN", "SDN", "HON", "LAN", "CIN", "ATN" );
leaderData36 = new Array( "53", "47", "45", "44", "39", "39", "38", "38", "36", "30" );

leaderName37 = new Array( "J.Putz", "C.Kimbrel", "F.Rodriguez", "J.Hanrahan", "C.Marmol", "J.Valverde", "D.Storen", "J.Axford", "J.Venters", "J.Motte" );
leaderTeam37 = new Array( "HON", "ATN", "NYN", "PIN", "CHN", "SDN", "WAN", "LAN", "ATN", "SLN" );
leaderData37 = new Array( "32", "31", "30", "29", "27", "26", "26", "20", "19", "16" );

leaderName38 = new Array( "C.Marmol", "J.Putz", "R.Betancourt", "J.Valverde", "B.Wilson", "J.Venters", "C.Kimbrel", "F.Rodriguez", "J.Hanrahan", "A.Bastardo" );
leaderTeam38 = new Array( "CHN", "HON", "SFN", "SDN", "SFN", "ATN", "ATN", "NYN", "PIN", "PHN" );
leaderData38 = new Array( ".900", ".889", ".882", ".867", ".867", ".864", ".861", ".833", ".829", ".789" );

leaderName39 = new Array( "C.Carpenter", "Y.Gallardo", "C.Kershaw", "C.Lee", "K.Lohse", "T.Lincecum", "J.Hellickson", "D.Holland", "J.Tomlin", "J.Collmenter" );
leaderTeam39 = new Array( "LAN", "HON", "LAN", "PHN", "SLN", "SFN", "WAN", "ATN", "CHN", "CHN" );
leaderData39 = new Array( "3", "2", "2", "2", "2", "2", "2", "1", "1", "1" );

leaderName40 = new Array( "C.Carpenter", "M.Pelfrey", "R.Dempster", "H.Kuroda", "C.Billingsley", "C.Lee", "J.Saunders", "M.Bumgarner", "D.Price", "E.Jackson" );
leaderTeam40 = new Array( "LAN", "PIN", "CHN", "LAN", "LAN", "PHN", "WAN", "SFN", "HON", "SDN" );
leaderData40 = new Array( "250", "242", "238", "225", "222", "222", "219", "218", "213", "212" );

leaderName41 = new Array( "C.Billingsley", "R.Dempster", "E.Jackson", "M.Pelfrey", "H.Kuroda", "J.McDonald", "J.Saunders", "B.Arroyo", "C.Morton", "B.Penny" );
leaderTeam41 = new Array( "LAN", "CHN", "SDN", "PIN", "LAN", "PIN", "WAN", "CIN", "PIN", "CIN" );
leaderData41 = new Array( "144", "131", "125", "118", "116", "115", "114", "113", "109", "108" );

leaderName42 = new Array( "C.Billingsley", "R.Dempster", "E.Jackson", "M.Pelfrey", "B.Penny", "J.McDonald", "B.Arroyo", "H.Kuroda", "C.Morton", "J.Reyes" );
leaderTeam42 = new Array( "LAN", "CHN", "SDN", "PIN", "CIN", "PIN", "CIN", "LAN", "PIN", "SFN" );
leaderData42 = new Array( "124", "122", "116", "111", "107", "106", "105", "102", "101", "101" );

leaderName43 = new Array( "B.Arroyo", "Y.Gallardo", "J.Saunders", "C.Lee", "R.Wolf", "B.Norris", "B.Penny", "H.Kuroda", "J.Vazquez", "E.Santana" );
leaderTeam43 = new Array( "CIN", "HON", "WAN", "PHN", "LAN", "WAN", "CIN", "LAN", "ATN", "HON" );
leaderData43 = new Array( "42", "33", "31", "30", "29", "28", "27", "27", "26", "25" );

leaderName44 = new Array( "R.Dempster", "J.Chacin", "J.McDonald", "J.Saunders", "R.Dickey", "C.Morton", "C.Narveson", "B.Norris", "D.Price", "C.Billingsley" );
leaderTeam44 = new Array( "CHN", "HON", "PIN", "WAN", "NYN", "PIN", "CIN", "WAN", "HON", "LAN" );
leaderData44 = new Array( "107", "97", "89", "87", "85", "85", "83", "83", "82", "80" );

leaderName45 = new Array( "C.Kershaw", "C.Lee", "D.Price", "I.Kennedy", "T.Lincecum", "C.Hamels", "M.Bumgarner", "M.Garza", "Y.Gallardo", "M.Cain" );
leaderTeam45 = new Array( "LAN", "PHN", "HON", "PHN", "SFN", "PHN", "SFN", "NYN", "HON", "SFN" );
leaderData45 = new Array( "278", "248", "219", "219", "219", "206", "205", "190", "185", "184" );

leaderName46 = new Array( "C.Morton", "Y.Gallardo", "H.Kuroda", "J.Hanrahan", "T.Lincecum", "J.Reyes", "T.Hudson", "B.Penny", "M.Scherzer", "J.Garcia" );
leaderTeam46 = new Array( "PIN", "HON", "LAN", "PIN", "SFN", "SFN", "ATN", "CIN", "***", "SLN" );
leaderData46 = new Array( "17", "12", "12", "11", "11", "11", "10", "10", "10", "10" );

leaderName47 = new Array( "C.Hamels", "J.Grabow", "C.Luebke", "J.Jurrjens", "J.Collmenter", "N.Masset", "R.Wolf", "B.Parnell", "V.Worley", "C.Morton" );
leaderTeam47 = new Array( "PHN", "SDN", "ATN", "WAN", "CHN", "CIN", "LAN", "NYN", "PHN", "PIN" );
leaderData47 = new Array( "7", "5", "4", "4", "3", "3", "3", "3", "3", "3" );

leaderName48 = new Array( "M.Leake", "C.Kershaw", "H.Kuroda", "I.Kennedy", "A.Ogando", "K.Lohse", "F.Carmona", "J.Hellickson", "J.Saunders", "T.Hudson" );
leaderTeam48 = new Array( "CIN", "LAN", "LAN", "PHN", "PHN", "SLN", "SLN", "WAN", "WAN", "ATN" );
leaderData48 = new Array( "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", ".88" );

leaderName49 = new Array( "M.Pelfrey", "C.Hamels", "E.Jackson", "T.Hudson", "E.Santana", "D.Moseley", "T.Hanson", "T.Lincecum", "R.Dempster", "C.Morton" );
leaderTeam49 = new Array( "PIN", "PHN", "SDN", "ATN", "HON", "CHN", "ATN", "SFN", "CHN", "PIN" );
leaderData49 = new Array( "49", "43", "38", "33", "33", "31", "29", "29", "24", "24" );

leaderName50 = new Array( "C.Lee", "D.Price", "N.Blackburn", "J.Reyes", "B.Penny", "H.Bailey", "N.Masset", "T.Hanson", "B.Arroyo", "B.Beachy" );
leaderTeam50 = new Array( "PHN", "HON", "SDN", "SFN", "CIN", "CIN", "CIN", "ATN", "CIN", "ATN" );
leaderData50 = new Array( ".54", ".65", ".67", ".67", ".70", ".71", ".71", ".73", ".74", ".75" );

leaderName51 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderTeam51 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderData51 = new Array( "", "", "", "", "", "", "", "", "", "" );

leaderName52 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderTeam52 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderData52 = new Array( "", "", "", "", "", "", "", "", "", "" );

leaderName53 = new Array( "G.Floyd", "T.Lincecum", "J.Hellickson", "I.Kennedy", "M.Cain", "C.Hamels", "C.Kershaw", "J.Chacin", "J.Vazquez", "A.Ogando" );
leaderTeam53 = new Array( "SLN", "SFN", "WAN", "PHN", "SFN", "PHN", "LAN", "HON", "ATN", "PHN" );
leaderData53 = new Array( " 7.0", " 7.1", " 7.2", " 7.5", " 7.7", " 7.7", " 7.8", " 7.8", " 7.9", " 8.0" );

leaderName54 = new Array( "J.Tomlin", "B.Arroyo", "C.Hamels", "C.Lee", "M.Leake", "C.Carpenter", "G.Floyd", "H.Kuroda", "J.Vazquez", "M.Garza" );
leaderTeam54 = new Array( "CHN", "CIN", "PHN", "PHN", "CIN", "LAN", "SLN", "LAN", "ATN", "NYN" );
leaderData54 = new Array( " 1.7", " 1.8", " 2.0", " 2.1", " 2.2", " 2.2", " 2.3", " 2.3", " 2.3", " 2.3" );

leaderName55 = new Array( "C.Kershaw", "C.Lee", "M.Bumgarner", "T.Lincecum", "M.Garza", "D.Price", "I.Kennedy", "B.Norris", "Y.Gallardo", "C.Hamels" );
leaderTeam55 = new Array( "LAN", "PHN", "SFN", "SFN", "NYN", "HON", "PHN", "WAN", "HON", "PHN" );
leaderData55 = new Array( "10.4", " 9.3", " 9.2", " 9.1", " 9.1", " 8.7", " 8.6", " 8.4", " 8.3", " 8.2" );

leaderName56 = new Array( "R.Dickey", "J.Hellickson", "C.Carpenter", "M.Cain", "T.Lincecum", "M.Bumgarner", "K.Lohse", "A.Ogando", "E.Jackson", "C.Hamels" );
leaderTeam56 = new Array( "NYN", "WAN", "LAN", "SFN", "SFN", "SFN", "SLN", "PHN", "SDN", "PHN" );
leaderData56 = new Array( " 0.50", " 0.57", " 0.63", " 0.73", " 0.75", " 0.76", " 0.78", " 0.80", " 0.83", " 0.84" );

