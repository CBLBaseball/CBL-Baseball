leaderName0 = new Array( "A.Gonzalez", "V.Guerrero", "J.Reyes", "J.Ellsbury", "R.Braun", "M.Morse", "R.Cano", "E.Hosmer", "C.Gonzalez", "D.Ortiz" );
leaderTeam0 = new Array( "BAA", "BAA", "TOA", "BOA", "CHA", "BOA", "NYA", "KCA", "OAA", "BOA" );
leaderData0 = new Array( ".363", ".336", ".328", ".315", ".315", ".313", ".310", ".307", ".307", ".307" );

leaderName1 = new Array( "J.Ellsbury", "D.Pedroia", "A.Gonzalez", "N.Markakis", "A.Ramirez", "R.Cano", "A.Gordon", "J.Francoeur", "I.Suzuki", "T.Hunter" );
leaderTeam1 = new Array( "BOA", "BOA", "BAA", "BAA", "CHA", "NYA", "KCA", "KCA", "SEA", "LAA" );
leaderData1 = new Array( "686", "657", "652", "642", "639", "629", "627", "621", "598", "597" );

leaderName2 = new Array( "J.Ellsbury", "D.Pedroia", "A.Gonzalez", "M.Teixeira", "I.Kinsler", "R.Braun", "A.Ramirez", "A.Gordon", "R.Cano", "C.Granderson" );
leaderTeam2 = new Array( "BOA", "BOA", "BAA", "NYA", "TOA", "CHA", "CHA", "KCA", "NYA", "DEA" );
leaderData2 = new Array( "141", "108", "105", "105", "104", "101", "99", "98", "98", "97" );

leaderName3 = new Array( "A.Gonzalez", "J.Ellsbury", "R.Cano", "V.Guerrero", "D.Pedroia", "R.Braun", "A.Ramirez", "J.Reyes", "M.Morse", "J.Francoeur" );
leaderTeam3 = new Array( "BAA", "BOA", "NYA", "BAA", "BOA", "CHA", "CHA", "TOA", "BOA", "KCA" );
leaderData3 = new Array( "237", "216", "195", "193", "192", "185", "173", "171", "170", "170" );

leaderName4 = new Array( "J.Ellsbury", "A.Gonzalez", "D.Pedroia", "J.Francoeur", "R.Cano", "A.Gordon", "K.Youkilis", "B.Butler", "I.Kinsler", "M.Wieters" );
leaderTeam4 = new Array( "BOA", "BAA", "BOA", "KCA", "NYA", "KCA", "BOA", "KCA", "TOA", "BAA" );
leaderData4 = new Array( "56", "52", "49", "45", "45", "43", "40", "40", "40", "37" );

leaderName5 = new Array( "J.Reyes", "B.Gardner", "P.Bourjos", "C.Granderson", "H.Quintero", "M.Cuddyer", "J.Ellsbury", "C.Beltran", "A.Jackson", "J.Damon" );
leaderTeam5 = new Array( "TOA", "NYA", "CLA", "DEA", "KCA", "MNA", "BOA", "CLA", "DEA", "NYA" );
leaderData5 = new Array( "17", "11", "10", "10", "9", "9", "8", "8", "8", "8" );

leaderName6 = new Array( "M.Teixeira", "M.Reynolds", "D.Uggla", "C.Granderson", "A.Gonzalez", "J.Ellsbury", "M.Morse", "R.Braun", "L.Berkman", "R.Cano" );
leaderTeam6 = new Array( "NYA", "BAA", "LAA", "DEA", "BAA", "BOA", "BOA", "CHA", "SEA", "NYA" );
leaderData6 = new Array( "46", "42", "38", "36", "35", "34", "34", "33", "33", "31" );

leaderName7 = new Array( "M.Teixeira", "R.Braun", "A.Gonzalez", "C.Granderson", "R.Cano", "M.Reynolds", "J.Ellsbury", "M.Morse", "P.Konerko", "E.Hosmer" );
leaderTeam7 = new Array( "NYA", "CHA", "BAA", "DEA", "NYA", "BAA", "BOA", "BOA", "CHA", "KCA" );
leaderData7 = new Array( "133", "122", "120", "107", "102", "99", "97", "95", "95", "94" );

leaderName8 = new Array( "C.Santana", "D.Pedroia", "L.Berkman", "C.Granderson", "C.Beltran", "M.Teixeira", "B.Abreu", "I.Kinsler", "M.Wieters", "M.Holliday" );
leaderTeam8 = new Array( "CLA", "BOA", "SEA", "DEA", "CLA", "NYA", "NYA", "TOA", "BAA", "LAA" );
leaderData8 = new Array( "100", "90", "87", "86", "79", "77", "76", "76", "75", "73" );

leaderName9 = new Array( "C.Gonzalez", "R.Cano", "J.Ellsbury", "L.Berkman", "A.Gonzalez", "M.Morse", "J.Weeks", "E.Hosmer", "H.Matsui", "J.Hardy" );
leaderTeam9 = new Array( "OAA", "NYA", "BOA", "SEA", "BAA", "BOA", "OAA", "KCA", "TOA", "BAA" );
leaderData9 = new Array( "20", "14", "13", "13", "12", "12", "11", "9", "9", "8" );

leaderName10 = new Array( "M.Reynolds", "C.Granderson", "A.Jackson", "A.Dunn", "A.Gordon", "A.Avila", "C.Young", "D.Uggla", "K.Johnson", "T.Hunter" );
leaderTeam10 = new Array( "BAA", "DEA", "DEA", "MNA", "KCA", "DEA", "BAA", "LAA", "BAA", "LAA" );
leaderData10 = new Array( "209", "201", "194", "179", "160", "152", "148", "138", "135", "128" );

leaderName11 = new Array( "M.Morse", "M.Izturis", "K.Youkilis", "J.Francoeur", "N.Morgan", "D.Jennings", "A.Cabrera", "C.Granderson", "M.Holliday", "M.Teixeira" );
leaderTeam11 = new Array( "BOA", "OAA", "BOA", "KCA", "***", "MNA", "CLA", "DEA", "LAA", "NYA" );
leaderData11 = new Array( "16", "16", "14", "13", "13", "12", "11", "11", "11", "11" );

leaderName12 = new Array( "B.Ryan", "A.Escobar", "J.Schafer", "A.Gonzalez", "A.Pagan", "R.Santiago", "J.Wilson", "A.Ramirez", "A.Jackson", "J.McDonald" );
leaderTeam12 = new Array( "SEA", "DEA", "***", "BOA", "KCA", "DEA", "KCA", "CHA", "DEA", "KCA" );
leaderData12 = new Array( "63", "40", "37", "30", "26", "21", "20", "19", "19", "19" );

leaderName13 = new Array( "C.Crisp", "B.Gardner", "J.Ellsbury", "J.Reyes", "P.Bourjos", "B.Revere", "I.Suzuki", "J.Weeks", "I.Kinsler", "D.Pedroia" );
leaderTeam13 = new Array( "NYA", "NYA", "BOA", "TOA", "CLA", "CLA", "SEA", "OAA", "TOA", "BOA" );
leaderData13 = new Array( "75", "65", "60", "47", "45", "44", "43", "38", "35", "32" );

leaderName14 = new Array( "H.Ramirez", "I.Suzuki", "E.Hosmer", "J.Reyes", "J.Ellsbury", "J.Schafer", "J.Francoeur", "K.Johnson", "C.Young", "C.Crisp" );
leaderTeam14 = new Array( "LAA", "SEA", "KCA", "TOA", "BOA", "***", "KCA", "BAA", "BAA", "NYA" );
leaderData14 = new Array( ".88", ".88", ".87", ".87", ".85", ".83", ".82", ".82", ".82", ".82" );

leaderName15 = new Array( "A.Gonzalez", "A.Pierzynski", "M.Wieters", "J.Francoeur", "M.Holliday", "M.Trumbo", "M.Cuddyer", "D.Ortiz", "R.Braun", "L.Overbay" );
leaderTeam15 = new Array( "BAA", "CHA", "BAA", "KCA", "LAA", "LAA", "MNA", "BOA", "CHA", "LAA" );
leaderData15 = new Array( "27", "24", "23", "23", "23", "23", "23", "21", "20", "20" );

leaderName16 = new Array( "R.Hernandez", "C.Gonzalez", "J.Weeks", "P.Goldschmidt", "D.Ackley", "A.Rodriguez", "B.Butler", "J.Francoeur", "A.Gordon", "E.Hosmer" );
leaderTeam16 = new Array( "***", "OAA", "OAA", "OAA", "SEA", "SEA", "KCA", "KCA", "KCA", "KCA" );
leaderData16 = new Array( "4", "3", "3", "3", "3", "3", "2", "2", "2", "2" );

leaderName17 = new Array( "A.Pagan", "Y.Torrealba", "M.Carp", "S.Sizemore", "L.Overbay", "", "", "", "", "" );
leaderTeam17 = new Array( "KCA", "SEA", "SEA", "DEA", "LAA", "", "", "", "", "" );
leaderData17 = new Array( ".348", ".320", ".286", ".222", ".083", "0", "0", "0", "0", "0" );

leaderName18 = new Array( "A.Gonzalez", "J.Ellsbury", "M.Morse", "R.Braun", "R.Cano", "C.Gonzalez", "L.Berkman", "C.Beltran", "M.Teixeira", "E.Hosmer" );
leaderTeam18 = new Array( "BAA", "BOA", "BOA", "CHA", "NYA", "OAA", "SEA", "CLA", "NYA", "KCA" );
leaderData18 = new Array( ".610", ".569", ".565", ".560", ".545", ".541", ".540", ".517", ".515", ".514" );

leaderName19 = new Array( "A.Gonzalez", "L.Berkman", "C.Beltran", "C.Kotchman", "B.Abreu", "C.Gonzalez", "D.Ortiz", "J.Ellsbury", "R.Braun", "M.Morse" );
leaderTeam19 = new Array( "BAA", "SEA", "CLA", "DEA", "NYA", "OAA", "BOA", "BOA", "CHA", "BOA" );
leaderData19 = new Array( ".420", ".402", ".392", ".383", ".383", ".381", ".381", ".380", ".378", ".377" );

leaderName20 = new Array( "A.Gonzalez", "J.Ellsbury", "L.Berkman", "M.Morse", "C.Gonzalez", "R.Braun", "J.Reyes", "C.Beltran", "R.Cano", "D.Ortiz" );
leaderTeam20 = new Array( "BAA", "BOA", "SEA", "BOA", "OAA", "CHA", "TOA", "CLA", "NYA", "BOA" );
leaderData20 = new Array( " 9.5", " 8.7", " 8.4", " 8.1", " 7.8", " 7.4", " 7.4", " 7.3", " 7.2", " 6.9" );

leaderName21 = new Array( "J.Ellsbury", "A.Gonzalez", "L.Berkman", "C.Gonzalez", "R.Braun", "M.Morse", "J.Reyes", "C.Beltran", "I.Kinsler", "C.Granderson" );
leaderTeam21 = new Array( "BOA", "BAA", "SEA", "OAA", "CHA", "BOA", "TOA", "CLA", "TOA", "DEA" );
leaderData21 = new Array( "1.085", "1.052", "1.000", ".977", ".975", ".963", ".948", ".929", ".912", ".904" );

leaderName22 = new Array( "A.Gonzalez", "J.Ellsbury", "R.Cano", "R.Braun", "M.Morse", "M.Teixeira", "C.Granderson", "D.Pedroia", "I.Kinsler", "E.Hosmer" );
leaderTeam22 = new Array( "BAA", "BOA", "NYA", "CHA", "BOA", "NYA", "DEA", "BOA", "TOA", "KCA" );
leaderData22 = new Array( "398", "390", "343", "329", "307", "303", "302", "297", "293", "281" );

leaderName23 = new Array( "V.Guerrero", "R.Braun", "M.Wieters", "D.Ortiz", "A.Gonzalez", "P.Konerko", "D.Pedroia", "B.Boesch", "A.Huff", "B.Revere" );
leaderTeam23 = new Array( "BAA", "CHA", "BAA", "BOA", "BAA", "CHA", "BOA", "DEA", "CLA", "CLA" );
leaderData23 = new Array( ".396", ".370", ".360", ".352", ".349", ".348", ".341", ".337", ".333", ".327" );

leaderName24 = new Array( "C.Young", "V.Wells", "R.Raburn", "M.Teixeira", "M.Reynolds", "I.Kinsler", "J.Francoeur", "M.Cameron", "M.Carp", "C.Gomez" );
leaderTeam24 = new Array( "BAA", "BOA", "DEA", "NYA", "BAA", "TOA", "KCA", "OAA", "SEA", "***" );
leaderData24 = new Array( "17", "13", "13", "13", "11", "11", "10", "10", "10", "9" );

leaderName25 = new Array( "A.Gonzalez", "M.Brantley", "R.Cano", "J.Reyes", "C.Gonzalez", "J.Ellsbury", "W.Betemit", "M.Morse", "C.Beltran", "E.Hosmer" );
leaderTeam25 = new Array( "BAA", "CLA", "NYA", "TOA", "OAA", "BOA", "DEA", "BOA", "CLA", "KCA" );
leaderData25 = new Array( ".372", ".343", ".335", ".329", ".324", ".323", ".321", ".316", ".313", ".312" );

leaderName26 = new Array( "M.Teixeira", "A.Gonzalez", "M.Reynolds", "D.Uggla", "J.Ellsbury", "L.Berkman", "M.Morse", "C.Granderson", "R.Braun", "M.Napoli" );
leaderTeam26 = new Array( "NYA", "BAA", "BAA", "LAA", "BOA", "SEA", "BOA", "DEA", "CHA", "LAA" );
leaderData26 = new Array( "33", "32", "31", "29", "28", "28", "27", "27", "25", "25" );

leaderName27 = new Array( "F.Hernandez", "J.Shields", "D.Haren", "D.Fister", "J.Beckett", "R.Romero", "J.Verlander", "M.Harrison", "R.Halladay", "C.Sabathia" );
leaderTeam27 = new Array( "SEA", "MNA", "OAA", "SEA", "BOA", "TOA", "DEA", "BOA", "CHA", "CLA" );
leaderData27 = new Array( "21", "19", "19", "19", "18", "17", "16", "15", "15", "15" );

leaderName28 = new Array( "B.Myers", "J.Vargas", "J.Lackey", "C.Pavano", "A.Burnett", "C.Lewis", "C.Volstad", "R.Nolasco", "T.Cahill", "R.Porcello" );
leaderTeam28 = new Array( "KCA", "MNA", "LAA", "MNA", "NYA", "TOA", "TOA", "NYA", "OAA", "DEA" );
leaderData28 = new Array( "20", "17", "16", "16", "16", "16", "16", "15", "15", "14" );

leaderName29 = new Array( "D.Fister", "J.Pineiro", "J.Beckett", "F.Hernandez", "E.Bedard", "M.Harrison", "B.Morrow", "D.Haren", "Z.Greinke", "J.Shields" );
leaderTeam29 = new Array( "SEA", "SEA", "BOA", "SEA", "BOA", "BOA", "SEA", "OAA", "KCA", "MNA" );
leaderData29 = new Array( ".826", ".800", ".783", ".778", ".733", ".714", ".706", ".679", ".667", ".655" );

leaderName30 = new Array( "D.Fister", "D.Haren", "J.Verlander", "J.Karstens", "J.Beckett", "T.Lilly", "B.Morrow", "J.Weaver", "S.Marcum", "P.Humber" );
leaderTeam30 = new Array( "SEA", "OAA", "DEA", "OAA", "BOA", "KCA", "SEA", "LAA", "CLA", "CHA" );
leaderData30 = new Array( " 1.91", " 2.11", " 2.34", " 2.35", " 2.92", " 3.13", " 3.18", " 3.21", " 3.22", " 3.33" );

leaderName31 = new Array( "J.Verlander", "D.Haren", "J.Weaver", "R.Halladay", "F.Hernandez", "C.Sabathia", "J.Shields", "D.Fister", "C.Wilson", "R.Romero" );
leaderTeam31 = new Array( "DEA", "OAA", "LAA", "CHA", "SEA", "CLA", "MNA", "SEA", "CLA", "TOA" );
leaderData31 = new Array( "257.2", "247.1", "246.2", "244.1", "244.1", "234.2", "232.2", "226.1", "223.1", "219.1" );

leaderName32 = new Array( "J.Weaver", "R.Halladay", "F.Hernandez", "J.Verlander", "C.Sabathia", "J.Shields", "C.Pavano", "D.Haren", "J.Masterson", "B.Myers" );
leaderTeam32 = new Array( "LAA", "CHA", "SEA", "DEA", "CLA", "MNA", "MNA", "OAA", "CLA", "KCA" );
leaderData32 = new Array( "1035", "1014", "1009", "1001", "989", "980", "978", "961", "929", "908" );

leaderName33 = new Array( "J.Karstens", "A.Aceves", "N.Feliz", "J.Papelbon", "J.Johnson", "B.League", "D.Hernandez", "M.Rzepczynski", "C.Sale", "B.Ziegler" );
leaderTeam33 = new Array( "OAA", "BOA", "BAA", "BOA", "BAA", "SEA", "BAA", "***", "CHA", "BAA" );
leaderData33 = new Array( "75", "68", "62", "61", "60", "59", "58", "57", "53", "52" );

leaderName34 = new Array( "M.Scherzer", "C.Sabathia", "J.Verlander", "B.Myers", "J.Weaver", "F.Hernandez", "U.Jimenez", "R.Halladay", "D.Hudson", "C.Wilson" );
leaderTeam34 = new Array( "***", "CLA", "DEA", "KCA", "LAA", "SEA", "BAA", "CHA", "CLA", "CLA" );
leaderData34 = new Array( "33", "33", "33", "33", "33", "33", "32", "32", "32", "32" );

leaderName35 = new Array( "J.Verlander", "D.Haren", "D.Fister", "R.Halladay", "T.Lilly", "F.Hernandez", "J.Danks", "J.Shields", "J.Westbrook", "J.Weaver" );
leaderTeam35 = new Array( "DEA", "OAA", "SEA", "CHA", "KCA", "SEA", "CHA", "MNA", "***", "LAA" );
leaderData35 = new Array( "13", "11", "10", "9", "9", "9", "8", "8", "7", "7" );

leaderName36 = new Array( "J.Papelbon", "J.Karstens", "N.Feliz", "F.Francisco", "B.League", "M.Melancon", "B.Fuentes", "S.Santos", "M.Rivera", "C.Perez" );
leaderTeam36 = new Array( "BOA", "OAA", "BAA", "DEA", "SEA", "KCA", "LAA", "TOA", "NYA", "CLA" );
leaderData36 = new Array( "56", "56", "54", "49", "49", "42", "41", "41", "40", "35" );

leaderName37 = new Array( "J.Papelbon", "B.League", "N.Feliz", "F.Francisco", "S.Santos", "M.Rivera", "H.Street", "C.Perez", "M.Melancon", "B.Fuentes" );
leaderTeam37 = new Array( "BOA", "SEA", "BAA", "DEA", "TOA", "NYA", "OAA", "CLA", "KCA", "LAA" );
leaderData37 = new Array( "47", "37", "36", "34", "32", "28", "26", "24", "24", "24" );

leaderName38 = new Array( "M.Rivera", "H.Street", "M.Melancon", "J.Papelbon", "S.Santos", "B.League", "N.Feliz", "B.Fuentes", "C.Sale", "F.Francisco" );
leaderTeam38 = new Array( "NYA", "OAA", "KCA", "BOA", "TOA", "SEA", "BAA", "LAA", "CHA", "DEA" );
leaderData38 = new Array( ".933", ".897", ".889", ".870", ".865", ".822", ".800", ".774", ".765", ".756" );

leaderName39 = new Array( "J.Verlander", "D.Fister", "J.Beckett", "R.Halladay", "B.Myers", "D.Haren", "F.Hernandez", "S.Marcum", "C.Wilson", "U.Jimenez" );
leaderTeam39 = new Array( "DEA", "SEA", "BOA", "CHA", "KCA", "OAA", "SEA", "CLA", "CLA", "BAA" );
leaderData39 = new Array( "5", "5", "4", "3", "3", "3", "3", "2", "2", "1" );

leaderName40 = new Array( "C.Pavano", "J.Vargas", "R.Halladay", "C.Sabathia", "J.Shields", "F.Hernandez", "D.Hudson", "B.Myers", "J.Lackey", "J.Weaver" );
leaderTeam40 = new Array( "MNA", "MNA", "CHA", "CLA", "MNA", "SEA", "CLA", "KCA", "LAA", "LAA" );
leaderData40 = new Array( "261", "253", "250", "234", "231", "225", "222", "222", "221", "219" );

leaderName41 = new Array( "A.Burnett", "T.Cahill", "B.Myers", "J.Lackey", "R.Nolasco", "C.Pavano", "J.Vargas", "A.Sanchez", "M.Buehrle", "M.Latos" );
leaderTeam41 = new Array( "NYA", "OAA", "KCA", "LAA", "NYA", "MNA", "MNA", "LAA", "CHA", "BAA" );
leaderData41 = new Array( "138", "135", "131", "130", "126", "122", "119", "118", "115", "111" );

leaderName42 = new Array( "B.Myers", "A.Burnett", "T.Cahill", "J.Lackey", "R.Nolasco", "C.Pavano", "J.Vargas", "J.Hammel", "U.Jimenez", "J.Francis" );
leaderTeam42 = new Array( "KCA", "NYA", "OAA", "LAA", "NYA", "MNA", "MNA", "NYA", "BAA", "DEA" );
leaderData42 = new Array( "126", "125", "119", "118", "116", "110", "110", "106", "104", "103" );

leaderName43 = new Array( "A.Burnett", "C.Volstad", "R.Romero", "C.Lewis", "A.Sanchez", "J.Verlander", "J.Shields", "L.Hochevar", "B.Myers", "J.Weaver" );
leaderTeam43 = new Array( "NYA", "TOA", "TOA", "TOA", "LAA", "DEA", "MNA", "KCA", "KCA", "LAA" );
leaderData43 = new Array( "42", "35", "33", "31", "30", "29", "29", "27", "27", "27" );

leaderName44 = new Array( "U.Jimenez", "E.Volquez", "J.Happ", "J.Weaver", "J.Lester", "T.Cahill", "B.Morrow", "J.Masterson", "G.Gonzalez", "C.Pavano" );
leaderTeam44 = new Array( "BAA", "LAA", "NYA", "LAA", "BOA", "OAA", "SEA", "CLA", "OAA", "MNA" );
leaderData44 = new Array( "86", "86", "86", "85", "83", "81", "81", "80", "79", "78" );

leaderName45 = new Array( "J.Verlander", "F.Hernandez", "J.Weaver", "C.Sabathia", "R.Halladay", "J.Shields", "G.Gonzalez", "J.Beckett", "Z.Greinke", "C.Wilson" );
leaderTeam45 = new Array( "DEA", "SEA", "LAA", "CLA", "CHA", "MNA", "OAA", "BOA", "KCA", "CLA" );
leaderData45 = new Array( "251", "233", "225", "216", "211", "209", "202", "201", "198", "194" );

leaderName46 = new Array( "T.Cahill", "A.Burnett", "I.Nova", "F.Liriano", "J.Lackey", "U.Jimenez", "M.Latos", "M.Scherzer", "M.Harrison", "F.Garcia" );
leaderTeam46 = new Array( "OAA", "NYA", "BAA", "MNA", "LAA", "BAA", "BAA", "***", "BOA", "CHA" );
leaderData46 = new Array( "24", "15", "13", "12", "11", "10", "10", "10", "10", "10" );

leaderName47 = new Array( "A.Sanchez", "C.Pavano", "R.Halladay", "M.Harrison", "T.Lilly", "M.Reynolds", "N.Feliz", "D.Hernandez", "F.Morales", "P.Humber" );
leaderTeam47 = new Array( "LAA", "MNA", "CHA", "BOA", "KCA", "LAA", "BAA", "BAA", "BOA", "CHA" );
leaderData47 = new Array( "7", "5", "4", "3", "3", "3", "2", "2", "2", "2" );

leaderName48 = new Array( "J.Danks", "C.Wilson", "J.Francis", "D.Haren", "C.Lewis", "Z.Greinke", "R.Halladay", "F.Hernandez", "S.Marcum", "C.Sabathia" );
leaderTeam48 = new Array( "CHA", "CLA", "DEA", "OAA", "TOA", "KCA", "CHA", "SEA", "CLA", "CLA" );
leaderData48 = new Array( "1.00", "1.00", "1.00", "1.00", "1.00", ".92", ".90", ".89", ".86", ".83" );

leaderName49 = new Array( "F.Hernandez", "D.Lowe", "T.Lilly", "J.Lackey", "E.Volquez", "T.Cahill", "F.Garcia", "A.Burnett", "J.Hammel", "C.Pavano" );
leaderTeam49 = new Array( "SEA", "TOA", "KCA", "LAA", "LAA", "OAA", "CHA", "NYA", "NYA", "MNA" );
leaderData49 = new Array( "67", "53", "49", "47", "47", "42", "38", "38", "36", "33" );

leaderName50 = new Array( "R.Romero", "W.Rodriguez", "R.Nolasco", "C.Lewis", "R.Porcello", "J.Masterson", "D.Hudson", "A.Sanchez", "J.Karstens", "J.Vargas" );
leaderTeam50 = new Array( "TOA", "LAA", "NYA", "TOA", "DEA", "CLA", "CLA", "LAA", "OAA", "MNA" );
leaderData50 = new Array( ".54", ".59", ".60", ".60", ".63", ".65", ".67", ".67", ".67", ".68" );

leaderName51 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderTeam51 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderData51 = new Array( "", "", "", "", "", "", "", "", "", "" );

leaderName52 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderTeam52 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderData52 = new Array( "", "", "", "", "", "", "", "", "", "" );

leaderName53 = new Array( "J.Verlander", "D.Fister", "B.Morrow", "J.Beckett", "C.Wilson", "M.Pineda", "D.Haren", "R.Romero", "J.Lester", "G.Gonzalez" );
leaderTeam53 = new Array( "DEA", "SEA", "SEA", "BOA", "CLA", "SEA", "OAA", "TOA", "BOA", "OAA" );
leaderData53 = new Array( " 5.9", " 6.2", " 6.3", " 6.6", " 6.7", " 6.8", " 7.5", " 7.5", " 7.5", " 7.9" );

leaderName54 = new Array( "D.Haren", "D.Fister", "R.Halladay", "B.McCarthy", "J.Beckett", "J.Danks", "S.Marcum", "D.Hudson", "J.Verlander", "R.Nolasco" );
leaderTeam54 = new Array( "OAA", "SEA", "CHA", "OAA", "BOA", "CHA", "CLA", "CLA", "DEA", "NYA" );
leaderData54 = new Array( " 1.1", " 1.2", " 1.8", " 2.0", " 2.0", " 2.1", " 2.1", " 2.2", " 2.2", " 2.4" );

leaderName55 = new Array( "Z.Greinke", "M.Pineda", "B.Morrow", "J.Beckett", "G.Gonzalez", "J.Verlander", "F.Hernandez", "C.Sabathia", "U.Jimenez", "J.Weaver" );
leaderTeam55 = new Array( "KCA", "SEA", "SEA", "BOA", "OAA", "DEA", "SEA", "CLA", "BAA", "LAA" );
leaderData55 = new Array( " 9.9", " 9.8", " 9.6", " 9.0", " 8.8", " 8.8", " 8.6", " 8.3", " 8.2", " 8.2" );

leaderName56 = new Array( "R.Halladay", "M.Harrison", "S.Marcum", "D.Fister", "D.Haren", "F.Hernandez", "C.Wilson", "R.Porcello", "P.Humber", "C.Sabathia" );
leaderTeam56 = new Array( "CHA", "BOA", "CLA", "SEA", "OAA", "SEA", "CLA", "DEA", "CHA", "CLA" );
leaderData56 = new Array( " 0.44", " 0.62", " 0.63", " 0.64", " 0.69", " 0.70", " 0.73", " 0.76", " 0.79", " 0.81" );

