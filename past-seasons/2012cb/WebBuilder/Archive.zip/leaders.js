leaderName0 = new Array( "A.Gonzalez", "H.Pence", "V.Martinez", "V.Guerrero", "J.Reyes", "M.Kemp", "M.Bourn", "M.Young", "F.Freeman", "M.Cabrera" );
leaderTeam0 = new Array( "BAA", "HON", "PHN", "BAA", "TOA", "LAN", "HON", "PHN", "ATN", "SLN" );
leaderData0 = new Array( ".363", ".345", ".341", ".336", ".328", ".325", ".324", ".324", ".319", ".317" );

leaderName1 = new Array( "J.Ellsbury", "S.Castro", "D.Pedroia", "M.Cabrera", "A.Gonzalez", "N.Markakis", "M.Bourn", "A.Ramirez", "M.Young", "B.Phillips" );
leaderTeam1 = new Array( "BOA", "CHN", "BOA", "SFN", "BAA", "BAA", "HON", "CHA", "PHN", "CIN" );
leaderData1 = new Array( "686", "663", "657", "657", "652", "642", "642", "639", "633", "630" );

leaderName2 = new Array( "J.Ellsbury", "J.Votto", "J.Bautista", "D.Pedroia", "M.Kemp", "A.Gonzalez", "M.Teixeira", "I.Kinsler", "R.Braun", "M.Bourn" );
leaderTeam2 = new Array( "BOA", "CIN", "PHN", "BOA", "LAN", "BAA", "NYA", "TOA", "CHA", "HON" );
leaderData2 = new Array( "141", "114", "112", "108", "108", "105", "105", "104", "101", "100" );

leaderName3 = new Array( "A.Gonzalez", "J.Ellsbury", "H.Pence", "M.Bourn", "M.Young", "M.Kemp", "M.Cabrera", "R.Cano", "V.Guerrero", "D.Pedroia" );
leaderTeam3 = new Array( "BAA", "BOA", "HON", "HON", "PHN", "LAN", "SFN", "NYA", "BAA", "BOA" );
leaderData3 = new Array( "237", "216", "210", "208", "205", "202", "196", "195", "193", "192" );

leaderName4 = new Array( "J.Ellsbury", "A.Gonzalez", "D.Pedroia", "M.Bourn", "M.Young", "J.Francoeur", "R.Cano", "M.Cabrera", "A.Gordon", "V.Martinez" );
leaderTeam4 = new Array( "BOA", "BAA", "BOA", "HON", "PHN", "KCA", "NYA", "SLN", "KCA", "PHN" );
leaderData4 = new Array( "56", "52", "49", "49", "49", "45", "45", "45", "43", "42" );

leaderName5 = new Array( "S.Victorino", "J.Reyes", "C.Maybin", "D.Fowler", "M.Bourn", "B.Gardner", "O.Infante", "M.Stanton", "P.Bourjos", "C.Granderson" );
leaderTeam5 = new Array( "PHN", "TOA", "SLN", "WAN", "HON", "NYA", "ATN", "ATN", "CLA", "DEA" );
leaderData5 = new Array( "20", "17", "13", "12", "11", "11", "10", "10", "10", "10" );

leaderName6 = new Array( "A.Pujols", "M.Teixeira", "M.Reynolds", "D.Uggla", "M.Kemp", "J.Bautista", "J.Bruce", "C.Granderson", "A.Gonzalez", "P.Fielder" );
leaderTeam6 = new Array( "PIN", "NYA", "BAA", "LAA", "LAN", "PHN", "CIN", "DEA", "BAA", "WAN" );
leaderData6 = new Array( "47", "46", "42", "38", "38", "38", "36", "36", "35", "35" );

leaderName7 = new Array( "M.Teixeira", "R.Braun", "J.Bautista", "A.Gonzalez", "A.Pujols", "H.Pence", "P.Fielder", "C.Granderson", "M.Stanton", "R.Howard" );
leaderTeam7 = new Array( "NYA", "CHA", "PHN", "BAA", "PIN", "HON", "WAN", "DEA", "ATN", "PHN" );
leaderData7 = new Array( "133", "122", "121", "120", "117", "110", "109", "107", "104", "103" );

leaderName8 = new Array( "J.Votto", "J.Bautista", "C.Santana", "C.Pena", "M.Cabrera", "D.Pedroia", "L.Berkman", "C.Granderson", "R.Howard", "B.Zobrist" );
leaderTeam8 = new Array( "CIN", "PHN", "CLA", "LAN", "SLN", "BOA", "SEA", "DEA", "PHN", "SLN" );
leaderData8 = new Array( "117", "117", "100", "92", "91", "90", "87", "86", "84", "84" );

leaderName9 = new Array( "C.Gonzalez", "V.Martinez", "H.Pence", "R.Cano", "J.Ellsbury", "M.Kemp", "M.Young", "L.Berkman", "A.Gonzalez", "M.Morse" );
leaderTeam9 = new Array( "OAA", "PHN", "HON", "NYA", "BOA", "LAN", "PHN", "SEA", "BAA", "BOA" );
leaderData9 = new Array( "20", "16", "14", "14", "13", "13", "13", "13", "12", "12" );

leaderName10 = new Array( "M.Reynolds", "C.Granderson", "D.Stubbs", "A.Jackson", "A.Dunn", "B.Upton", "M.Stanton", "J.Bruce", "M.Kemp", "D.Espinosa" );
leaderTeam10 = new Array( "BAA", "DEA", "CIN", "DEA", "MNA", "SFN", "ATN", "CIN", "LAN", "WAN" );
leaderData10 = new Array( "209", "201", "197", "194", "179", "170", "169", "169", "168", "168" );

leaderName11 = new Array( "D.Espinosa", "C.Utley", "J.Upton", "M.Morse", "C.Quentin", "M.Izturis", "A.Rowand", "K.Youkilis", "J.Willingham", "J.Francoeur" );
leaderTeam11 = new Array( "WAN", "PHN", "WAN", "BOA", "HON", "OAA", "WAN", "BOA", "SFN", "KCA" );
leaderData11 = new Array( "21", "17", "17", "16", "16", "16", "16", "14", "14", "13" );

leaderName12 = new Array( "B.Ryan", "A.Escobar", "J.Schafer", "A.Gonzalez", "A.Torres", "A.Pagan", "K.Fukudome", "R.Santiago", "J.Carroll", "J.Wilson" );
leaderTeam12 = new Array( "SEA", "DEA", "***", "BOA", "NYN", "KCA", "NYN", "DEA", "SDN", "KCA" );
leaderData12 = new Array( "63", "40", "37", "30", "28", "26", "23", "21", "21", "20" );

leaderName13 = new Array( "M.Bourn", "C.Crisp", "B.Gardner", "J.Ellsbury", "E.Andrus", "M.Kemp", "C.Maybin", "J.Reyes", "P.Bourjos", "B.Revere" );
leaderTeam13 = new Array( "HON", "NYA", "NYA", "BOA", "WAN", "LAN", "SLN", "TOA", "CLA", "CLA" );
leaderData13 = new Array( "79", "75", "65", "60", "53", "50", "49", "47", "45", "44" );

leaderName14 = new Array( "C.Gentry", "E.Bonifacio", "H.Ramirez", "I.Suzuki", "E.Hosmer", "X.Paul", "J.Reyes", "T.Gwynn Jr", "H.Kendrick", "J.Rollins" );
leaderTeam14 = new Array( "CHN", "ATN", "LAA", "SEA", "KCA", "LAN", "TOA", "PHN", "SFN", "PHN" );
leaderData14 = new Array( ".95", ".90", ".88", ".88", ".87", ".87", ".87", ".87", ".86", ".85" );

leaderName15 = new Array( "A.Pujols", "M.Young", "A.Gonzalez", "M.Cabrera", "A.Pierzynski", "S.Castro", "M.Wieters", "J.Francoeur", "M.Holliday", "M.Trumbo" );
leaderTeam15 = new Array( "PIN", "PHN", "BAA", "SLN", "CHA", "CHN", "BAA", "KCA", "LAA", "LAA" );
leaderData15 = new Array( "29", "28", "27", "25", "24", "24", "23", "23", "23", "23" );

leaderName16 = new Array( "M.Byrd", "A.Callaspo", "E.Bonifacio", "S.Castro", "D.Stubbs", "M.Olivo", "H.Pence", "E.Aybar", "E.Andrus", "O.Infante" );
leaderTeam16 = new Array( "CHN", "CHN", "ATN", "CHN", "CIN", "HON", "HON", "SLN", "WAN", "ATN" );
leaderData16 = new Array( "8", "8", "6", "6", "6", "6", "6", "6", "6", "5" );

leaderName17 = new Array( "J.Constanza", "A.Pagan", "Y.Torrealba", "M.Carp", "S.Sizemore", "R.Doumit", "G.Jones", "L.Overbay", "", "" );
leaderTeam17 = new Array( "CIN", "KCA", "SEA", "SEA", "DEA", "PIN", "PIN", "LAA", "", "" );
leaderData17 = new Array( ".429", ".348", ".320", ".286", ".222", ".192", ".190", ".083", "0", "0" );

leaderName18 = new Array( "A.Gonzalez", "A.Pujols", "M.Kemp", "H.Pence", "J.Ellsbury", "J.Bautista", "M.Morse", "R.Braun", "F.Freeman", "P.Fielder" );
leaderTeam18 = new Array( "BAA", "PIN", "LAN", "HON", "BOA", "PHN", "BOA", "CHA", "ATN", "WAN" );
leaderData18 = new Array( ".610", ".604", ".577", ".571", ".569", ".566", ".565", ".560", ".555", ".545" );

leaderName19 = new Array( "J.Bautista", "A.Gonzalez", "J.Votto", "H.Pence", "M.Cabrera", "L.Berkman", "M.Kemp", "V.Martinez", "C.Beltran", "C.Kotchman" );
leaderTeam19 = new Array( "PHN", "BAA", "CIN", "HON", "SLN", "SEA", "LAN", "PHN", "CLA", "DEA" );
leaderData19 = new Array( ".427", ".420", ".412", ".412", ".408", ".402", ".399", ".397", ".392", ".383" );

leaderName20 = new Array( "J.Bautista", "A.Gonzalez", "H.Pence", "J.Ellsbury", "M.Kemp", "L.Berkman", "J.Votto", "M.Morse", "F.Freeman", "C.Gonzalez" );
leaderTeam20 = new Array( "PHN", "BAA", "HON", "BOA", "LAN", "SEA", "CIN", "BOA", "ATN", "OAA" );
leaderData20 = new Array( " 9.7", " 9.5", " 8.7", " 8.7", " 8.5", " 8.4", " 8.4", " 8.1", " 7.9", " 7.8" );

leaderName21 = new Array( "J.Bautista", "M.Kemp", "J.Ellsbury", "A.Gonzalez", "J.Votto", "L.Berkman", "H.Pence", "C.Gonzalez", "R.Braun", "M.Morse" );
leaderTeam21 = new Array( "PHN", "LAN", "BOA", "BAA", "CIN", "SEA", "HON", "OAA", "CHA", "BOA" );
leaderData21 = new Array( "1.127", "1.086", "1.085", "1.052", "1.018", "1.000", ".993", ".977", ".975", ".963" );

leaderName22 = new Array( "A.Gonzalez", "J.Ellsbury", "M.Kemp", "H.Pence", "R.Cano", "A.Pujols", "R.Braun", "F.Freeman", "J.Votto", "M.Morse" );
leaderTeam22 = new Array( "BAA", "BOA", "LAN", "HON", "NYA", "PIN", "CHA", "ATN", "CIN", "BOA" );
leaderData22 = new Array( "398", "390", "359", "348", "343", "330", "329", "326", "321", "307" );

leaderName23 = new Array( "H.Pence", "V.Guerrero", "J.Sands", "R.Braun", "E.Bonifacio", "M.Wieters", "D.Ortiz", "J.Lowrie", "A.Gonzalez", "P.Konerko" );
leaderTeam23 = new Array( "HON", "BAA", "LAN", "CHA", "ATN", "BAA", "BOA", "SLN", "BAA", "CHA" );
leaderData23 = new Array( ".400", ".396", ".374", ".370", ".364", ".360", ".352", ".350", ".349", ".348" );

leaderName24 = new Array( "C.Young", "V.Wells", "G.Soto", "R.Raburn", "M.Teixeira", "M.Kemp", "J.Bautista", "J.Upton", "M.Reynolds", "H.Pence" );
leaderTeam24 = new Array( "BAA", "BOA", "CHN", "DEA", "NYA", "LAN", "PHN", "WAN", "BAA", "HON" );
leaderData24 = new Array( "17", "13", "13", "13", "13", "12", "12", "12", "11", "11" );

leaderName25 = new Array( "P.Sandoval", "A.Gonzalez", "V.Martinez", "E.Aybar", "M.Brantley", "M.Bourn", "F.Freeman", "M.Cabrera", "R.Cano", "M.Young" );
leaderTeam25 = new Array( "SFN", "BAA", "PHN", "SLN", "CLA", "HON", "ATN", "SLN", "NYA", "PHN" );
leaderData25 = new Array( ".381", ".372", ".371", ".345", ".343", ".339", ".339", ".336", ".335", ".333" );

leaderName26 = new Array( "A.Pujols", "M.Teixeira", "A.Gonzalez", "M.Reynolds", "D.Uggla", "J.Ellsbury", "J.Votto", "L.Berkman", "P.Fielder", "M.Morse" );
leaderTeam26 = new Array( "PIN", "NYA", "BAA", "BAA", "LAA", "BOA", "CIN", "SEA", "WAN", "BOA" );
leaderData26 = new Array( "38", "33", "32", "31", "29", "28", "28", "28", "28", "27" );

leaderName27 = new Array( "F.Hernandez", "I.Kennedy", "C.Lee", "J.Shields", "D.Haren", "C.Hamels", "D.Fister", "T.Hudson", "J.Beckett", "R.Romero" );
leaderTeam27 = new Array( "SEA", "PHN", "PHN", "MNA", "OAA", "PHN", "SEA", "ATN", "BOA", "TOA" );
leaderData27 = new Array( "21", "20", "20", "19", "19", "19", "19", "18", "18", "17" );

leaderName28 = new Array( "B.Myers", "T.Stauffer", "J.Vargas", "Y.Gallardo", "J.Lackey", "C.Billingsley", "C.Pavano", "A.Burnett", "E.Jackson", "C.Lewis" );
leaderTeam28 = new Array( "KCA", "SDN", "MNA", "HON", "LAA", "LAN", "MNA", "NYA", "SDN", "TOA" );
leaderData28 = new Array( "20", "19", "17", "16", "16", "16", "16", "16", "16", "16" );

leaderName29 = new Array( "D.Fister", "T.Hudson", "J.Pineiro", "J.Beckett", "T.Hanson", "F.Hernandez", "I.Kennedy", "J.Tomlin", "C.Hamels", "C.Lee" );
leaderTeam29 = new Array( "SEA", "ATN", "SEA", "BOA", "ATN", "SEA", "PHN", "CHN", "PHN", "PHN" );
leaderData29 = new Array( ".826", ".818", ".800", ".783", ".778", ".778", ".769", ".762", ".760", ".741" );

leaderName30 = new Array( "D.Fister", "D.Haren", "J.Verlander", "J.Karstens", "C.Hamels", "T.Lincecum", "C.Kershaw", "J.Beckett", "J.Tomlin", "T.Hudson" );
leaderTeam30 = new Array( "SEA", "OAA", "DEA", "OAA", "PHN", "SFN", "LAN", "BOA", "CHN", "ATN" );
leaderData30 = new Array( " 1.91", " 2.11", " 2.34", " 2.35", " 2.68", " 2.71", " 2.81", " 2.92", " 2.97", " 3.00" );

leaderName31 = new Array( "J.Verlander", "D.Haren", "J.Weaver", "R.Halladay", "F.Hernandez", "C.Carpenter", "C.Kershaw", "C.Lee", "C.Sabathia", "J.Shields" );
leaderTeam31 = new Array( "DEA", "OAA", "LAA", "CHA", "SEA", "LAN", "LAN", "PHN", "CLA", "MNA" );
leaderData31 = new Array( "257.2", "247.1", "246.2", "244.1", "244.1", "242.0", "240.1", "240.0", "234.2", "232.2" );

leaderName32 = new Array( "J.Weaver", "C.Carpenter", "R.Halladay", "F.Hernandez", "C.Kershaw", "J.Verlander", "C.Sabathia", "J.Shields", "C.Pavano", "C.Lee" );
leaderTeam32 = new Array( "LAA", "LAN", "CHA", "SEA", "LAN", "DEA", "CLA", "MNA", "MNA", "PHN" );
leaderData32 = new Array( "1035", "1029", "1014", "1009", "1006", "1001", "989", "980", "978", "976" );

leaderName33 = new Array( "J.Karstens", "A.Aceves", "T.Gorzelanny", "N.Feliz", "C.Marmol", "J.Papelbon", "D.Storen", "J.Johnson", "N.Masset", "B.League" );
leaderTeam33 = new Array( "OAA", "BOA", "CHN", "BAA", "CHN", "BOA", "WAN", "BAA", "CIN", "SEA" );
leaderData33 = new Array( "75", "68", "67", "62", "62", "61", "61", "60", "60", "59" );

leaderName34 = new Array( "D.Price", "C.Carpenter", "T.Hudson", "M.Scherzer", "R.Dempster", "C.Sabathia", "J.Verlander", "Y.Gallardo", "E.Santana", "B.Myers" );
leaderTeam34 = new Array( "HON", "LAN", "ATN", "***", "CHN", "CLA", "DEA", "HON", "HON", "KCA" );
leaderData34 = new Array( "34", "34", "33", "33", "33", "33", "33", "33", "33", "33" );

leaderName35 = new Array( "J.Verlander", "C.Carpenter", "C.Lee", "D.Haren", "C.Hamels", "I.Kennedy", "T.Lincecum", "D.Fister", "R.Halladay", "T.Lilly" );
leaderTeam35 = new Array( "DEA", "LAN", "PHN", "OAA", "PHN", "PHN", "SFN", "SEA", "CHA", "KCA" );
leaderData35 = new Array( "13", "12", "12", "11", "10", "10", "10", "10", "9", "9" );

leaderName36 = new Array( "J.Papelbon", "J.Karstens", "N.Feliz", "D.Storen", "F.Francisco", "B.League", "J.Hanrahan", "C.Kimbrel", "C.Marmol", "M.Melancon" );
leaderTeam36 = new Array( "BOA", "OAA", "BAA", "WAN", "DEA", "SEA", "PIN", "ATN", "CHN", "KCA" );
leaderData36 = new Array( "56", "56", "54", "53", "49", "49", "47", "45", "44", "42" );

leaderName37 = new Array( "J.Papelbon", "B.League", "N.Feliz", "F.Francisco", "J.Putz", "S.Santos", "C.Kimbrel", "F.Rodriguez", "J.Hanrahan", "M.Rivera" );
leaderTeam37 = new Array( "BOA", "SEA", "BAA", "DEA", "HON", "TOA", "ATN", "NYN", "PIN", "NYA" );
leaderData37 = new Array( "47", "37", "36", "34", "32", "32", "31", "30", "29", "28" );

leaderName38 = new Array( "M.Rivera", "C.Marmol", "H.Street", "J.Putz", "M.Melancon", "R.Betancourt", "J.Papelbon", "J.Valverde", "B.Wilson", "S.Santos" );
leaderTeam38 = new Array( "NYA", "CHN", "OAA", "HON", "KCA", "SFN", "BOA", "SDN", "SFN", "TOA" );
leaderData38 = new Array( ".933", ".900", ".897", ".889", ".889", ".882", ".870", ".867", ".867", ".865" );

leaderName39 = new Array( "J.Verlander", "D.Fister", "J.Beckett", "R.Halladay", "B.Myers", "C.Carpenter", "D.Haren", "F.Hernandez", "S.Marcum", "C.Wilson" );
leaderTeam39 = new Array( "DEA", "SEA", "BOA", "CHA", "KCA", "LAN", "OAA", "SEA", "CLA", "CLA" );
leaderData39 = new Array( "5", "5", "4", "3", "3", "3", "3", "3", "2", "2" );

leaderName40 = new Array( "C.Pavano", "J.Vargas", "R.Halladay", "C.Carpenter", "M.Pelfrey", "R.Dempster", "C.Sabathia", "J.Shields", "H.Kuroda", "F.Hernandez" );
leaderTeam40 = new Array( "MNA", "MNA", "CHA", "LAN", "PIN", "CHN", "CLA", "MNA", "LAN", "SEA" );
leaderData40 = new Array( "261", "253", "250", "250", "242", "238", "234", "231", "225", "225" );

leaderName41 = new Array( "C.Billingsley", "A.Burnett", "T.Cahill", "R.Dempster", "B.Myers", "J.Lackey", "R.Nolasco", "E.Jackson", "C.Pavano", "J.Vargas" );
leaderTeam41 = new Array( "LAN", "NYA", "OAA", "CHN", "KCA", "LAA", "NYA", "SDN", "MNA", "MNA" );
leaderData41 = new Array( "144", "138", "135", "131", "131", "130", "126", "125", "122", "119" );

leaderName42 = new Array( "B.Myers", "A.Burnett", "C.Billingsley", "R.Dempster", "T.Cahill", "J.Lackey", "R.Nolasco", "E.Jackson", "M.Pelfrey", "C.Pavano" );
leaderTeam42 = new Array( "KCA", "NYA", "LAN", "CHN", "OAA", "LAA", "NYA", "SDN", "PIN", "MNA" );
leaderData42 = new Array( "126", "125", "124", "122", "119", "118", "116", "116", "111", "110" );

leaderName43 = new Array( "B.Arroyo", "A.Burnett", "C.Volstad", "Y.Gallardo", "R.Romero", "C.Lewis", "J.Saunders", "A.Sanchez", "C.Lee", "J.Verlander" );
leaderTeam43 = new Array( "CIN", "NYA", "TOA", "HON", "TOA", "TOA", "WAN", "LAA", "PHN", "DEA" );
leaderData43 = new Array( "42", "42", "35", "33", "33", "31", "31", "30", "30", "29" );

leaderName44 = new Array( "R.Dempster", "J.Chacin", "J.McDonald", "J.Saunders", "U.Jimenez", "E.Volquez", "J.Happ", "J.Weaver", "R.Dickey", "C.Morton" );
leaderTeam44 = new Array( "CHN", "HON", "PIN", "WAN", "BAA", "LAA", "NYA", "LAA", "NYN", "PIN" );
leaderData44 = new Array( "107", "97", "89", "87", "86", "86", "86", "85", "85", "85" );

leaderName45 = new Array( "C.Kershaw", "J.Verlander", "C.Lee", "F.Hernandez", "J.Weaver", "D.Price", "I.Kennedy", "T.Lincecum", "C.Sabathia", "R.Halladay" );
leaderTeam45 = new Array( "LAN", "DEA", "PHN", "SEA", "LAA", "HON", "PHN", "SFN", "CLA", "CHA" );
leaderData45 = new Array( "278", "251", "248", "233", "225", "219", "219", "219", "216", "211" );

leaderName46 = new Array( "T.Cahill", "C.Morton", "A.Burnett", "I.Nova", "Y.Gallardo", "H.Kuroda", "F.Liriano", "J.Lackey", "J.Hanrahan", "T.Lincecum" );
leaderTeam46 = new Array( "OAA", "PIN", "NYA", "BAA", "HON", "LAN", "MNA", "LAA", "PIN", "SFN" );
leaderData46 = new Array( "24", "17", "15", "13", "12", "12", "12", "11", "11", "11" );

leaderName47 = new Array( "A.Sanchez", "C.Hamels", "C.Pavano", "J.Grabow", "C.Luebke", "R.Halladay", "J.Jurrjens", "M.Harrison", "J.Collmenter", "N.Masset" );
leaderTeam47 = new Array( "LAA", "PHN", "MNA", "SDN", "ATN", "CHA", "WAN", "BOA", "CHN", "CIN" );
leaderData47 = new Array( "7", "7", "5", "5", "4", "4", "4", "3", "3", "3" );

leaderName48 = new Array( "J.Danks", "M.Leake", "C.Wilson", "J.Francis", "C.Kershaw", "H.Kuroda", "D.Haren", "I.Kennedy", "A.Ogando", "K.Lohse" );
leaderTeam48 = new Array( "CHA", "CIN", "CLA", "DEA", "LAN", "LAN", "OAA", "PHN", "PHN", "SLN" );
leaderData48 = new Array( "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00" );

leaderName49 = new Array( "F.Hernandez", "D.Lowe", "T.Lilly", "M.Pelfrey", "J.Lackey", "E.Volquez", "C.Hamels", "T.Cahill", "F.Garcia", "A.Burnett" );
leaderTeam49 = new Array( "SEA", "TOA", "KCA", "PIN", "LAA", "LAA", "PHN", "OAA", "CHA", "NYA" );
leaderData49 = new Array( "67", "53", "49", "49", "47", "47", "43", "42", "38", "38" );

leaderName50 = new Array( "C.Lee", "R.Romero", "W.Rodriguez", "R.Nolasco", "C.Lewis", "R.Porcello", "J.Masterson", "D.Price", "D.Hudson", "A.Sanchez" );
leaderTeam50 = new Array( "PHN", "TOA", "LAA", "NYA", "TOA", "DEA", "CLA", "HON", "CLA", "LAA" );
leaderData50 = new Array( ".54", ".54", ".59", ".60", ".60", ".63", ".65", ".65", ".67", ".67" );

leaderName51 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderTeam51 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderData51 = new Array( "", "", "", "", "", "", "", "", "", "" );

leaderName52 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderTeam52 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderData52 = new Array( "", "", "", "", "", "", "", "", "", "" );

leaderName53 = new Array( "J.Verlander", "D.Fister", "B.Morrow", "J.Beckett", "C.Wilson", "M.Pineda", "G.Floyd", "T.Lincecum", "J.Hellickson", "I.Kennedy" );
leaderTeam53 = new Array( "DEA", "SEA", "SEA", "BOA", "CLA", "SEA", "SLN", "SFN", "WAN", "PHN" );
leaderData53 = new Array( " 5.9", " 6.2", " 6.3", " 6.6", " 6.7", " 6.8", " 7.0", " 7.1", " 7.2", " 7.5" );

leaderName54 = new Array( "D.Haren", "D.Fister", "J.Tomlin", "R.Halladay", "B.Arroyo", "B.McCarthy", "C.Hamels", "J.Beckett", "J.Danks", "C.Lee" );
leaderTeam54 = new Array( "OAA", "SEA", "CHN", "CHA", "CIN", "OAA", "PHN", "BOA", "CHA", "PHN" );
leaderData54 = new Array( " 1.1", " 1.2", " 1.7", " 1.8", " 1.8", " 2.0", " 2.0", " 2.0", " 2.1", " 2.1" );

leaderName55 = new Array( "C.Kershaw", "Z.Greinke", "M.Pineda", "B.Morrow", "C.Lee", "M.Bumgarner", "T.Lincecum", "M.Garza", "J.Beckett", "G.Gonzalez" );
leaderTeam55 = new Array( "LAN", "KCA", "SEA", "SEA", "PHN", "SFN", "SFN", "NYN", "BOA", "OAA" );
leaderData55 = new Array( "10.4", " 9.9", " 9.8", " 9.6", " 9.3", " 9.2", " 9.1", " 9.1", " 9.0", " 8.8" );

leaderName56 = new Array( "R.Halladay", "R.Dickey", "J.Hellickson", "M.Harrison", "S.Marcum", "C.Carpenter", "D.Fister", "D.Haren", "F.Hernandez", "C.Wilson" );
leaderTeam56 = new Array( "CHA", "NYN", "WAN", "BOA", "CLA", "LAN", "SEA", "OAA", "SEA", "CLA" );
leaderData56 = new Array( " 0.44", " 0.50", " 0.57", " 0.62", " 0.63", " 0.63", " 0.64", " 0.69", " 0.70", " 0.73" );

