// User Data
var myLeague = "Continental Baseball League";	
var mylogo = "my_logo.gif";
var toplogo = "stratomatic.jpg"
var toptext = "The CBL - Since 1985 and still going strong!!!!";
var backColor = "LightSteelBlue";			  
var bargraph = "green.gif";
// 0=Do not show wild card standings
// 1=Show wild card standings
var wildCard = 1;
// How many teams to list in the wild card standings
var wildcardsThisMany = 6;  