leaderName0 = new Array( "A.Gonzalez", "H.Pence", "V.Guerrero", "V.Martinez", "E.Hosmer", "M.Cabrera", "R.Cano", "L.Berkman", "E.Bonifacio", "M.Bourn" );
leaderTeam0 = new Array( "BAA", "HON", "BAA", "PHN", "KCA", "SLN", "NYA", "SEA", "ATN", "HON" );
leaderData0 = new Array( ".376", ".344", ".343", ".336", ".322", ".319", ".318", ".317", ".314", ".312" );

leaderName1 = new Array( "M.Cabrera", "J.Ellsbury", "A.Gordon", "A.Gonzalez", "B.Phillips", "M.Young", "E.Aybar", "N.Markakis", "A.Ramirez", "E.Hosmer" );
leaderTeam1 = new Array( "SFN", "BOA", "KCA", "BAA", "CIN", "PHN", "SLN", "BAA", "CHA", "KCA" );
leaderData1 = new Array( "494", "488", "481", "468", "466", "466", "466", "462", "462", "460" );

leaderName2 = new Array( "J.Ellsbury", "J.Bautista", "M.Teixeira", "J.Votto", "A.Gonzalez", "R.Braun", "C.Granderson", "R.Cano", "A.Ramirez", "A.Gordon" );
leaderTeam2 = new Array( "BOA", "PHN", "NYA", "CIN", "BAA", "CHA", "DEA", "NYA", "CHA", "KCA" );
leaderData2 = new Array( "96", "93", "85", "83", "81", "78", "78", "77", "76", "76" );

leaderName3 = new Array( "A.Gonzalez", "H.Pence", "J.Ellsbury", "M.Cabrera", "E.Hosmer", "V.Guerrero", "R.Cano", "M.Cabrera", "M.Young", "E.Aybar" );
leaderTeam3 = new Array( "BAA", "HON", "BOA", "SFN", "KCA", "BAA", "NYA", "SLN", "PHN", "SLN" );
leaderData3 = new Array( "176", "157", "149", "149", "148", "147", "145", "145", "143", "143" );

leaderName4 = new Array( "J.Ellsbury", "M.Young", "M.Cabrera", "A.Gonzalez", "D.Pedroia", "J.Francoeur", "I.Kinsler", "D.Fowler", "H.Pence", "E.Hosmer" );
leaderTeam4 = new Array( "BOA", "PHN", "SLN", "BAA", "BOA", "KCA", "TOA", "WAN", "HON", "KCA" );
leaderData4 = new Array( "43", "37", "37", "34", "34", "34", "32", "31", "30", "30" );

leaderName5 = new Array( "S.Victorino", "J.Reyes", "B.Gardner", "C.Maybin", "D.Fowler", "M.Cuddyer", "M.Bourn", "C.Granderson", "S.Smith", "E.Aybar" );
leaderTeam5 = new Array( "PHN", "TOA", "NYA", "SLN", "WAN", "MNA", "HON", "DEA", "NYN", "SLN" );
leaderData5 = new Array( "11", "11", "10", "10", "10", "9", "8", "7", "7", "7" );

leaderName6 = new Array( "M.Teixeira", "A.Pujols", "M.Reynolds", "J.Bautista", "A.Gonzalez", "C.Granderson", "J.Votto", "J.Bruce", "D.Uggla", "P.Fielder" );
leaderTeam6 = new Array( "NYA", "PIN", "BAA", "PHN", "BAA", "DEA", "CIN", "CIN", "LAA", "WAN" );
leaderData6 = new Array( "36", "36", "34", "33", "30", "30", "29", "27", "27", "27" );

leaderName7 = new Array( "A.Gonzalez", "J.Bautista", "M.Teixeira", "A.Pujols", "R.Braun", "E.Hosmer", "C.Granderson", "R.Cano", "J.Votto", "P.Fielder" );
leaderTeam7 = new Array( "BAA", "PHN", "NYA", "PIN", "CHA", "KCA", "DEA", "NYA", "CIN", "WAN" );
leaderData7 = new Array( "98", "97", "96", "91", "87", "84", "83", "81", "77", "76" );

leaderName8 = new Array( "J.Bautista", "J.Votto", "C.Santana", "M.Cabrera", "B.Zobrist", "L.Berkman", "D.Pedroia", "M.Holliday", "R.Howard", "G.Sanchez" );
leaderTeam8 = new Array( "PHN", "CIN", "CLA", "SLN", "SLN", "SEA", "BOA", "LAA", "PHN", "HON" );
leaderData8 = new Array( "95", "87", "72", "70", "69", "68", "65", "64", "63", "61" );

leaderName9 = new Array( "C.Gonzalez", "V.Martinez", "L.Berkman", "M.Kemp", "R.Cano", "M.Young", "M.Cabrera", "A.Gonzalez", "E.Hosmer", "H.Pence" );
leaderTeam9 = new Array( "OAA", "PHN", "SEA", "LAN", "NYA", "PHN", "SLN", "BAA", "KCA", "HON" );
leaderData9 = new Array( "16", "12", "11", "10", "10", "10", "10", "9", "9", "8" );

leaderName10 = new Array( "M.Reynolds", "A.Dunn", "D.Stubbs", "C.Granderson", "B.Upton", "M.Kemp", "A.Jackson", "J.Bruce", "A.Gordon", "D.Espinosa" );
leaderTeam10 = new Array( "BAA", "MNA", "CIN", "DEA", "SFN", "LAN", "DEA", "CIN", "KCA", "WAN" );
leaderData10 = new Array( "164", "154", "148", "143", "138", "128", "127", "126", "120", "120" );

leaderName11 = new Array( "C.Utley", "D.Espinosa", "J.Upton", "M.Morse", "C.Quentin", "M.Izturis", "N.Morgan", "E.Aybar", "P.Fielder", "K.Youkilis" );
leaderTeam11 = new Array( "PHN", "WAN", "WAN", "BOA", "HON", "OAA", "OAA", "SLN", "WAN", "BOA" );
leaderData11 = new Array( "14", "14", "14", "13", "13", "11", "11", "11", "11", "9" );

leaderName12 = new Array( "B.Ryan", "J.Schafer", "A.Escobar", "A.Torres", "K.Fukudome", "A.Gonzalez", "A.Ramirez", "R.Santiago", "C.Denorfia", "J.Carroll" );
leaderTeam12 = new Array( "SEA", "KCA", "DEA", "NYN", "NYN", "BOA", "CHA", "DEA", "SDN", "SDN" );
leaderData12 = new Array( "46", "31", "30", "25", "22", "18", "17", "17", "17", "16" );

leaderName13 = new Array( "M.Bourn", "C.Crisp", "B.Gardner", "E.Andrus", "B.Revere", "C.Maybin", "J.Ellsbury", "S.Castro", "M.Cabrera", "I.Suzuki" );
leaderTeam13 = new Array( "HON", "NYA", "NYA", "WAN", "CLA", "SLN", "BOA", "CHN", "SFN", "SEA" );
leaderData13 = new Array( "54", "52", "48", "42", "40", "40", "38", "33", "33", "32" );

leaderName14 = new Array( "C.Gentry", "E.Bonifacio", "X.Paul", "T.Gwynn Jr", "I.Suzuki", "J.Rollins", "J.Bartlett", "C.Crisp", "N.Morgan", "J.Weeks" );
leaderTeam14 = new Array( "CHN", "ATN", "LAN", "PHN", "SEA", "PHN", "CIN", "NYA", "OAA", "OAA" );
leaderData14 = new Array( ".95", ".92", ".92", ".89", ".89", ".88", ".87", ".87", ".87", ".85" );

leaderName15 = new Array( "A.Pujols", "A.Gonzalez", "M.Young", "M.Wieters", "R.Braun", "S.Castro", "M.Joyce", "M.Cuddyer", "M.Trumbo", "M.Cabrera" );
leaderTeam15 = new Array( "PIN", "BAA", "PHN", "BAA", "CHA", "CHN", "CHN", "MNA", "LAA", "SLN" );
leaderData15 = new Array( "25", "21", "21", "19", "19", "19", "19", "19", "18", "18" );

leaderName16 = new Array( "E.Aybar", "E.Andrus", "T.Hafner", "D.Fowler", "A.Callaspo", "T.Campana", "J.Turner", "E.Bonifacio", "O.Infante", "B.McCann" );
leaderTeam16 = new Array( "SLN", "WAN", "PIN", "WAN", "CHN", "CHN", "NYN", "ATN", "ATN", "ATN" );
leaderData16 = new Array( "6", "6", "5", "5", "4", "4", "4", "3", "3", "3" );

leaderName17 = new Array( "J.Constanza", "P.Sandoval", "A.Pagan", "Y.Torrealba", "M.Carp", "R.Doumit", "W.Betemit", "B.Inge", "N.Evans", "S.Sizemore" );
leaderTeam17 = new Array( "CIN", "SFN", "KCA", "SEA", "SEA", "PIN", "DEA", "KCA", "DEA", "DEA" );
leaderData17 = new Array( ".529", ".467", ".348", ".333", ".300", ".235", ".222", ".200", ".188", ".167" );

leaderName18 = new Array( "A.Gonzalez", "A.Pujols", "J.Bautista", "J.Votto", "M.Stanton", "L.Berkman", "R.Cano", "J.Ellsbury", "H.Pence", "M.Kemp" );
leaderTeam18 = new Array( "BAA", "PIN", "PHN", "CIN", "ATN", "SEA", "NYA", "BOA", "HON", "LAN" );
leaderData18 = new Array( ".645", ".605", ".594", ".590", ".575", ".575", ".572", ".566", ".555", ".548" );

leaderName19 = new Array( "A.Gonzalez", "J.Bautista", "J.Votto", "L.Berkman", "H.Pence", "M.Cabrera", "V.Martinez", "B.Abreu", "C.Gonzalez", "C.Kotchman" );
leaderTeam19 = new Array( "BAA", "PHN", "CIN", "SEA", "HON", "SLN", "PHN", "NYA", "OAA", "DEA" );
leaderData19 = new Array( ".440", ".431", ".430", ".423", ".410", ".410", ".401", ".390", ".389", ".388" );

leaderName20 = new Array( "A.Gonzalez", "J.Votto", "J.Bautista", "L.Berkman", "H.Pence", "J.Ellsbury", "C.Gonzalez", "M.Cabrera", "R.Cano", "V.Martinez" );
leaderTeam20 = new Array( "BAA", "CIN", "PHN", "SEA", "HON", "BOA", "OAA", "SLN", "NYA", "PHN" );
leaderData20 = new Array( "10.6", "10.2", "10.1", " 9.6", " 8.3", " 8.0", " 7.9", " 7.9", " 7.8", " 7.4" );

leaderName21 = new Array( "J.Bautista", "A.Gonzalez", "J.Votto", "L.Berkman", "J.Ellsbury", "M.Kemp", "C.Gonzalez", "C.Granderson", "M.Cabrera", "H.Pence" );
leaderTeam21 = new Array( "PHN", "BAA", "CIN", "SEA", "BOA", "LAN", "OAA", "DEA", "SLN", "HON" );
leaderData21 = new Array( "1.170", "1.146", "1.146", "1.093", "1.034", ".988", ".980", ".979", ".963", ".959" );

leaderName22 = new Array( "A.Gonzalez", "J.Ellsbury", "R.Cano", "H.Pence", "E.Hosmer", "M.Kemp", "J.Votto", "A.Pujols", "M.Cabrera", "R.Braun" );
leaderTeam22 = new Array( "BAA", "BOA", "NYA", "HON", "KCA", "LAN", "CIN", "PIN", "SLN", "CHA" );
leaderData22 = new Array( "302", "276", "261", "253", "250", "247", "246", "242", "241", "240" );

leaderName23 = new Array( "J.Sands", "A.Ramirez", "V.Guerrero", "J.Carroll", "H.Pence", "R.Braun", "A.Huff", "M.Wieters", "E.Bonifacio", "A.Gonzalez" );
leaderTeam23 = new Array( "LAN", "CHN", "BAA", "SDN", "HON", "CHA", "CLA", "BAA", "ATN", "BAA" );
leaderData23 = new Array( ".400", ".395", ".392", ".386", ".382", ".379", ".373", ".372", ".370", ".363" );

leaderName24 = new Array( "C.Young", "M.Teixeira", "R.Raburn", "A.Ellis", "J.Bautista", "M.Cameron", "M.Reynolds", "G.Soto", "J.Bruce", "H.Pence" );
leaderTeam24 = new Array( "BAA", "NYA", "DEA", "LAN", "PHN", "OAA", "BAA", "CHN", "CIN", "HON" );
leaderData24 = new Array( "14", "13", "12", "10", "10", "9", "8", "8", "8", "8" );

leaderName25 = new Array( "A.Gonzalez", "V.Martinez", "P.Sandoval", "J.Mauer", "E.Aybar", "M.Cabrera", "R.Cano", "T.Hafner", "E.Hosmer", "G.Parra" );
leaderTeam25 = new Array( "BAA", "PHN", "SFN", "MNA", "SLN", "SLN", "NYA", "PIN", "KCA", "CHA" );
leaderData25 = new Array( ".384", ".367", ".362", ".348", ".345", ".344", ".341", ".340", ".338", ".333" );

leaderName26 = new Array( "A.Pujols", "A.Gonzalez", "M.Reynolds", "J.Votto", "C.Granderson", "M.Teixeira", "J.Bautista", "L.Berkman", "P.Fielder", "D.Uggla" );
leaderTeam26 = new Array( "PIN", "BAA", "BAA", "CIN", "DEA", "NYA", "PHN", "SEA", "WAN", "LAA" );
leaderData26 = new Array( "32", "28", "26", "24", "23", "23", "23", "22", "22", "21" );

leaderName27 = new Array( "C.Lee", "C.Hamels", "D.Fister", "F.Hernandez", "J.Tomlin", "I.Kennedy", "T.Hudson", "R.Oswalt", "Z.Greinke", "D.Haren" );
leaderTeam27 = new Array( "PHN", "PHN", "SEA", "SEA", "CHN", "PHN", "ATN", "HON", "KCA", "OAA" );
leaderData27 = new Array( "17", "15", "15", "15", "14", "14", "13", "13", "13", "13" );

leaderName28 = new Array( "B.Myers", "C.Volstad", "J.Vargas", "C.Lewis", "F.Liriano", "G.Gonzalez", "T.Stauffer", "M.Latos", "R.Porcello", "J.Chacin" );
leaderTeam28 = new Array( "KCA", "TOA", "MNA", "TOA", "MNA", "OAA", "SDN", "BAA", "DEA", "HON" );
leaderData28 = new Array( "15", "15", "14", "14", "13", "13", "13", "12", "12", "12" );

leaderName29 = new Array( "T.Hanson", "D.Fister", "J.Pineiro", "C.Lee", "M.Harrison", "C.Hamels", "F.Hernandez", "J.Tomlin", "I.Kennedy", "E.Bedard" );
leaderTeam29 = new Array( "ATN", "SEA", "SEA", "PHN", "BOA", "PHN", "SEA", "CHN", "PHN", "BOA" );
leaderData29 = new Array( ".857", ".833", ".818", ".810", ".800", ".789", ".789", ".778", ".778", ".769" );

leaderName30 = new Array( "D.Fister", "J.Verlander", "D.Haren", "G.Floyd", "J.Hellickson", "C.Kershaw", "T.Lincecum", "K.Lohse", "T.Hudson", "J.Tomlin" );
leaderTeam30 = new Array( "SEA", "DEA", "OAA", "SLN", "WAN", "LAN", "SFN", "SLN", "ATN", "CHN" );
leaderData30 = new Array( " 1.67", " 2.30", " 2.32", " 2.36", " 2.55", " 2.71", " 2.81", " 2.91", " 2.98", " 2.99" );

leaderName31 = new Array( "J.Verlander", "R.Halladay", "D.Haren", "T.Lincecum", "M.Cain", "F.Hernandez", "D.Fister", "J.Weaver", "C.Lee", "W.Rodriguez" );
leaderTeam31 = new Array( "DEA", "CHA", "OAA", "SFN", "SFN", "SEA", "SEA", "LAA", "PHN", "LAA" );
leaderData31 = new Array( "191.1", "189.0", "186.1", "186.0", "184.0", "183.2", "177.1", "176.2", "176.0", "170.2" );

leaderName32 = new Array( "R.Halladay", "T.Lincecum", "F.Hernandez", "M.Cain", "J.Weaver", "J.Verlander", "D.Haren", "C.Sabathia", "C.Carpenter", "C.Lee" );
leaderTeam32 = new Array( "CHA", "SFN", "SEA", "SFN", "LAA", "DEA", "OAA", "CLA", "LAN", "PHN" );
leaderData32 = new Array( "798", "769", "765", "763", "747", "746", "732", "723", "720", "713" );

leaderName33 = new Array( "T.Gorzelanny", "J.Karstens", "N.Masset", "N.Feliz", "A.Aceves", "J.Hanrahan", "J.Benoit", "F.Cordero", "D.Storen", "J.Johnson" );
leaderTeam33 = new Array( "CHN", "OAA", "CIN", "BAA", "BOA", "PIN", "HON", "TOA", "WAN", "BAA" );
leaderData33 = new Array( "60", "53", "50", "49", "47", "47", "46", "46", "46", "45" );

leaderName34 = new Array( "F.Hernandez", "T.Hudson", "M.Buehrle", "R.Halladay", "J.Verlander", "W.Rodriguez", "C.Carpenter", "H.Kuroda", "D.Haren", "T.Lincecum" );
leaderTeam34 = new Array( "SEA", "ATN", "CHA", "CHA", "DEA", "LAA", "LAN", "LAN", "OAA", "SFN" );
leaderData34 = new Array( "25", "24", "24", "24", "24", "24", "24", "24", "24", "24" );

leaderName35 = new Array( "J.Verlander", "C.Lee", "T.Lincecum", "D.Haren", "M.Cain", "D.Fister", "R.Halladay", "T.Lilly", "C.Carpenter", "C.Hamels" );
leaderTeam35 = new Array( "DEA", "PHN", "SFN", "OAA", "SFN", "SEA", "CHA", "KCA", "LAN", "PHN" );
leaderData35 = new Array( "11", "10", "10", "9", "9", "8", "7", "7", "7", "7" );

leaderName36 = new Array( "N.Feliz", "J.Karstens", "J.Hanrahan", "D.Storen", "F.Francisco", "J.Papelbon", "B.League", "C.Marmol", "B.Fuentes", "M.Rivera" );
leaderTeam36 = new Array( "BAA", "OAA", "PIN", "WAN", "DEA", "BOA", "SEA", "CHN", "LAA", "NYA" );
leaderData36 = new Array( "43", "40", "40", "40", "38", "37", "35", "33", "32", "31" );

leaderName37 = new Array( "J.Papelbon", "N.Feliz", "B.League", "F.Francisco", "J.Hanrahan", "C.Marmol", "M.Rivera", "B.Fuentes", "S.Santos", "F.Rodriguez" );
leaderTeam37 = new Array( "BOA", "BAA", "SEA", "DEA", "PIN", "CHN", "NYA", "LAA", "TOA", "NYN" );
leaderData37 = new Array( "33", "30", "27", "25", "25", "23", "22", "20", "20", "19" );

leaderName38 = new Array( "M.Rivera", "J.Venters", "M.Melancon", "C.Marmol", "G.Holland", "B.Wilson", "S.Santos", "J.Papelbon", "C.Kimbrel", "H.Street" );
leaderTeam38 = new Array( "NYA", "ATN", "KCA", "CHN", "KCA", "SFN", "TOA", "BOA", "ATN", "OAA" );
leaderData38 = new Array( ".957", ".944", ".941", ".920", ".917", ".909", ".870", ".868", ".857", ".850" );

leaderName39 = new Array( "J.Beckett", "J.Verlander", "D.Fister", "R.Halladay", "D.Haren", "S.Marcum", "Y.Gallardo", "B.Myers", "T.Lincecum", "J.Hellickson" );
leaderTeam39 = new Array( "BOA", "DEA", "SEA", "CHA", "OAA", "CLA", "HON", "KCA", "SFN", "WAN" );
leaderData39 = new Array( "4", "4", "4", "3", "3", "2", "2", "2", "2", "2" );

leaderName40 = new Array( "R.Halladay", "J.Vargas", "C.Pavano", "C.Carpenter", "J.Masterson", "C.Sabathia", "F.Hernandez", "M.Bumgarner", "E.Jackson", "J.Weaver" );
leaderTeam40 = new Array( "CHA", "MNA", "MNA", "LAN", "CLA", "CLA", "SEA", "SFN", "SDN", "LAA" );
leaderData40 = new Array( "207", "199", "189", "178", "174", "171", "171", "170", "166", "165" );

leaderName41 = new Array( "T.Cahill", "B.Myers", "J.Vargas", "A.Burnett", "C.Volstad", "E.Jackson", "M.Buehrle", "C.Billingsley", "B.Arroyo", "J.Masterson" );
leaderTeam41 = new Array( "OAA", "KCA", "MNA", "NYA", "TOA", "SDN", "CHA", "LAN", "CIN", "CLA" );
leaderData41 = new Array( "105", "100", "98", "97", "95", "94", "92", "92", "90", "90" );

leaderName42 = new Array( "B.Myers", "J.Vargas", "T.Cahill", "A.Burnett", "E.Jackson", "B.Arroyo", "C.Volstad", "C.Pavano", "J.Masterson", "F.Hernandez" );
leaderTeam42 = new Array( "KCA", "MNA", "OAA", "NYA", "SDN", "CIN", "TOA", "MNA", "CLA", "SEA" );
leaderData42 = new Array( "97", "94", "90", "89", "88", "84", "83", "82", "81", "81" );

leaderName43 = new Array( "B.Arroyo", "C.Volstad", "A.Burnett", "C.Lee", "C.Lewis", "R.Romero", "B.Cecil", "J.Vazquez", "Y.Gallardo", "A.Sanchez" );
leaderTeam43 = new Array( "CIN", "TOA", "NYA", "PHN", "TOA", "TOA", "TOA", "ATN", "HON", "LAA" );
leaderData43 = new Array( "34", "31", "29", "25", "25", "25", "24", "23", "23", "23" );

leaderName44 = new Array( "T.Lincecum", "E.Volquez", "C.Narveson", "G.Gonzalez", "J.Masterson", "J.Chacin", "B.Morrow", "J.Lester", "R.Dempster", "M.Cain" );
leaderTeam44 = new Array( "SFN", "LAA", "CIN", "OAA", "CLA", "HON", "SEA", "BOA", "CHN", "SFN" );
leaderData44 = new Array( "73", "72", "70", "65", "64", "63", "63", "62", "62", "62" );

leaderName45 = new Array( "C.Kershaw", "C.Lee", "T.Lincecum", "J.Verlander", "F.Hernandez", "R.Halladay", "Z.Greinke", "J.Weaver", "C.Sabathia", "M.Cain" );
leaderTeam45 = new Array( "LAN", "PHN", "SFN", "DEA", "SEA", "CHA", "KCA", "LAA", "CLA", "SFN" );
leaderData45 = new Array( "186", "186", "185", "182", "178", "168", "166", "166", "162", "158" );

leaderName46 = new Array( "T.Cahill", "C.Morton", "I.Nova", "J.Hanrahan", "T.Lincecum", "F.Liriano", "A.Burnett", "J.Reyes", "H.Kuroda", "J.Garcia" );
leaderTeam46 = new Array( "OAA", "PIN", "BAA", "PIN", "SFN", "MNA", "NYA", "SFN", "LAN", "SLN" );
leaderData46 = new Array( "18", "12", "11", "11", "11", "10", "10", "10", "9", "9" );

leaderName47 = new Array( "A.Sanchez", "C.Hamels", "C.Luebke", "J.Grabow", "M.Harrison", "R.Halladay", "T.Lilly", "C.Pavano", "B.Parnell", "V.Worley" );
leaderTeam47 = new Array( "LAA", "PHN", "ATN", "SDN", "BOA", "CHA", "KCA", "MNA", "NYN", "PHN" );
leaderData47 = new Array( "6", "5", "4", "4", "3", "3", "3", "3", "3", "3" );

leaderName48 = new Array( "U.Jimenez", "J.Collmenter", "M.Leake", "C.Narveson", "C.Wilson", "J.Francis", "B.Chen", "W.Rodriguez", "C.Kershaw", "H.Kuroda" );
leaderTeam48 = new Array( "BAA", "CHN", "CIN", "CIN", "CLA", "DEA", "KCA", "LAA", "LAN", "LAN" );
leaderData48 = new Array( "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00" );

leaderName49 = new Array( "F.Hernandez", "D.Lowe", "T.Lilly", "E.Volquez", "E.Jackson", "J.Lackey", "C.Hamels", "F.Garcia", "D.Moseley", "E.Santana" );
leaderTeam49 = new Array( "SEA", "TOA", "KCA", "LAA", "SDN", "LAA", "PHN", "CHA", "CHN", "HON" );
leaderData49 = new Array( "49", "45", "41", "38", "33", "31", "31", "28", "27", "26" );

leaderName50 = new Array( "F.Liriano", "R.Romero", "A.Sanchez", "W.Rodriguez", "C.Lee", "C.Lewis", "J.Karstens", "D.Price", "R.Nolasco", "R.Porcello" );
leaderTeam50 = new Array( "MNA", "TOA", "LAA", "LAA", "PHN", "TOA", "OAA", "HON", "NYA", "DEA" );
leaderData50 = new Array( ".33", ".50", ".53", ".54", ".56", ".57", ".60", ".61", ".63", ".63" );

leaderName51 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderTeam51 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderData51 = new Array( "", "", "", "", "", "", "", "", "", "" );

leaderName52 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderTeam52 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderData52 = new Array( "", "", "", "", "", "", "", "", "", "" );

leaderName53 = new Array( "J.Verlander", "D.Fister", "B.Morrow", "G.Floyd", "J.Beckett", "J.Hellickson", "T.Lincecum", "A.Ogando", "J.Lester", "M.Pineda" );
leaderTeam53 = new Array( "DEA", "SEA", "SEA", "SLN", "BOA", "WAN", "SFN", "PHN", "BOA", "SEA" );
leaderData53 = new Array( " 5.8", " 5.8", " 6.4", " 6.4", " 6.8", " 7.0", " 7.1", " 7.1", " 7.3", " 7.4" );

leaderName54 = new Array( "D.Haren", "D.Fister", "B.Arroyo", "J.Tomlin", "J.Collmenter", "S.Marcum", "C.Lee", "R.Halladay", "J.Beckett", "J.Vazquez" );
leaderTeam54 = new Array( "OAA", "SEA", "CIN", "CHN", "CHN", "CLA", "PHN", "CHA", "BOA", "ATN" );
leaderData54 = new Array( " 1.1", " 1.2", " 1.7", " 1.8", " 1.8", " 1.8", " 1.9", " 1.9", " 2.0", " 2.1" );

leaderName55 = new Array( "C.Kershaw", "Z.Greinke", "M.Garza", "C.Lee", "M.Pineda", "B.Morrow", "T.Lincecum", "G.Gonzalez", "M.Bumgarner", "J.Beckett" );
leaderTeam55 = new Array( "LAN", "KCA", "NYN", "PHN", "SEA", "SEA", "SFN", "OAA", "SFN", "BOA" );
leaderData55 = new Array( "10.3", " 9.9", " 9.5", " 9.5", " 9.1", " 9.0", " 9.0", " 8.9", " 8.8", " 8.8" );

leaderName56 = new Array( "R.Halladay", "J.Hellickson", "D.Fister", "S.Marcum", "R.Dickey", "M.Harrison", "C.Carpenter", "G.Floyd", "T.Lincecum", "M.Cain" );
leaderTeam56 = new Array( "CHA", "WAN", "SEA", "CLA", "NYN", "BOA", "LAN", "SLN", "SFN", "SFN" );
leaderData56 = new Array( " 0.29", " 0.40", " 0.46", " 0.47", " 0.56", " 0.58", " 0.69", " 0.70", " 0.73", " 0.73" );

