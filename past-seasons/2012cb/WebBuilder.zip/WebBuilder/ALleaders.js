leaderName0 = new Array( "A.Gonzalez", "V.Guerrero", "E.Hosmer", "R.Cano", "L.Berkman", "R.Braun", "C.Gonzalez", "C.Kotchman", "J.Ellsbury", "J.Reyes" );
leaderTeam0 = new Array( "BAA", "BAA", "KCA", "NYA", "SEA", "CHA", "OAA", "DEA", "BOA", "TOA" );
leaderData0 = new Array( ".376", ".343", ".322", ".318", ".317", ".311", ".307", ".306", ".305", ".303" );

leaderName1 = new Array( "J.Ellsbury", "A.Gordon", "A.Gonzalez", "N.Markakis", "A.Ramirez", "E.Hosmer", "D.Pedroia", "R.Cano", "R.Braun", "M.Teixeira" );
leaderTeam1 = new Array( "BOA", "KCA", "BAA", "BAA", "CHA", "KCA", "BOA", "NYA", "CHA", "NYA" );
leaderData1 = new Array( "488", "481", "468", "462", "462", "460", "456", "456", "454", "441" );

leaderName2 = new Array( "J.Ellsbury", "M.Teixeira", "A.Gonzalez", "R.Braun", "C.Granderson", "R.Cano", "A.Ramirez", "A.Gordon", "N.Markakis", "I.Kinsler" );
leaderTeam2 = new Array( "BOA", "NYA", "BAA", "CHA", "DEA", "NYA", "CHA", "KCA", "BAA", "TOA" );
leaderData2 = new Array( "96", "85", "81", "78", "78", "77", "76", "76", "71", "71" );

leaderName3 = new Array( "A.Gonzalez", "J.Ellsbury", "E.Hosmer", "V.Guerrero", "R.Cano", "R.Braun", "A.Ramirez", "D.Pedroia", "A.Gordon", "J.Francoeur" );
leaderTeam3 = new Array( "BAA", "BOA", "KCA", "BAA", "NYA", "CHA", "CHA", "BOA", "KCA", "KCA" );
leaderData3 = new Array( "176", "149", "148", "147", "145", "141", "128", "127", "121", "120" );

leaderName4 = new Array( "J.Ellsbury", "A.Gonzalez", "D.Pedroia", "J.Francoeur", "I.Kinsler", "E.Hosmer", "R.Cano", "M.Wieters", "C.Jones", "A.Gordon" );
leaderTeam4 = new Array( "BOA", "BAA", "BOA", "KCA", "TOA", "KCA", "NYA", "BAA", "LAA", "KCA" );
leaderData4 = new Array( "43", "34", "34", "34", "32", "30", "30", "29", "29", "28" );

leaderName5 = new Array( "J.Reyes", "B.Gardner", "M.Cuddyer", "C.Granderson", "J.Ellsbury", "P.Bourjos", "C.Crisp", "J.Damon", "G.Parra", "C.Beltran" );
leaderTeam5 = new Array( "TOA", "NYA", "MNA", "DEA", "BOA", "CLA", "NYA", "NYA", "CHA", "CLA" );
leaderData5 = new Array( "11", "10", "9", "7", "6", "6", "6", "6", "5", "5" );

leaderName6 = new Array( "M.Teixeira", "M.Reynolds", "A.Gonzalez", "C.Granderson", "D.Uggla", "R.Cano", "L.Berkman", "J.Ellsbury", "R.Braun", "M.Napoli" );
leaderTeam6 = new Array( "NYA", "BAA", "BAA", "DEA", "LAA", "NYA", "SEA", "BOA", "CHA", "LAA" );
leaderData6 = new Array( "36", "34", "30", "30", "27", "26", "26", "24", "23", "23" );

leaderName7 = new Array( "A.Gonzalez", "M.Teixeira", "R.Braun", "E.Hosmer", "C.Granderson", "R.Cano", "P.Konerko", "M.Reynolds", "A.Jones", "J.Hardy" );
leaderTeam7 = new Array( "BAA", "NYA", "CHA", "KCA", "DEA", "NYA", "CHA", "BAA", "SEA", "BAA" );
leaderData7 = new Array( "98", "96", "87", "84", "83", "81", "74", "71", "71", "70" );

leaderName8 = new Array( "C.Santana", "L.Berkman", "D.Pedroia", "M.Holliday", "C.Granderson", "B.Abreu", "I.Kinsler", "C.Beltran", "M.Wieters", "T.Hunter" );
leaderTeam8 = new Array( "CLA", "SEA", "BOA", "LAA", "DEA", "NYA", "TOA", "CLA", "BAA", "LAA" );
leaderData8 = new Array( "72", "68", "65", "64", "60", "59", "56", "55", "53", "52" );

leaderName9 = new Array( "C.Gonzalez", "L.Berkman", "R.Cano", "A.Gonzalez", "E.Hosmer", "B.Abreu", "J.Ellsbury", "A.Rodriguez", "H.Matsui", "J.Francoeur" );
leaderTeam9 = new Array( "OAA", "SEA", "NYA", "BAA", "KCA", "NYA", "BOA", "SEA", "TOA", "KCA" );
leaderData9 = new Array( "16", "11", "10", "9", "9", "8", "7", "7", "7", "6" );

leaderName10 = new Array( "M.Reynolds", "A.Dunn", "C.Granderson", "A.Jackson", "A.Gordon", "C.Young", "A.Avila", "D.Uggla", "T.Hunter", "M.Morse" );
leaderTeam10 = new Array( "BAA", "MNA", "DEA", "DEA", "KCA", "BAA", "DEA", "LAA", "LAA", "BOA" );
leaderData10 = new Array( "164", "154", "143", "127", "120", "110", "109", "98", "96", "94" );

leaderName11 = new Array( "M.Morse", "M.Izturis", "N.Morgan", "K.Youkilis", "P.Konerko", "C.Granderson", "J.Francoeur", "M.Holliday", "A.Gonzalez", "S.Rodriguez" );
leaderTeam11 = new Array( "BOA", "OAA", "OAA", "BOA", "CHA", "DEA", "KCA", "LAA", "BAA", "CHA" );
leaderData11 = new Array( "13", "11", "11", "9", "9", "9", "9", "9", "8", "8" );

leaderName12 = new Array( "B.Ryan", "J.Schafer", "A.Escobar", "A.Gonzalez", "A.Ramirez", "R.Santiago", "A.Jackson", "R.Raburn", "A.Pagan", "J.McDonald" );
leaderTeam12 = new Array( "SEA", "KCA", "DEA", "BOA", "CHA", "DEA", "DEA", "DEA", "KCA", "KCA" );
leaderData12 = new Array( "46", "31", "30", "18", "17", "17", "15", "15", "15", "13" );

leaderName13 = new Array( "C.Crisp", "B.Gardner", "B.Revere", "J.Ellsbury", "I.Suzuki", "I.Kinsler", "P.Bourjos", "J.Reyes", "R.Braun", "D.Pedroia" );
leaderTeam13 = new Array( "NYA", "NYA", "CLA", "BOA", "SEA", "TOA", "CLA", "TOA", "CHA", "BOA" );
leaderData13 = new Array( "52", "48", "40", "38", "32", "30", "27", "27", "25", "24" );

leaderName14 = new Array( "I.Suzuki", "C.Crisp", "N.Morgan", "J.Weeks", "K.Johnson", "E.Hosmer", "I.Kinsler", "H.Ramirez", "D.Jeter", "J.Schafer" );
leaderTeam14 = new Array( "SEA", "NYA", "OAA", "OAA", "BAA", "KCA", "TOA", "LAA", "NYA", "KCA" );
leaderData14 = new Array( ".89", ".87", ".87", ".85", ".84", ".84", ".83", ".83", ".83", ".81" );

leaderName15 = new Array( "A.Gonzalez", "M.Wieters", "R.Braun", "M.Cuddyer", "M.Trumbo", "M.Holliday", "D.Ortiz", "B.Butler", "D.Young", "K.Suzuki" );
leaderTeam15 = new Array( "BAA", "BAA", "CHA", "MNA", "LAA", "LAA", "BOA", "KCA", "MNA", "OAA" );
leaderData15 = new Array( "21", "19", "19", "19", "18", "17", "16", "16", "16", "16" );

leaderName16 = new Array( "C.Gonzalez", "J.Weeks", "P.Goldschmidt", "D.Ackley", "A.Rodriguez", "B.Butler", "J.Francoeur", "A.Gordon", "E.Hosmer", "B.Inge" );
leaderTeam16 = new Array( "OAA", "OAA", "OAA", "SEA", "SEA", "KCA", "KCA", "KCA", "KCA", "KCA" );
leaderData16 = new Array( "3", "3", "3", "3", "3", "2", "2", "2", "2", "2" );

leaderName17 = new Array( "A.Pagan", "Y.Torrealba", "M.Carp", "W.Betemit", "B.Inge", "N.Evans", "S.Sizemore", "L.Overbay", "M.Moustakas", "H.Ramirez" );
leaderTeam17 = new Array( "KCA", "SEA", "SEA", "DEA", "KCA", "DEA", "DEA", "LAA", "KCA", "LAA" );
leaderData17 = new Array( ".348", ".333", ".300", ".222", ".200", ".188", ".167", ".118", ".067", ".063" );

leaderName18 = new Array( "A.Gonzalez", "L.Berkman", "R.Cano", "J.Ellsbury", "C.Granderson", "E.Hosmer", "N.Swisher", "R.Braun", "C.Gonzalez", "M.Teixeira" );
leaderTeam18 = new Array( "BAA", "SEA", "NYA", "BOA", "DEA", "KCA", "NYA", "CHA", "OAA", "NYA" );
leaderData18 = new Array( ".645", ".575", ".572", ".566", ".548", ".543", ".540", ".529", ".524", ".515" );

leaderName19 = new Array( "A.Gonzalez", "L.Berkman", "B.Abreu", "C.Gonzalez", "C.Kotchman", "C.Beltran", "N.Swisher", "M.Holliday", "M.Wieters", "D.Ortiz" );
leaderTeam19 = new Array( "BAA", "SEA", "NYA", "OAA", "DEA", "CLA", "NYA", "LAA", "BAA", "BOA" );
leaderData19 = new Array( ".440", ".423", ".390", ".389", ".388", ".382", ".381", ".376", ".375", ".371" );

leaderName20 = new Array( "A.Gonzalez", "L.Berkman", "J.Ellsbury", "C.Gonzalez", "R.Cano", "N.Swisher", "E.Hosmer", "C.Granderson", "V.Guerrero", "I.Kinsler" );
leaderTeam20 = new Array( "BAA", "SEA", "BOA", "OAA", "NYA", "NYA", "KCA", "DEA", "BAA", "TOA" );
leaderData20 = new Array( "10.6", " 9.6", " 8.0", " 7.9", " 7.8", " 7.3", " 7.1", " 7.0", " 6.7", " 6.6" );

leaderName21 = new Array( "A.Gonzalez", "L.Berkman", "J.Ellsbury", "C.Gonzalez", "C.Granderson", "R.Cano", "N.Swisher", "I.Kinsler", "E.Hosmer", "R.Braun" );
leaderTeam21 = new Array( "BAA", "SEA", "BOA", "OAA", "DEA", "NYA", "NYA", "TOA", "KCA", "CHA" );
leaderData21 = new Array( "1.146", "1.093", "1.034", ".980", ".979", ".957", ".948", ".937", ".918", ".900" );

leaderName22 = new Array( "A.Gonzalez", "J.Ellsbury", "R.Cano", "E.Hosmer", "R.Braun", "C.Granderson", "M.Teixeira", "V.Guerrero", "L.Berkman", "I.Kinsler" );
leaderTeam22 = new Array( "BAA", "BOA", "NYA", "KCA", "CHA", "DEA", "NYA", "BAA", "SEA", "TOA" );
leaderData22 = new Array( "302", "276", "261", "250", "240", "230", "227", "214", "212", "205" );

leaderName23 = new Array( "V.Guerrero", "R.Braun", "A.Huff", "M.Wieters", "A.Gonzalez", "B.Boesch", "D.Pedroia", "B.Butler", "R.Andino", "B.Revere" );
leaderTeam23 = new Array( "BAA", "CHA", "CLA", "BAA", "BAA", "DEA", "BOA", "KCA", "BAA", "CLA" );
leaderData23 = new Array( ".392", ".379", ".373", ".372", ".363", ".359", ".340", ".338", ".336", ".333" );

leaderName24 = new Array( "C.Young", "M.Teixeira", "R.Raburn", "M.Cameron", "M.Reynolds", "B.Butler", "C.Gomez", "V.Wells", "R.Braun", "B.Lillibridge" );
leaderTeam24 = new Array( "BAA", "NYA", "DEA", "OAA", "BAA", "KCA", "***", "BOA", "CHA", "CHA" );
leaderData24 = new Array( "14", "13", "12", "9", "8", "8", "7", "7", "7", "7" );

leaderName25 = new Array( "A.Gonzalez", "J.Mauer", "R.Cano", "E.Hosmer", "G.Parra", "C.Gonzalez", "M.Brantley", "W.Betemit", "L.Berkman", "V.Guerrero" );
leaderTeam25 = new Array( "BAA", "MNA", "NYA", "KCA", "CHA", "OAA", "CLA", "DEA", "SEA", "BAA" );
leaderData25 = new Array( ".384", ".348", ".341", ".338", ".333", ".329", ".321", ".318", ".318", ".318" );

leaderName26 = new Array( "A.Gonzalez", "M.Reynolds", "C.Granderson", "M.Teixeira", "L.Berkman", "D.Uggla", "J.Ellsbury", "E.Hosmer", "R.Cano", "M.Napoli" );
leaderTeam26 = new Array( "BAA", "BAA", "DEA", "NYA", "SEA", "LAA", "BOA", "KCA", "NYA", "LAA" );
leaderData26 = new Array( "28", "26", "23", "23", "22", "21", "19", "19", "19", "18" );

leaderName27 = new Array( "D.Fister", "F.Hernandez", "Z.Greinke", "D.Haren", "M.Harrison", "R.Halladay", "J.Verlander", "R.Romero", "J.Beckett", "W.Rodriguez" );
leaderTeam27 = new Array( "SEA", "SEA", "KCA", "OAA", "BOA", "CHA", "DEA", "TOA", "BOA", "LAA" );
leaderData27 = new Array( "15", "15", "13", "13", "12", "12", "12", "12", "11", "11" );

leaderName28 = new Array( "B.Myers", "C.Volstad", "J.Vargas", "C.Lewis", "F.Liriano", "G.Gonzalez", "M.Latos", "R.Porcello", "C.Pavano", "M.Buehrle" );
leaderTeam28 = new Array( "KCA", "TOA", "MNA", "TOA", "MNA", "OAA", "BAA", "DEA", "MNA", "CHA" );
leaderData28 = new Array( "15", "15", "14", "14", "13", "13", "12", "12", "12", "11" );

leaderName29 = new Array( "D.Fister", "J.Pineiro", "M.Harrison", "F.Hernandez", "E.Bedard", "Z.Greinke", "J.Happ", "B.Morrow", "J.Danks", "J.Beckett" );
leaderTeam29 = new Array( "SEA", "SEA", "BOA", "SEA", "BOA", "KCA", "NYA", "SEA", "CHA", "BOA" );
leaderData29 = new Array( ".833", ".818", ".800", ".789", ".769", ".722", ".714", ".714", ".692", ".688" );

leaderName30 = new Array( "D.Fister", "J.Verlander", "D.Haren", "B.Morrow", "S.Marcum", "T.Lilly", "J.Lester", "J.Beckett", "J.Weaver", "R.Halladay" );
leaderTeam30 = new Array( "SEA", "DEA", "OAA", "SEA", "CLA", "KCA", "BOA", "BOA", "LAA", "CHA" );
leaderData30 = new Array( " 1.67", " 2.30", " 2.32", " 3.05", " 3.06", " 3.11", " 3.40", " 3.47", " 3.52", " 3.52" );

leaderName31 = new Array( "J.Verlander", "R.Halladay", "D.Haren", "F.Hernandez", "D.Fister", "J.Weaver", "W.Rodriguez", "C.Sabathia", "T.Lilly", "D.Hudson" );
leaderTeam31 = new Array( "DEA", "CHA", "OAA", "SEA", "SEA", "LAA", "LAA", "CLA", "KCA", "CLA" );
leaderData31 = new Array( "191.1", "189.0", "186.1", "183.2", "177.1", "176.2", "170.2", "169.1", "167.2", "165.1" );

leaderName32 = new Array( "R.Halladay", "F.Hernandez", "J.Weaver", "J.Verlander", "D.Haren", "C.Sabathia", "J.Masterson", "W.Rodriguez", "T.Lilly", "J.Vargas" );
leaderTeam32 = new Array( "CHA", "SEA", "LAA", "DEA", "OAA", "CLA", "CLA", "LAA", "KCA", "MNA" );
leaderData32 = new Array( "798", "765", "747", "746", "732", "723", "708", "700", "693", "683" );

leaderName33 = new Array( "J.Karstens", "N.Feliz", "A.Aceves", "F.Cordero", "J.Johnson", "B.League", "J.Papelbon", "C.Sale", "R.Ramirez", "D.Hernandez" );
leaderTeam33 = new Array( "OAA", "BAA", "BOA", "TOA", "BAA", "SEA", "BOA", "CHA", "NYA", "BAA" );
leaderData33 = new Array( "53", "49", "47", "46", "45", "44", "42", "41", "41", "40" );

leaderName34 = new Array( "F.Hernandez", "M.Buehrle", "R.Halladay", "J.Verlander", "W.Rodriguez", "D.Haren", "D.Fister", "U.Jimenez", "I.Nova", "M.Latos" );
leaderTeam34 = new Array( "SEA", "CHA", "CHA", "DEA", "LAA", "OAA", "SEA", "BAA", "BAA", "BAA" );
leaderData34 = new Array( "25", "24", "24", "24", "24", "24", "24", "23", "23", "23" );

leaderName35 = new Array( "J.Verlander", "D.Haren", "D.Fister", "R.Halladay", "T.Lilly", "F.Hernandez", "J.Danks", "J.Beckett", "J.Weaver", "J.Vargas" );
leaderTeam35 = new Array( "DEA", "OAA", "SEA", "CHA", "KCA", "SEA", "CHA", "BOA", "LAA", "MNA" );
leaderData35 = new Array( "11", "9", "8", "7", "7", "7", "6", "5", "5", "5" );

leaderName36 = new Array( "N.Feliz", "J.Karstens", "F.Francisco", "J.Papelbon", "B.League", "B.Fuentes", "M.Rivera", "M.Melancon", "S.Santos", "C.Perez" );
leaderTeam36 = new Array( "BAA", "OAA", "DEA", "BOA", "SEA", "LAA", "NYA", "KCA", "TOA", "CLA" );
leaderData36 = new Array( "43", "40", "38", "37", "35", "32", "31", "29", "27", "26" );

leaderName37 = new Array( "J.Papelbon", "N.Feliz", "B.League", "F.Francisco", "M.Rivera", "B.Fuentes", "S.Santos", "C.Perez", "H.Street", "M.Melancon" );
leaderTeam37 = new Array( "BOA", "BAA", "SEA", "DEA", "NYA", "LAA", "TOA", "CLA", "OAA", "KCA" );
leaderData37 = new Array( "33", "30", "27", "25", "22", "20", "20", "18", "17", "16" );

leaderName38 = new Array( "M.Rivera", "M.Melancon", "G.Holland", "S.Santos", "J.Papelbon", "H.Street", "N.Feliz", "B.League", "C.Sale", "B.Fuentes" );
leaderTeam38 = new Array( "NYA", "KCA", "KCA", "TOA", "BOA", "OAA", "BAA", "SEA", "CHA", "LAA" );
leaderData38 = new Array( ".957", ".941", ".917", ".870", ".868", ".850", ".833", ".818", ".769", ".769" );

leaderName39 = new Array( "J.Beckett", "J.Verlander", "D.Fister", "R.Halladay", "D.Haren", "S.Marcum", "B.Myers", "U.Jimenez", "M.Latos", "J.Danks" );
leaderTeam39 = new Array( "BOA", "DEA", "SEA", "CHA", "OAA", "CLA", "KCA", "BAA", "BAA", "CHA" );
leaderData39 = new Array( "4", "4", "4", "3", "3", "2", "2", "1", "1", "1" );

leaderName40 = new Array( "R.Halladay", "J.Vargas", "C.Pavano", "J.Masterson", "C.Sabathia", "F.Hernandez", "J.Weaver", "T.Cahill", "D.Hudson", "B.Myers" );
leaderTeam40 = new Array( "CHA", "MNA", "MNA", "CLA", "CLA", "SEA", "LAA", "OAA", "CLA", "KCA" );
leaderData40 = new Array( "207", "199", "189", "174", "171", "171", "165", "165", "164", "164" );

leaderName41 = new Array( "T.Cahill", "B.Myers", "J.Vargas", "A.Burnett", "C.Volstad", "M.Buehrle", "J.Masterson", "C.Lewis", "D.Lowe", "C.Pavano" );
leaderTeam41 = new Array( "OAA", "KCA", "MNA", "NYA", "TOA", "CHA", "CLA", "TOA", "TOA", "MNA" );
leaderData41 = new Array( "105", "100", "98", "97", "95", "92", "90", "89", "88", "87" );

leaderName42 = new Array( "B.Myers", "J.Vargas", "T.Cahill", "A.Burnett", "C.Volstad", "C.Pavano", "J.Masterson", "F.Hernandez", "C.Lewis", "D.Lowe" );
leaderTeam42 = new Array( "KCA", "MNA", "OAA", "NYA", "TOA", "MNA", "CLA", "SEA", "TOA", "TOA" );
leaderData42 = new Array( "97", "94", "90", "89", "83", "82", "81", "81", "81", "81" );

leaderName43 = new Array( "C.Volstad", "A.Burnett", "C.Lewis", "R.Romero", "B.Cecil", "A.Sanchez", "J.Beckett", "L.Hochevar", "J.Weaver", "R.Nolasco" );
leaderTeam43 = new Array( "TOA", "NYA", "TOA", "TOA", "TOA", "LAA", "BOA", "KCA", "LAA", "NYA" );
leaderData43 = new Array( "31", "29", "25", "25", "24", "23", "22", "22", "22", "22" );

leaderName44 = new Array( "E.Volquez", "G.Gonzalez", "J.Masterson", "B.Morrow", "J.Lester", "J.Happ", "R.Romero", "U.Jimenez", "C.Sabathia", "J.Vargas" );
leaderTeam44 = new Array( "LAA", "OAA", "CLA", "SEA", "BOA", "NYA", "TOA", "BAA", "CLA", "MNA" );
leaderData44 = new Array( "72", "65", "64", "63", "62", "61", "61", "60", "60", "59" );

leaderName45 = new Array( "J.Verlander", "F.Hernandez", "R.Halladay", "Z.Greinke", "J.Weaver", "C.Sabathia", "G.Gonzalez", "D.Haren", "J.Beckett", "W.Rodriguez" );
leaderTeam45 = new Array( "DEA", "SEA", "CHA", "KCA", "LAA", "CLA", "OAA", "OAA", "BOA", "LAA" );
leaderData45 = new Array( "182", "178", "168", "166", "166", "162", "156", "147", "144", "144" );

leaderName46 = new Array( "T.Cahill", "I.Nova", "F.Liriano", "A.Burnett", "B.Morrow", "M.Harrison", "G.Holland", "R.Ramirez", "T.Wakefield", "U.Jimenez" );
leaderTeam46 = new Array( "OAA", "BAA", "MNA", "NYA", "SEA", "BOA", "KCA", "NYA", "NYA", "BAA" );
leaderData46 = new Array( "18", "11", "10", "10", "9", "8", "8", "8", "8", "7" );

leaderName47 = new Array( "A.Sanchez", "M.Harrison", "R.Halladay", "T.Lilly", "C.Pavano", "D.Hernandez", "J.Johnson", "D.Oliver", "D.Hudson", "E.Volquez" );
leaderTeam47 = new Array( "LAA", "BOA", "CHA", "KCA", "MNA", "BAA", "CHA", "CHA", "CLA", "LAA" );
leaderData47 = new Array( "6", "3", "3", "3", "3", "2", "2", "2", "2", "2" );

leaderName48 = new Array( "U.Jimenez", "C.Wilson", "J.Francis", "B.Chen", "W.Rodriguez", "R.Nolasco", "D.Haren", "F.Hernandez", "C.Lewis", "D.Lowe" );
leaderTeam48 = new Array( "BAA", "CLA", "DEA", "KCA", "LAA", "NYA", "OAA", "SEA", "TOA", "TOA" );
leaderData48 = new Array( "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00" );

leaderName49 = new Array( "F.Hernandez", "D.Lowe", "T.Lilly", "E.Volquez", "J.Lackey", "F.Garcia", "A.Burnett", "T.Cahill", "M.Latos", "C.Wilson" );
leaderTeam49 = new Array( "SEA", "TOA", "KCA", "LAA", "LAA", "CHA", "NYA", "OAA", "BAA", "CLA" );
leaderData49 = new Array( "49", "45", "41", "38", "31", "28", "26", "26", "25", "25" );

leaderName50 = new Array( "F.Liriano", "R.Romero", "A.Sanchez", "W.Rodriguez", "C.Lewis", "J.Karstens", "R.Nolasco", "R.Porcello", "A.Burnett", "D.Hudson" );
leaderTeam50 = new Array( "MNA", "TOA", "LAA", "LAA", "TOA", "OAA", "NYA", "DEA", "NYA", "CLA" );
leaderData50 = new Array( ".33", ".50", ".53", ".54", ".57", ".60", ".63", ".63", ".67", ".68" );

leaderName51 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderTeam51 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderData51 = new Array( "", "", "", "", "", "", "", "", "", "" );

leaderName52 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderTeam52 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderData52 = new Array( "", "", "", "", "", "", "", "", "", "" );

leaderName53 = new Array( "J.Verlander", "D.Fister", "B.Morrow", "J.Beckett", "J.Lester", "M.Pineda", "C.Wilson", "R.Romero", "D.Haren", "Z.Greinke" );
leaderTeam53 = new Array( "DEA", "SEA", "SEA", "BOA", "BOA", "SEA", "CLA", "TOA", "OAA", "KCA" );
leaderData53 = new Array( " 5.8", " 5.8", " 6.4", " 6.8", " 7.3", " 7.4", " 7.4", " 7.5", " 7.7", " 8.0" );

leaderName54 = new Array( "D.Haren", "D.Fister", "S.Marcum", "R.Halladay", "J.Beckett", "D.Hudson", "C.Volstad", "R.Nolasco", "J.Verlander", "J.Shields" );
leaderTeam54 = new Array( "OAA", "SEA", "CLA", "CHA", "BOA", "CLA", "TOA", "NYA", "DEA", "MNA" );
leaderData54 = new Array( " 1.1", " 1.2", " 1.8", " 1.9", " 2.0", " 2.1", " 2.2", " 2.3", " 2.4", " 2.4" );

leaderName55 = new Array( "Z.Greinke", "M.Pineda", "B.Morrow", "G.Gonzalez", "J.Beckett", "F.Hernandez", "C.Sabathia", "J.Verlander", "J.Weaver", "U.Jimenez" );
leaderTeam55 = new Array( "KCA", "SEA", "SEA", "OAA", "BOA", "SEA", "CLA", "DEA", "LAA", "BAA" );
leaderData55 = new Array( " 9.9", " 9.1", " 9.0", " 8.9", " 8.8", " 8.7", " 8.6", " 8.6", " 8.5", " 8.0" );

leaderName56 = new Array( "R.Halladay", "D.Fister", "S.Marcum", "M.Harrison", "M.Latos", "C.Wilson", "D.Haren", "B.Morrow", "F.Hernandez", "C.Pavano" );
leaderTeam56 = new Array( "CHA", "SEA", "CLA", "BOA", "BAA", "CLA", "OAA", "SEA", "SEA", "MNA" );
leaderData56 = new Array( " 0.29", " 0.46", " 0.47", " 0.58", " 0.75", " 0.77", " 0.77", " 0.80", " 0.83", " 0.85" );

