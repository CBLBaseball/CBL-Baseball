leaderName0 = new Array( "H.Pence", "V.Martinez", "M.Cabrera", "E.Bonifacio", "M.Bourn", "J.Votto", "M.Kemp", "M.Young", "E.Aybar", "J.Bautista" );
leaderTeam0 = new Array( "HON", "PHN", "SLN", "ATN", "HON", "CIN", "LAN", "PHN", "SLN", "PHN" );
leaderData0 = new Array( ".344", ".336", ".319", ".314", ".312", ".312", ".308", ".307", ".307", ".302" );

leaderName1 = new Array( "M.Cabrera", "B.Phillips", "M.Young", "E.Aybar", "J.Upton", "S.Castro", "E.Andrus", "H.Pence", "M.Cabrera", "R.Ibanez" );
leaderTeam1 = new Array( "SFN", "CIN", "PHN", "SLN", "WAN", "CHN", "WAN", "HON", "SLN", "SDN" );
leaderData1 = new Array( "494", "466", "466", "466", "460", "459", "457", "456", "454", "454" );

leaderName2 = new Array( "J.Bautista", "J.Votto", "A.Pujols", "M.Kemp", "M.Young", "H.Pence", "E.Aybar", "M.Cabrera", "M.Bourn", "P.Fielder" );
leaderTeam2 = new Array( "PHN", "CIN", "PIN", "LAN", "PHN", "HON", "SLN", "SLN", "HON", "WAN" );
leaderData2 = new Array( "93", "83", "75", "74", "73", "72", "72", "71", "68", "68" );

leaderName3 = new Array( "H.Pence", "M.Cabrera", "M.Cabrera", "M.Young", "E.Aybar", "M.Kemp", "M.Bourn", "B.Phillips", "J.Votto", "E.Andrus" );
leaderTeam3 = new Array( "HON", "SFN", "SLN", "PHN", "SLN", "LAN", "HON", "CIN", "CIN", "WAN" );
leaderData3 = new Array( "157", "149", "145", "143", "143", "139", "138", "137", "130", "129" );

leaderName4 = new Array( "M.Young", "M.Cabrera", "D.Fowler", "H.Pence", "B.Zobrist", "M.Bourn", "J.Guzman", "M.Montero", "V.Martinez", "M.Cabrera" );
leaderTeam4 = new Array( "PHN", "SLN", "WAN", "HON", "SLN", "HON", "SDN", "WAN", "PHN", "SFN" );
leaderData4 = new Array( "37", "37", "31", "30", "30", "29", "29", "29", "28", "28" );

leaderName5 = new Array( "S.Victorino", "C.Maybin", "D.Fowler", "M.Bourn", "S.Smith", "E.Aybar", "H.Kendrick", "M.Stanton", "O.Infante", "R.Davis" );
leaderTeam5 = new Array( "PHN", "SLN", "WAN", "HON", "NYN", "SLN", "SFN", "ATN", "ATN", "ATN" );
leaderData5 = new Array( "11", "10", "10", "8", "7", "7", "7", "6", "5", "5" );

leaderName6 = new Array( "A.Pujols", "J.Bautista", "J.Votto", "J.Bruce", "P.Fielder", "M.Kemp", "M.Stanton", "A.Beltre", "F.Freeman", "T.Tulowitzki" );
leaderTeam6 = new Array( "PIN", "PHN", "CIN", "CIN", "WAN", "LAN", "ATN", "HON", "ATN", "HON" );
leaderData6 = new Array( "36", "33", "29", "27", "27", "26", "25", "24", "23", "22" );

leaderName7 = new Array( "J.Bautista", "A.Pujols", "J.Votto", "P.Fielder", "H.Pence", "R.Howard", "M.Cabrera", "F.Freeman", "M.Stanton", "J.Bruce" );
leaderTeam7 = new Array( "PHN", "PIN", "CIN", "WAN", "HON", "PHN", "SLN", "ATN", "ATN", "CIN" );
leaderData7 = new Array( "97", "91", "77", "76", "75", "74", "72", "71", "71", "71" );

leaderName8 = new Array( "J.Bautista", "J.Votto", "M.Cabrera", "B.Zobrist", "R.Howard", "G.Sanchez", "C.Pena", "A.McCutchen", "E.Longoria", "D.Fowler" );
leaderTeam8 = new Array( "PHN", "CIN", "SLN", "SLN", "PHN", "HON", "LAN", "PIN", "SDN", "WAN" );
leaderData8 = new Array( "95", "87", "70", "69", "63", "61", "61", "60", "60", "55" );

leaderName9 = new Array( "V.Martinez", "M.Kemp", "M.Young", "M.Cabrera", "H.Pence", "M.Bourn", "R.Ibanez", "R.Tejada", "S.Castro", "B.Phillips" );
leaderTeam9 = new Array( "PHN", "LAN", "PHN", "SLN", "HON", "HON", "SDN", "ATN", "CHN", "CIN" );
leaderData9 = new Array( "12", "10", "10", "10", "8", "7", "6", "5", "5", "5" );

leaderName10 = new Array( "D.Stubbs", "B.Upton", "M.Kemp", "J.Bruce", "D.Espinosa", "D.Fowler", "J.Werth", "M.Stanton", "J.Upton", "R.Howard" );
leaderTeam10 = new Array( "CIN", "SFN", "LAN", "CIN", "WAN", "WAN", "WAN", "ATN", "WAN", "PHN" );
leaderData10 = new Array( "148", "138", "128", "126", "120", "116", "111", "110", "106", "105" );

leaderName11 = new Array( "C.Utley", "D.Espinosa", "J.Upton", "C.Quentin", "E.Aybar", "P.Fielder", "M.Byrd", "J.Turner", "J.Willingham", "D.Fowler" );
leaderTeam11 = new Array( "PHN", "WAN", "WAN", "HON", "SLN", "WAN", "CHN", "NYN", "SFN", "WAN" );
leaderData11 = new Array( "14", "14", "14", "13", "11", "11", "9", "9", "9", "9" );

leaderName12 = new Array( "A.Torres", "K.Fukudome", "C.Denorfia", "J.Carroll", "E.Aybar", "D.Descalso", "C.Maybin", "O.Hudson", "E.Longoria", "R.Ibanez" );
leaderTeam12 = new Array( "NYN", "NYN", "SDN", "SDN", "SLN", "SLN", "SLN", "SDN", "SDN", "SDN" );
leaderData12 = new Array( "25", "22", "17", "16", "15", "14", "12", "12", "12", "12" );

leaderName13 = new Array( "M.Bourn", "E.Andrus", "C.Maybin", "S.Castro", "M.Cabrera", "E.Aybar", "M.Kemp", "R.Davis", "B.Upton", "E.Bonifacio" );
leaderTeam13 = new Array( "HON", "WAN", "SLN", "CHN", "SFN", "SLN", "LAN", "ATN", "SFN", "ATN" );
leaderData13 = new Array( "54", "42", "40", "33", "33", "31", "30", "26", "25", "24" );

leaderName14 = new Array( "C.Gentry", "E.Bonifacio", "X.Paul", "T.Gwynn Jr", "J.Rollins", "J.Bartlett", "D.Gordon", "S.Castro", "M.Cabrera", "I.Desmond" );
leaderTeam14 = new Array( "CHN", "ATN", "LAN", "PHN", "PHN", "CIN", "LAN", "CHN", "SFN", "SFN" );
leaderData14 = new Array( ".95", ".92", ".92", ".89", ".88", ".87", ".85", ".82", ".82", ".82" );

leaderName15 = new Array( "A.Pujols", "M.Young", "S.Castro", "M.Joyce", "M.Cabrera", "M.Stanton", "H.Pence", "P.Fielder", "M.Montero", "Y.Molina" );
leaderTeam15 = new Array( "PIN", "PHN", "CHN", "CHN", "SLN", "ATN", "HON", "WAN", "WAN", "SLN" );
leaderData15 = new Array( "25", "21", "19", "19", "18", "17", "17", "17", "17", "16" );

leaderName16 = new Array( "E.Aybar", "E.Andrus", "T.Hafner", "D.Fowler", "A.Callaspo", "T.Campana", "J.Turner", "E.Bonifacio", "O.Infante", "B.McCann" );
leaderTeam16 = new Array( "SLN", "WAN", "PIN", "WAN", "CHN", "CHN", "NYN", "ATN", "ATN", "ATN" );
leaderData16 = new Array( "6", "6", "5", "5", "4", "4", "4", "3", "3", "3" );

leaderName17 = new Array( "J.Constanza", "P.Sandoval", "R.Doumit", "J.Giambi", "G.Jones", "", "", "", "", "" );
leaderTeam17 = new Array( "CIN", "SFN", "PIN", "LAN", "PIN", "", "", "", "", "" );
leaderData17 = new Array( ".529", ".467", ".235", ".125", ".125", "0", "0", "0", "0", "0" );

leaderName18 = new Array( "A.Pujols", "J.Bautista", "J.Votto", "M.Stanton", "H.Pence", "M.Kemp", "L.Morrison", "M.Cabrera", "P.Fielder", "M.Joyce" );
leaderTeam18 = new Array( "PIN", "PHN", "CIN", "ATN", "HON", "LAN", "SLN", "SLN", "WAN", "CHN" );
leaderData18 = new Array( ".605", ".594", ".590", ".575", ".555", ".548", ".544", ".531", ".527", ".514" );

leaderName19 = new Array( "J.Bautista", "J.Votto", "H.Pence", "M.Cabrera", "V.Martinez", "M.Kemp", "E.Bonifacio", "P.Fielder", "M.Bourn", "J.Peralta" );
leaderTeam19 = new Array( "PHN", "CIN", "HON", "SLN", "PHN", "LAN", "ATN", "WAN", "HON", "NYN" );
leaderData19 = new Array( ".431", ".430", ".410", ".410", ".401", ".380", ".376", ".372", ".370", ".367" );

leaderName20 = new Array( "J.Votto", "J.Bautista", "H.Pence", "M.Cabrera", "V.Martinez", "M.Kemp", "P.Fielder", "F.Freeman", "M.Stanton", "E.Bonifacio" );
leaderTeam20 = new Array( "CIN", "PHN", "HON", "SLN", "PHN", "LAN", "WAN", "ATN", "ATN", "ATN" );
leaderData20 = new Array( "10.2", "10.1", " 8.3", " 7.9", " 7.4", " 7.3", " 6.8", " 6.5", " 6.5", " 6.4" );

leaderName21 = new Array( "J.Bautista", "J.Votto", "M.Kemp", "M.Cabrera", "H.Pence", "A.Pujols", "M.Stanton", "P.Fielder", "V.Martinez", "L.Morrison" );
leaderTeam21 = new Array( "PHN", "CIN", "LAN", "SLN", "HON", "PIN", "ATN", "WAN", "PHN", "SLN" );
leaderData21 = new Array( "1.170", "1.146", ".988", ".963", ".959", ".916", ".902", ".892", ".888", ".854" );

leaderName22 = new Array( "H.Pence", "M.Kemp", "J.Votto", "A.Pujols", "M.Cabrera", "J.Bautista", "P.Fielder", "M.Cabrera", "B.Phillips", "E.Aybar" );
leaderTeam22 = new Array( "HON", "LAN", "CIN", "PIN", "SLN", "PHN", "WAN", "SFN", "CIN", "SLN" );
leaderData22 = new Array( "253", "247", "246", "242", "241", "238", "232", "229", "219", "217" );

leaderName23 = new Array( "J.Sands", "A.Ramirez", "J.Carroll", "H.Pence", "E.Bonifacio", "J.Donald", "M.Kemp", "G.Sanchez", "S.Victorino", "M.Cabrera" );
leaderTeam23 = new Array( "LAN", "CHN", "SDN", "HON", "ATN", "PHN", "LAN", "HON", "PHN", "SFN" );
leaderData23 = new Array( ".400", ".395", ".386", ".382", ".370", ".361", ".343", ".340", ".337", ".336" );

leaderName24 = new Array( "A.Ellis", "J.Bautista", "G.Soto", "J.Bruce", "H.Pence", "J.Rollins", "F.Freeman", "T.Tulowitzki", "M.Kemp", "C.Gomez" );
leaderTeam24 = new Array( "LAN", "PHN", "CHN", "CIN", "HON", "PHN", "ATN", "HON", "LAN", "***" );
leaderData24 = new Array( "10", "10", "8", "8", "8", "8", "7", "7", "7", "7" );

leaderName25 = new Array( "V.Martinez", "P.Sandoval", "E.Aybar", "M.Cabrera", "T.Hafner", "H.Pence", "F.Freeman", "J.Loney", "J.Peralta", "M.Young" );
leaderTeam25 = new Array( "PHN", "SFN", "SLN", "SLN", "PIN", "HON", "ATN", "LAN", "NYN", "PHN" );
leaderData25 = new Array( ".367", ".362", ".345", ".344", ".340", ".333", ".330", ".327", ".323", ".319" );

leaderName26 = new Array( "A.Pujols", "J.Votto", "J.Bautista", "P.Fielder", "L.Morrison", "P.Sandoval", "M.Stanton", "J.Bruce", "M.Kemp", "A.Beltre" );
leaderTeam26 = new Array( "PIN", "CIN", "PHN", "WAN", "SLN", "SFN", "ATN", "CIN", "LAN", "HON" );
leaderData26 = new Array( "32", "24", "23", "22", "20", "20", "19", "19", "19", "18" );

leaderName27 = new Array( "C.Lee", "C.Hamels", "J.Tomlin", "I.Kennedy", "T.Hudson", "R.Oswalt", "T.Hanson", "T.Lincecum", "J.Vazquez", "R.Dickey" );
leaderTeam27 = new Array( "PHN", "PHN", "CHN", "PHN", "ATN", "HON", "ATN", "SFN", "ATN", "NYN" );
leaderData27 = new Array( "17", "15", "14", "14", "13", "13", "12", "12", "11", "11" );

leaderName28 = new Array( "T.Stauffer", "J.Chacin", "C.Billingsley", "C.Carpenter", "E.Jackson", "B.Colon", "Y.Gallardo", "J.Reyes", "R.Dempster", "B.Arroyo" );
leaderTeam28 = new Array( "SDN", "HON", "LAN", "LAN", "SDN", "SDN", "HON", "SFN", "CHN", "CIN" );
leaderData28 = new Array( "13", "12", "12", "12", "12", "12", "11", "11", "10", "10" );

leaderName29 = new Array( "T.Hanson", "C.Lee", "C.Hamels", "J.Tomlin", "I.Kennedy", "T.Hudson", "K.Lohse", "R.Oswalt", "T.Lincecum", "C.Carrasco" );
leaderTeam29 = new Array( "ATN", "PHN", "PHN", "CHN", "PHN", "ATN", "SLN", "HON", "SFN", "CIN" );
leaderData29 = new Array( ".857", ".810", ".789", ".778", ".778", ".765", ".688", ".684", ".667", ".643" );

leaderName30 = new Array( "G.Floyd", "J.Hellickson", "C.Kershaw", "T.Lincecum", "K.Lohse", "T.Hudson", "J.Tomlin", "D.Price", "C.Hamels", "A.Ogando" );
leaderTeam30 = new Array( "SLN", "WAN", "LAN", "SFN", "SLN", "ATN", "CHN", "HON", "PHN", "PHN" );
leaderData30 = new Array( " 2.36", " 2.55", " 2.71", " 2.81", " 2.91", " 2.98", " 2.99", " 3.00", " 3.00", " 3.07" );

leaderName31 = new Array( "T.Lincecum", "M.Cain", "C.Lee", "C.Carpenter", "I.Kennedy", "C.Kershaw", "D.Price", "C.Hamels", "T.Hudson", "J.Tomlin" );
leaderTeam31 = new Array( "SFN", "SFN", "PHN", "LAN", "PHN", "LAN", "HON", "PHN", "ATN", "CHN" );
leaderData31 = new Array( "186.0", "184.0", "176.0", "169.2", "163.0", "162.2", "162.0", "162.0", "154.0", "153.2" );

leaderName32 = new Array( "T.Lincecum", "M.Cain", "C.Carpenter", "C.Lee", "C.Kershaw", "I.Kennedy", "D.Price", "E.Jackson", "M.Bumgarner", "C.Hamels" );
leaderTeam32 = new Array( "SFN", "SFN", "LAN", "PHN", "LAN", "PHN", "HON", "SDN", "SFN", "PHN" );
leaderData32 = new Array( "769", "763", "720", "713", "690", "685", "681", "658", "658", "651" );

leaderName33 = new Array( "T.Gorzelanny", "N.Masset", "J.Hanrahan", "J.Benoit", "D.Storen", "C.Marmol", "S.Marshall", "J.Venters", "C.Martinez", "G.Balfour" );
leaderTeam33 = new Array( "CHN", "CIN", "PIN", "HON", "WAN", "CHN", "SLN", "ATN", "ATN", "HON" );
leaderData33 = new Array( "60", "50", "47", "46", "46", "45", "43", "40", "40", "40" );

leaderName34 = new Array( "T.Hudson", "C.Carpenter", "H.Kuroda", "T.Lincecum", "D.Holland", "J.Vazquez", "R.Dempster", "J.Chacin", "Y.Gallardo", "D.Price" );
leaderTeam34 = new Array( "ATN", "LAN", "LAN", "SFN", "ATN", "ATN", "CHN", "HON", "HON", "HON" );
leaderData34 = new Array( "24", "24", "24", "24", "23", "23", "23", "23", "23", "23" );

leaderName35 = new Array( "C.Lee", "T.Lincecum", "M.Cain", "C.Carpenter", "C.Hamels", "J.Collmenter", "C.Kershaw", "I.Kennedy", "J.Reyes", "D.Price" );
leaderTeam35 = new Array( "PHN", "SFN", "SFN", "LAN", "PHN", "CHN", "LAN", "PHN", "SFN", "HON" );
leaderData35 = new Array( "10", "10", "9", "7", "7", "6", "6", "6", "6", "5" );

leaderName36 = new Array( "J.Hanrahan", "D.Storen", "C.Marmol", "H.Takahashi", "F.Rodriguez", "J.Valverde", "T.Gorzelanny", "J.Venters", "C.Kimbrel", "N.Masset" );
leaderTeam36 = new Array( "PIN", "WAN", "CHN", "CIN", "NYN", "SDN", "CHN", "ATN", "ATN", "CIN" );
leaderData36 = new Array( "40", "40", "33", "28", "28", "28", "26", "25", "24", "23" );

leaderName37 = new Array( "J.Hanrahan", "C.Marmol", "F.Rodriguez", "D.Storen", "C.Kimbrel", "J.Putz", "J.Valverde", "J.Venters", "J.Axford", "H.Takahashi" );
leaderTeam37 = new Array( "PIN", "CHN", "NYN", "WAN", "ATN", "HON", "SDN", "ATN", "LAN", "CIN" );
leaderData37 = new Array( "25", "23", "19", "19", "18", "18", "18", "17", "13", "11" );

leaderName38 = new Array( "J.Venters", "C.Marmol", "B.Wilson", "C.Kimbrel", "J.Putz", "A.Bastardo", "J.Valverde", "J.Hanrahan", "F.Rodriguez", "D.Storen" );
leaderTeam38 = new Array( "ATN", "CHN", "SFN", "ATN", "HON", "PHN", "SDN", "PIN", "NYN", "WAN" );
leaderData38 = new Array( ".944", ".920", ".909", ".857", ".818", ".818", ".818", ".806", ".792", ".760" );

leaderName39 = new Array( "Y.Gallardo", "T.Lincecum", "J.Hellickson", "J.Tomlin", "J.Collmenter", "M.Leake", "D.Price", "C.Carpenter", "C.Kershaw", "H.Kuroda" );
leaderTeam39 = new Array( "HON", "SFN", "WAN", "CHN", "CHN", "CIN", "HON", "LAN", "LAN", "LAN" );
leaderData39 = new Array( "2", "2", "2", "1", "1", "1", "1", "1", "1", "1" );

leaderName40 = new Array( "C.Carpenter", "M.Bumgarner", "E.Jackson", "C.Lee", "H.Kuroda", "M.Pelfrey", "I.Kennedy", "D.Price", "R.Dempster", "M.Cain" );
leaderTeam40 = new Array( "LAN", "SFN", "SDN", "PHN", "LAN", "PIN", "PHN", "HON", "CHN", "SFN" );
leaderData40 = new Array( "178", "170", "166", "161", "160", "159", "155", "154", "152", "151" );

leaderName41 = new Array( "E.Jackson", "C.Billingsley", "B.Arroyo", "C.Narveson", "R.Dempster", "J.Chacin", "H.Kuroda", "I.Kennedy", "J.Guthrie", "J.Reyes" );
leaderTeam41 = new Array( "SDN", "LAN", "CIN", "CIN", "CHN", "HON", "LAN", "PHN", "NYN", "SFN" );
leaderData41 = new Array( "94", "92", "90", "89", "82", "81", "80", "80", "78", "78" );

leaderName42 = new Array( "E.Jackson", "B.Arroyo", "C.Narveson", "J.Reyes", "R.Dempster", "I.Kennedy", "J.Chacin", "C.Billingsley", "C.Lee", "E.Santana" );
leaderTeam42 = new Array( "SDN", "CIN", "CIN", "SFN", "CHN", "PHN", "HON", "LAN", "PHN", "HON" );
leaderData42 = new Array( "88", "84", "80", "77", "76", "75", "74", "74", "74", "72" );

leaderName43 = new Array( "B.Arroyo", "C.Lee", "J.Vazquez", "Y.Gallardo", "J.Saunders", "J.Chacin", "E.Santana", "C.Kershaw", "J.Collmenter", "I.Kennedy" );
leaderTeam43 = new Array( "CIN", "PHN", "ATN", "HON", "WAN", "HON", "HON", "LAN", "CHN", "PHN" );
leaderData43 = new Array( "34", "25", "23", "23", "23", "22", "21", "21", "20", "20" );

leaderName44 = new Array( "T.Lincecum", "C.Narveson", "J.Chacin", "R.Dempster", "M.Cain", "D.Price", "C.Billingsley", "J.Sanchez", "B.Norris", "J.McDonald" );
leaderTeam44 = new Array( "SFN", "CIN", "HON", "CHN", "SFN", "HON", "LAN", "SFN", "WAN", "PIN" );
leaderData44 = new Array( "73", "70", "63", "62", "62", "60", "60", "59", "59", "58" );

leaderName45 = new Array( "C.Kershaw", "C.Lee", "T.Lincecum", "M.Cain", "D.Price", "M.Bumgarner", "M.Garza", "C.Hamels", "I.Kennedy", "J.Chacin" );
leaderTeam45 = new Array( "LAN", "PHN", "SFN", "SFN", "HON", "SFN", "NYN", "PHN", "PHN", "HON" );
leaderData45 = new Array( "186", "186", "185", "158", "157", "150", "148", "146", "146", "126" );

leaderName46 = new Array( "C.Morton", "J.Hanrahan", "T.Lincecum", "J.Reyes", "H.Kuroda", "J.Garcia", "Y.Gallardo", "C.Luebke", "L.Ondrusek", "B.Parnell" );
leaderTeam46 = new Array( "PIN", "PIN", "SFN", "SFN", "LAN", "SLN", "HON", "ATN", "CIN", "NYN" );
leaderData46 = new Array( "12", "11", "11", "10", "9", "9", "8", "7", "7", "7" );

leaderName47 = new Array( "C.Hamels", "C.Luebke", "J.Grabow", "B.Parnell", "V.Worley", "C.Resop", "D.Robertson", "N.Masset", "C.Carpenter", "R.Dickey" );
leaderTeam47 = new Array( "PHN", "ATN", "SDN", "NYN", "PHN", "PIN", "WAN", "CIN", "LAN", "NYN" );
leaderData47 = new Array( "5", "4", "4", "3", "3", "3", "3", "2", "2", "2" );

leaderName48 = new Array( "J.Collmenter", "M.Leake", "C.Narveson", "C.Kershaw", "H.Kuroda", "I.Kennedy", "C.Lee", "A.Ogando", "C.Capuano", "K.Lohse" );
leaderTeam48 = new Array( "CHN", "CIN", "CIN", "LAN", "LAN", "PHN", "PHN", "PHN", "PIN", "SLN" );
leaderData48 = new Array( "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00" );

leaderName49 = new Array( "E.Jackson", "C.Hamels", "D.Moseley", "E.Santana", "T.Hanson", "T.Hudson", "M.Pelfrey", "T.Lincecum", "R.De La Rosa", "A.Harang" );
leaderTeam49 = new Array( "SDN", "PHN", "CHN", "HON", "ATN", "ATN", "PIN", "SFN", "LAN", "SDN" );
leaderData49 = new Array( "33", "31", "27", "26", "24", "23", "23", "23", "18", "18" );

leaderName50 = new Array( "C.Lee", "D.Price", "N.Masset", "M.Cain", "J.Reyes", "L.Gregerson", "C.Morton", "H.Bailey", "T.Hanson", "C.Marmol" );
leaderTeam50 = new Array( "PHN", "HON", "CIN", "SFN", "SFN", "SDN", "PIN", "CIN", "ATN", "CHN" );
leaderData50 = new Array( ".56", ".61", ".67", ".67", ".67", ".69", ".71", ".71", ".73", ".73" );

leaderName51 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderTeam51 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderData51 = new Array( "", "", "", "", "", "", "", "", "", "" );

leaderName52 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderTeam52 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderData52 = new Array( "", "", "", "", "", "", "", "", "", "" );

leaderName53 = new Array( "G.Floyd", "J.Hellickson", "T.Lincecum", "A.Ogando", "M.Cain", "C.Hamels", "F.Carmona", "C.Kershaw", "M.Garza", "J.Tomlin" );
leaderTeam53 = new Array( "SLN", "WAN", "SFN", "PHN", "SFN", "PHN", "SLN", "LAN", "NYN", "CHN" );
leaderData53 = new Array( " 6.4", " 7.0", " 7.1", " 7.1", " 7.4", " 7.8", " 7.8", " 7.9", " 7.9", " 8.0" );

leaderName54 = new Array( "B.Arroyo", "J.Tomlin", "J.Collmenter", "C.Lee", "J.Vazquez", "R.Oswalt", "C.Carpenter", "J.Zimmermann", "C.Hamels", "G.Floyd" );
leaderTeam54 = new Array( "CIN", "CHN", "CHN", "PHN", "ATN", "HON", "LAN", "WAN", "PHN", "SLN" );
leaderData54 = new Array( " 1.7", " 1.8", " 1.8", " 1.9", " 2.1", " 2.1", " 2.1", " 2.1", " 2.2", " 2.2" );

leaderName55 = new Array( "C.Kershaw", "M.Garza", "C.Lee", "T.Lincecum", "M.Bumgarner", "D.Price", "J.Chacin", "B.Norris", "C.Hamels", "I.Kennedy" );
leaderTeam55 = new Array( "LAN", "NYN", "PHN", "SFN", "SFN", "HON", "HON", "WAN", "PHN", "PHN" );
leaderData55 = new Array( "10.3", " 9.5", " 9.5", " 9.0", " 8.8", " 8.7", " 8.3", " 8.1", " 8.1", " 8.1" );

leaderName56 = new Array( "J.Hellickson", "R.Dickey", "C.Carpenter", "G.Floyd", "T.Lincecum", "M.Cain", "L.Hernandez", "K.Lohse", "J.Garcia", "A.Ogando" );
leaderTeam56 = new Array( "WAN", "NYN", "LAN", "SLN", "SFN", "SFN", "SLN", "SLN", "SLN", "PHN" );
leaderData56 = new Array( " 0.40", " 0.56", " 0.69", " 0.70", " 0.73", " 0.73", " 0.73", " 0.78", " 0.80", " 0.84" );

