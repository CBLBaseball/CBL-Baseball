sub = new Array( "AL", "NL" );
sublong = new Array( "American League", "National League" );

AL = new Array( "ALEast", "ALCentral", "ALWest" );
NL = new Array( "NLEast", "NLCentral", "NLWest" );

ALALEast = new Array( "BAA", "BOA", "NYA", "TOA" );

BAA = new Array("ALEast", "Baltimore", "Orioles", "Baltimore Orioles (BAA)", "2012", "114", "64", "50", ".561", ".526", ".596" );
BOA = new Array("ALEast", "Boston", "Red Sox", "Boston Red Sox (BOA)", "2012", "114", "70", "44", ".614", ".596", ".632" );
NYA = new Array("ALEast", "New York (AL)", "Yankees", "New York (AL) Yankees (NYA)", "2012", "114", "54", "60", ".474", ".439", ".509" );
TOA = new Array("ALEast", "Toronto", "Blue Jays", "Toronto Blue Jays (TOA)", "2012", "114", "39", "75", ".342", ".368", ".316" );
ALALCentral = new Array( "CHA", "CLA", "DEA", "MNA" );

CHA = new Array("ALCentral", "Chicago (AL)", "White Sox", "Chicago (AL) White Sox (CHA)", "2012", "114", "64", "50", ".561", ".561", ".561" );
CLA = new Array("ALCentral", "Cleveland", "Indians", "Cleveland Indians (CLA)", "2012", "114", "56", "58", ".491", ".439", ".544" );
DEA = new Array("ALCentral", "Detroit", "Tigers", "Detroit Tigers (DEA)", "2012", "114", "61", "53", ".535", ".491", ".579" );
MNA = new Array("ALCentral", "Minnesota", "Twins", "Minnesota Twins (MNA)", "2012", "114", "42", "72", ".368", ".316", ".421" );
ALALWest = new Array( "KCA", "LAA", "OAA", "SEA" );

KCA = new Array("ALWest", "Kansas City", "Royals", "Kansas City Royals (KCA)", "2012", "114", "56", "58", ".491", ".386", ".596" );
LAA = new Array("ALWest", "Los Angeles(AL)", "Angels", "Los Angeles(AL) Angels (LAA)", "2012", "114", "52", "62", ".456", ".456", ".456" );
OAA = new Array("ALWest", "Oakland", "A's", "Oakland A's (OAA)", "2012", "114", "47", "67", ".412", ".404", ".421" );
SEA = new Array("ALWest", "Seattle", "Mariners", "Seattle Mariners (SEA)", "2012", "114", "78", "36", ".684", ".667", ".702" );
NLNLEast = new Array( "ATN", "NYN", "PHN", "WAN" );

ATN = new Array("NLEast", "Atlanta", "Braves", "Atlanta Braves (ATN)", "2012", "114", "76", "38", ".667", ".614", ".719" );
NYN = new Array("NLEast", "New York (NL)", "Mets", "New York (NL) Mets (NYN)", "2012", "114", "63", "51", ".553", ".474", ".632" );
PHN = new Array("NLEast", "Philadelphia", "Phillies", "Philadelphia Phillies (PHN)", "2012", "114", "79", "35", ".693", ".702", ".684" );
WAN = new Array("NLEast", "Washington", "Nationals", "Washington Nationals (WAN)", "2012", "114", "58", "56", ".509", ".439", ".579" );
NLNLCentral = new Array( "CHN", "CIN", "PIN", "SLN" );

CHN = new Array("NLCentral", "Chicago (NL)", "Cubs", "Chicago (NL) Cubs (CHN)", "2012", "114", "58", "56", ".509", ".368", ".649" );
CIN = new Array("NLCentral", "Cincinnati", "Reds", "Cincinnati Reds (CIN)", "2012", "114", "45", "69", ".395", ".263", ".526" );
PIN = new Array("NLCentral", "Pittsburgh", "Pirates", "Pittsburgh Pirates (PIN)", "2012", "114", "50", "64", ".439", ".386", ".491" );
SLN = new Array("NLCentral", "St. Louis", "Cardinals", "St. Louis Cardinals (SLN)", "2012", "114", "57", "57", ".500", ".474", ".526" );
NLNLWest = new Array( "HON", "LAN", "SDN", "SFN" );

HON = new Array("NLWest", "Houston", "Astros", "Houston Astros (HON)", "2012", "114", "57", "57", ".500", ".456", ".544" );
LAN = new Array("NLWest", "Los Angeles(NL)", "Dodgers", "Los Angeles(NL) Dodgers (LAN)", "2012", "114", "53", "61", ".465", ".439", ".491" );
SDN = new Array("NLWest", "San Diego", "Padres", "San Diego Padres (SDN)", "2012", "114", "35", "79", ".307", ".281", ".333" );
SFN = new Array("NLWest", "San Francisco", "Giants", "San Francisco Giants (SFN)", "2012", "114", "54", "60", ".474", ".421", ".526" );
