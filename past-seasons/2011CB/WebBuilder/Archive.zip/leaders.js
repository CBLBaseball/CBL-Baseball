leaderName0 = new Array( "O.Infante", "J.Hamilton", "C.Crawford", "R.Braun", "C.Gonzalez", "R.Cano", "M.Prado", "A.Ethier", "B.Butler", "M.Young" );
leaderTeam0 = new Array( "***", "ATN", "SEA", "CHA", "OAA", "NYA", "OAA", "LAN", "KCA", "MNA" );
leaderData0 = new Array( ".351", ".333", ".329", ".325", ".321", ".316", ".314", ".313", ".312", ".311" );

leaderName1 = new Array( "I.Suzuki", "M.Young", "M.Scutaro", "B.Phillips", "R.Cano", "N.Markakis", "R.Braun", "C.Headley", "D.Jeter", "M.Kemp" );
leaderTeam1 = new Array( "SEA", "MNA", "LAN", "CIN", "NYA", "BAA", "CHA", "ATN", "NYA", "LAN" );
leaderData1 = new Array( "676", "663", "648", "645", "643", "642", "637", "632", "627", "626" );

leaderName2 = new Array( "J.Bautista", "R.Braun", "J.Votto", "D.Wright", "R.Cano", "J.Werth", "A.Huff", "C.Gonzalez", "R.Weeks", "D.Uggla" );
leaderTeam2 = new Array( "PHN", "CHA", "CIN", "NYN", "NYA", "PHN", "CHA", "OAA", "MNA", "LAA" );
leaderData2 = new Array( "146", "112", "107", "107", "106", "106", "104", "103", "102", "101" );

leaderName3 = new Array( "R.Braun", "M.Young", "R.Cano", "C.Crawford", "C.Gonzalez", "I.Suzuki", "N.Markakis", "A.Gonzalez", "M.Byrd", "B.Butler" );
leaderTeam3 = new Array( "CHA", "MNA", "NYA", "SEA", "OAA", "SEA", "BAA", "BAA", "CHN", "KCA" );
leaderData3 = new Array( "207", "206", "203", "199", "193", "193", "189", "183", "179", "179" );

leaderName4 = new Array( "B.Butler", "M.Cabrera", "R.Braun", "B.Abreu", "J.Werth", "A.Beltre", "A.Soriano", "M.Prado", "C.Young", "A.Gonzalez" );
leaderTeam4 = new Array( "KCA", "SLN", "CHA", "NYA", "PHN", "HON", "CHN", "OAA", "BAA", "BOA" );
leaderData4 = new Array( "55", "53", "50", "48", "47", "44", "43", "43", "42", "42" );

leaderName5 = new Array( "D.Fowler", "S.Drew", "D.Span", "S.Victorino", "R.Furcal", "C.Granderson", "A.Jackson", "B.Dewitt", "C.Gonzalez", "A.Torres" );
leaderTeam5 = new Array( "WAN", "MNA", "MNA", "PHN", "CIN", "DEA", "DEA", "LAN", "OAA", "OAA" );
leaderData5 = new Array( "19", "12", "10", "10", "9", "9", "9", "9", "9", "9" );

leaderName6 = new Array( "J.Bautista", "J.Votto", "A.Dunn", "M.Kemp", "A.Pujols", "A.Gonzalez", "D.Ortiz", "C.Gonzalez", "M.Teixeira", "M.Reynolds" );
leaderTeam6 = new Array( "PHN", "CIN", "***", "LAN", "PIN", "BAA", "BOA", "OAA", "NYA", "TOA" );
leaderData6 = new Array( "60", "45", "43", "42", "42", "39", "39", "39", "38", "37" );

leaderName7 = new Array( "J.Bautista", "P.Konerko", "J.Hamilton", "C.Gonzalez", "C.Crawford", "B.Abreu", "A.Gonzalez", "M.Teixeira", "A.Rodriguez", "J.Votto" );
leaderTeam7 = new Array( "PHN", "CHA", "ATN", "OAA", "SEA", "NYA", "BAA", "NYA", "SEA", "CIN" );
leaderData7 = new Array( "136", "121", "114", "113", "112", "111", "110", "109", "109", "108" );

leaderName8 = new Array( "D.Barton", "J.Bautista", "J.Votto", "P.Fielder", "R.Zimmerman", "C.Pena", "B.Zobrist", "A.Huff", "M.Teixeira", "J.Werth" );
leaderTeam8 = new Array( "OAA", "PHN", "CIN", "WAN", "WAN", "LAN", "SLN", "CHA", "NYA", "PHN" );
leaderData8 = new Array( "126", "109", "103", "96", "94", "92", "89", "87", "87", "87" );

leaderName9 = new Array( "C.Crawford", "D.Young", "M.Cabrera", "B.Butler", "J.Mauer", "R.Cano", "C.Gonzalez", "J.Hamilton", "A.Pagan", "J.Votto" );
leaderTeam9 = new Array( "SEA", "MNA", "SLN", "KCA", "MNA", "NYA", "OAA", "ATN", "KCA", "CIN" );
leaderData9 = new Array( "20", "18", "18", "15", "14", "14", "14", "12", "12", "11" );

leaderName10 = new Array( "M.Reynolds", "A.Dunn", "R.Weeks", "A.Laroche", "B.Upton", "I.Davis", "A.Jackson", "J.Werth", "D.Uggla", "R.Howard" );
leaderTeam10 = new Array( "TOA", "***", "MNA", "CLA", "SFN", "NYN", "DEA", "PHN", "LAA", "PHN" );
leaderData10 = new Array( "194", "191", "183", "173", "171", "169", "168", "163", "161", "161" );

leaderName11 = new Array( "J.Pierre", "C.Utley", "R.Weeks", "M.Byrd", "P.Fielder", "C.Quentin", "M.Teixeira", "J.Wilson*", "K.Youkilis", "B.Phillips" );
leaderTeam11 = new Array( "KCA", "PHN", "MNA", "CHN", "WAN", "HON", "NYA", "CLA", "BOA", "CIN" );
leaderData11 = new Array( "27", "26", "25", "20", "19", "17", "17", "16", "15", "15" );

leaderName12 = new Array( "O.Hudson", "J.Pierre", "J.Reyes", "Y.Escobar", "G.Blanco", "A.Pagan", "T.Gwynn Jr", "B.Ryan", "J.Kendall", "W.Valdez" );
leaderTeam12 = new Array( "NYN", "KCA", "NYN", "ATN", "KCA", "KCA", "SDN", "***", "KCA", "SEA" );
leaderData12 = new Array( "64", "50", "50", "44", "33", "26", "26", "23", "22", "22" );

leaderName13 = new Array( "J.Pierre", "C.Crawford", "M.Bourn", "I.Suzuki", "A.Pagan", "R.Davis", "A.Jackson", "C.Figgins", "A.Torres", "B.Upton" );
leaderTeam13 = new Array( "KCA", "SEA", "HON", "SEA", "KCA", "MNA", "DEA", "LAA", "OAA", "SFN" );
leaderData13 = new Array( "98", "69", "68", "61", "52", "50", "44", "41", "41", "40" );

leaderName14 = new Array( "B.Gardner", "M.Bourn", "A.Rios", "H.Ramirez", "S.Podsednik", "C.Patterson", "J.Tabata", "N.Morgan", "A.Torres", "I.Suzuki" );
leaderTeam14 = new Array( "NYA", "HON", "TOA", "LAA", "SFN", "HON", "PIN", "OAA", "OAA", "SEA" );
leaderData14 = new Array( ".90", ".89", ".89", ".86", ".85", ".84", ".83", ".82", ".82", ".81" );

leaderName15 = new Array( "D.Jeter", "C.McGehee", "V.Guerrero", "R.Howard", "T.Hunter", "R.Cano", "A.Pujols", "N.Markakis", "C.Headley", "A.Huff" );
leaderTeam15 = new Array( "NYA", "NYA", "BAA", "PHN", "LAA", "NYA", "PIN", "BAA", "ATN", "CHA" );
leaderData15 = new Array( "32", "32", "30", "29", "27", "26", "26", "24", "23", "23" );

leaderName16 = new Array( "A.Cabrera", "S.Drew", "A.Jones", "M.Aviles", "G.Blum", "R.Theriot", "J.Morneau", "I.Suzuki", "J.Loney", "T.Hunter" );
leaderTeam16 = new Array( "CLA", "MNA", "SEA", "TOA", "TOA", "CHN", "MNA", "SEA", "TOA", "LAA" );
leaderData16 = new Array( "10", "8", "8", "7", "7", "6", "6", "6", "6", "5" );

leaderName17 = new Array( "M.Fontenot", "V.Martinez", "S.Rodriguez", "J.Francoeur", "J.Smoak", "M.Bradley", "G.Soto", "", "", "" );
leaderTeam17 = new Array( "CHA", "PHN", "CHA", "PHN", "SEA", "SEA", "CHN", "", "", "" );
leaderData17 = new Array( ".364", ".292", ".238", ".238", ".238", ".200", ".083", "0", "0", "0" );

leaderName18 = new Array( "J.Bautista", "C.Gonzalez", "J.Hamilton", "J.Votto", "D.Ortiz", "J.Drew", "A.Ethier", "A.Pujols", "M.Cabrera", "R.Braun" );
leaderTeam18 = new Array( "PHN", "OAA", "ATN", "CIN", "BOA", "SLN", "LAN", "PIN", "SLN", "CHA" );
leaderData18 = new Array( ".682", ".610", ".607", ".605", ".596", ".580", ".575", ".564", ".553", ".551" );

leaderName19 = new Array( "J.Bautista", "J.Votto", "R.Zimmerman", "C.Crawford", "O.Infante", "A.Huff", "J.Hamilton", "D.Barton", "R.Braun", "B.Butler" );
leaderTeam19 = new Array( "PHN", "CIN", "WAN", "SEA", "***", "CHA", "ATN", "OAA", "CHA", "KCA" );
leaderData19 = new Array( ".412", ".408", ".406", ".394", ".388", ".387", ".387", ".385", ".384", ".382" );

leaderName20 = new Array( "J.Bautista", "J.Votto", "J.Hamilton", "D.Ortiz", "R.Zimmerman", "J.Drew", "C.Crawford", "C.Gonzalez", "A.Ethier", "R.Braun" );
leaderTeam20 = new Array( "PHN", "CIN", "ATN", "BOA", "WAN", "SLN", "SEA", "OAA", "LAN", "CHA" );
leaderData20 = new Array( "10.6", " 9.4", " 8.6", " 8.4", " 8.3", " 8.2", " 8.2", " 8.2", " 7.7", " 7.7" );

leaderName21 = new Array( "J.Bautista", "J.Votto", "C.Crawford", "C.Gonzalez", "D.Ortiz", "J.Hamilton", "R.Zimmerman", "J.Drew", "A.Pujols", "R.Braun" );
leaderTeam21 = new Array( "PHN", "CIN", "SEA", "OAA", "BOA", "ATN", "WAN", "SLN", "PIN", "CHA" );
leaderData21 = new Array( "1.218", "1.112", "1.075", "1.048", "1.022", "1.019", "1.003", ".994", ".964", ".941" );

leaderName22 = new Array( "J.Bautista", "C.Gonzalez", "R.Braun", "J.Votto", "R.Cano", "A.Pujols", "J.Hamilton", "A.Gonzalez", "C.Crawford", "A.Beltre" );
leaderTeam22 = new Array( "PHN", "OAA", "CHA", "CIN", "NYA", "PIN", "ATN", "BAA", "SEA", "HON" );
leaderData22 = new Array( "398", "367", "351", "344", "331", "327", "324", "322", "322", "319" );

leaderName23 = new Array( "A.Gonzalez", "S.Castro", "M.Ordonez", "N.Markakis", "V.Guerrero", "I.Kinsler", "V.Martinez", "M.Olivo", "S.Victorino", "M.Young" );
leaderTeam23 = new Array( "BAA", "CHN", "DEA", "BAA", "BAA", "TOA", "PHN", "HON", "PHN", "MNA" );
leaderData23 = new Array( ".422", ".419", ".385", ".378", ".376", ".364", ".362", ".360", ".357", ".355" );

leaderName24 = new Array( "A.Pujols", "D.Young", "D.Stubbs", "M.Ordonez", "E.Encarnacion", "M.Teixeira", "V.Martinez", "M.Morse", "J.Bruce", "M.Reynolds" );
leaderTeam24 = new Array( "PIN", "MNA", "CIN", "DEA", "LAN", "NYA", "PHN", "BOA", "CIN", "TOA" );
leaderData24 = new Array( "17", "16", "14", "14", "14", "13", "13", "12", "12", "12" );

leaderName25 = new Array( "D.Dejesus", "J.Hamilton", "C.Crawford", "O.Infante", "J.Tabata", "Y.Torrealba", "R.Cano", "J.Mauer", "J.Votto", "J.Carroll" );
leaderTeam25 = new Array( "KCA", "ATN", "SEA", "***", "PIN", "SEA", "NYA", "MNA", "CIN", "SDN" );
leaderData25 = new Array( ".354", ".352", ".351", ".350", ".348", ".345", ".340", ".335", ".335", ".334" );

leaderName26 = new Array( "J.Bautista", "A.Dunn", "D.Ortiz", "A.Gonzalez", "J.Votto", "P.Fielder", "A.Ethier", "M.Kemp", "M.Thames", "J.Drew" );
leaderTeam26 = new Array( "PHN", "***", "BOA", "BAA", "CIN", "WAN", "LAN", "LAN", "NYA", "SLN" );
leaderData26 = new Array( "49", "40", "38", "34", "34", "33", "31", "31", "30", "30" );

leaderName27 = new Array( "F.Hernandez", "D.Haren", "A.Wainwright", "T.Hudson", "C.Hamels", "B.Arroyo", "D.Price", "C.Kershaw", "D.Lowe", "J.Danks" );
leaderTeam27 = new Array( "SEA", "OAA", "SLN", "ATN", "PHN", "SLN", "HON", "LAN", "NYN", "CHA" );
leaderData27 = new Array( "20", "19", "19", "18", "18", "17", "16", "16", "16", "15" );

leaderName28 = new Array( "R.Dempster", "F.Carmona", "J.Santana", "A.Burnett", "R.Wells", "C.Sabathia", "R.Porcello", "C.Lewis", "R.Romero", "C.Richard" );
leaderTeam28 = new Array( "CHN", "***", "***", "CHN", "CHN", "CLA", "DEA", "CHA", "CLA", "DEA" );
leaderData28 = new Array( "20", "18", "18", "17", "17", "17", "16", "15", "15", "15" );

leaderName29 = new Array( "A.Wainwright", "J.Arrieta", "D.Haren", "D.Lowe", "C.Hamels", "F.Liriano", "B.Arroyo", "U.Jimenez", "B.Duensing", "J.Shields" );
leaderTeam29 = new Array( "SLN", "BAA", "OAA", "NYN", "PHN", "MNA", "SLN", "BAA", "MNA", "MNA" );
leaderData29 = new Array( ".792", ".750", ".704", ".696", ".692", ".682", ".680", ".667", ".667", ".667" );

leaderName30 = new Array( "A.Wainwright", "F.Hernandez", "J.Verlander", "C.Billingsley", "T.Cahill", "R.Oswalt", "C.Carpenter", "B.Arroyo", "C.Kershaw", "M.Cain" );
leaderTeam30 = new Array( "SLN", "SEA", "DEA", "LAN", "OAA", "HON", "LAN", "SLN", "LAN", "SFN" );
leaderData30 = new Array( " 2.30", " 2.39", " 2.63", " 2.73", " 2.83", " 2.90", " 2.90", " 2.94", " 2.99", " 3.05" );

leaderName31 = new Array( "R.Halladay", "C.Sabathia", "F.Hernandez", "C.Carpenter", "D.Haren", "J.Weaver", "T.Hudson", "J.Verlander", "B.Myers", "A.Wainwright" );
leaderTeam31 = new Array( "TOA", "CLA", "SEA", "LAN", "OAA", "LAA", "ATN", "DEA", "KCA", "SLN" );
leaderData31 = new Array( "250.1", "249.1", "249.0", "242.0", "233.2", "233.1", "232.1", "229.2", "227.2", "227.1" );

leaderName32 = new Array( "C.Sabathia", "R.Halladay", "C.Carpenter", "F.Hernandez", "R.Dempster", "T.Hudson", "D.Haren", "J.Lackey", "F.Carmona", "J.Weaver" );
leaderTeam32 = new Array( "CLA", "TOA", "LAN", "SEA", "CHN", "ATN", "OAA", "LAA", "***", "LAA" );
leaderData32 = new Array( "1058", "1037", "1013", "1010", "1009", "971", "961", "957", "954", "953" );

leaderName33 = new Array( "L.Ondrusek", "D.Oliver", "T.Clippard", "N.Masset", "N.Feliz", "E.Meek", "J.Broxton", "R.Betancourt", "B.Thomas", "C.Marmol" );
leaderTeam33 = new Array( "CIN", "***", "WAN", "CIN", "BAA", "BAA", "CIN", "SFN", "DEA", "CHN" );
leaderData33 = new Array( "70", "66", "66", "62", "61", "61", "61", "61", "59", "58" );

leaderName34 = new Array( "C.Carpenter", "R.Dempster", "D.Haren", "F.Hernandez", "T.Hanson", "T.Hudson", "U.Jimenez", "M.Buehrle", "F.Carmona", "C.Sabathia" );
leaderTeam34 = new Array( "LAN", "CHN", "OAA", "SEA", "ATN", "ATN", "BAA", "CHA", "***", "CLA" );
leaderData34 = new Array( "35", "34", "34", "34", "33", "33", "33", "33", "33", "33" );

leaderName35 = new Array( "C.Sabathia", "C.Lee", "R.Halladay", "F.Hernandez", "F.Liriano", "J.Johnson", "J.Santana", "B.Myers", "T.Cahill", "J.Danks" );
leaderTeam35 = new Array( "CLA", "PHN", "TOA", "SEA", "MNA", "CHA", "***", "KCA", "OAA", "CHA" );
leaderData35 = new Array( "17", "12", "12", "11", "10", "9", "9", "9", "9", "8" );

leaderName36 = new Array( "N.Feliz", "F.Rodriguez", "J.Soria", "J.Papelbon", "N.Masset", "J.Benoit", "H.Bell", "M.Capps", "F.Cordero", "J.Broxton" );
leaderTeam36 = new Array( "BAA", "NYN", "KCA", "BOA", "CIN", "HON", "MNA", "PIN", "SFN", "CIN" );
leaderData36 = new Array( "50", "47", "46", "45", "44", "43", "43", "43", "41", "39" );

leaderName37 = new Array( "J.Papelbon", "N.Feliz", "J.Benoit", "F.Cordero", "H.Bell", "F.Rodriguez", "J.Valverde", "J.Soria", "B.Wilson", "C.Perez" );
leaderTeam37 = new Array( "BOA", "BAA", "HON", "SFN", "MNA", "NYN", "SDN", "KCA", "TOA", "CLA" );
leaderData37 = new Array( "37", "35", "35", "34", "32", "32", "31", "29", "27", "26" );

leaderName38 = new Array( "J.Benoit", "J.Broxton", "A.Bailey", "C.Perez", "H.Street", "M.Capps", "D.Storen", "R.Franklin", "J.Valverde", "N.Feliz" );
leaderTeam38 = new Array( "HON", "CIN", "OAA", "CLA", "OAA", "PIN", "WAN", "SLN", "SDN", "BAA" );
leaderData38 = new Array( ".972", ".960", ".960", ".929", ".900", ".897", ".895", ".889", ".886", ".854" );

leaderName39 = new Array( "C.Sabathia", "T.Cahill", "A.Wainwright", "U.Jimenez", "G.Gonzalez", "F.Hernandez", "R.Halladay", "T.Hudson", "M.Garza", "D.Matsuzaka" );
leaderTeam39 = new Array( "CLA", "OAA", "SLN", "BAA", "OAA", "SEA", "TOA", "ATN", "BAA", "BOA" );
leaderData39 = new Array( "4", "4", "4", "3", "3", "3", "3", "2", "2", "2" );

leaderName40 = new Array( "R.Halladay", "M.Buehrle", "C.Pavano", "R.Dempster", "C.Sabathia", "J.Lackey", "F.Carmona", "J.Shields", "J.Lester", "M.Pelfrey" );
leaderTeam40 = new Array( "TOA", "CHA", "MNA", "CHN", "CLA", "LAA", "***", "MNA", "BOA", "***" );
leaderData40 = new Array( "268", "250", "246", "240", "239", "239", "237", "235", "232", "226" );

leaderName41 = new Array( "C.Lewis", "E.Santana", "J.Lester", "C.Richard", "R.Dempster", "J.Lackey", "R.Romero", "C.Sabathia", "M.Garza", "J.Niese" );
leaderTeam41 = new Array( "CHA", "HON", "BOA", "DEA", "CHN", "LAA", "CLA", "CLA", "BAA", "PIN" );
leaderData41 = new Array( "136", "132", "126", "126", "124", "124", "121", "117", "116", "116" );

leaderName42 = new Array( "C.Lewis", "C.Richard", "R.Dempster", "J.Lackey", "R.Romero", "Z.Duke", "C.Sabathia", "E.Santana", "J.Lester", "A.Burnett" );
leaderTeam42 = new Array( "CHA", "DEA", "CHN", "LAA", "CLA", "PIN", "CLA", "HON", "BOA", "CHN" );
leaderData42 = new Array( "124", "123", "117", "115", "113", "112", "111", "109", "108", "108" );

leaderName43 = new Array( "M.Garza", "R.Dempster", "E.Santana", "S.Marcum", "B.Enright", "C.Lewis", "J.Bonderman", "T.Hudson", "K.Millwood", "C.Richard" );
leaderTeam43 = new Array( "BAA", "CHN", "HON", "TOA", "DEA", "CHA", "CIN", "ATN", "CIN", "DEA" );
leaderData43 = new Array( "40", "40", "35", "33", "32", "30", "30", "29", "29", "29" );

leaderName44 = new Array( "R.Dempster", "C.Wilson", "G.Gonzalez", "C.Zambrano", "J.Sanchez", "D.Price", "R.Romero", "J.Lackey", "E.Jackson", "A.Sanchez" );
leaderTeam44 = new Array( "CHN", "CLA", "OAA", "***", "SFN", "HON", "CLA", "LAA", "SDN", "LAA" );
leaderData44 = new Array( "107", "107", "105", "95", "95", "94", "92", "90", "90", "89" );

leaderName45 = new Array( "F.Hernandez", "J.Verlander", "C.Kershaw", "F.Liriano", "R.Oswalt", "J.Weaver", "R.Dempster", "A.Wainwright", "D.Haren", "U.Jimenez" );
leaderTeam45 = new Array( "SEA", "DEA", "LAN", "MNA", "HON", "LAA", "CHN", "SLN", "OAA", "BAA" );
leaderData45 = new Array( "240", "226", "225", "224", "223", "221", "213", "213", "206", "204" );

leaderName46 = new Array( "R.Romero", "F.Hernandez", "U.Jimenez", "C.Lewis", "A.Burnett", "F.Liriano", "C.Sabathia", "R.Porcello", "A.Harang", "H.Kuroda" );
leaderTeam46 = new Array( "CLA", "SEA", "BAA", "CHA", "CHN", "MNA", "CLA", "DEA", "CHN", "LAN" );
leaderData46 = new Array( "20", "19", "15", "15", "15", "15", "14", "14", "13", "13" );

leaderName47 = new Array( "D.Price", "T.Cahill", "U.Jimenez", "J.Cueto", "R.Oswalt", "B.Fuentes", "B.Moehler", "G.Gonzalez", "B.Hawksworth", "J.Vargas" );
leaderTeam47 = new Array( "HON", "OAA", "BAA", "CIN", "HON", "LAA", "***", "OAA", "OAA", "OAA" );
leaderData47 = new Array( "6", "5", "4", "4", "4", "4", "4", "4", "4", "4" );

leaderName48 = new Array( "M.Buehrle", "J.Danks", "K.Millwood", "C.Richard", "D.Price", "K.Davies", "T.Cahill", "T.Lincecum", "B.Arroyo", "L.Hernandez" );
leaderTeam48 = new Array( "CHA", "CHA", "CIN", "DEA", "HON", "KCA", "OAA", "SFN", "SLN", "SLN" );
leaderData48 = new Array( "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00" );

leaderName49 = new Array( "F.Carmona", "T.Lilly", "J.Lackey", "J.Hammel", "T.Hanson", "E.Santana", "J.Verlander", "C.Pavano", "T.Lincecum", "J.Niemann" );
leaderTeam49 = new Array( "***", "***", "LAA", "NYA", "ATN", "HON", "DEA", "MNA", "SFN", "TOA" );
leaderData49 = new Array( "56", "40", "40", "40", "38", "36", "34", "34", "34", "34" );

leaderName50 = new Array( "A.Sanchez", "J.Wright", "J.Weaver", "R.Porcello", "E.Jackson", "T.Lincecum", "T.Gorzelanny", "D.Haren", "R.Halladay", "J.De La Rosa" );
leaderTeam50 = new Array( "LAA", "***", "LAA", "DEA", "SDN", "SFN", "***", "OAA", "TOA", "***" );
leaderData50 = new Array( ".42", ".59", ".63", ".67", ".68", ".69", ".70", ".70", ".70", ".71" );

leaderName51 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderTeam51 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderData51 = new Array( "", "", "", "", "", "", "", "", "", "" );

leaderName52 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderTeam52 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderData52 = new Array( "", "", "", "", "", "", "", "", "", "" );

leaderName53 = new Array( "R.Oswalt", "C.Kershaw", "A.Wainwright", "T.Cahill", "J.Sanchez", "B.Arroyo", "M.Cain", "F.Hernandez", "J.Verlander", "I.Kennedy" );
leaderTeam53 = new Array( "HON", "LAN", "SLN", "OAA", "SFN", "SLN", "SFN", "SEA", "DEA", "PHN" );
leaderData53 = new Array( " 6.2", " 6.4", " 6.5", " 6.6", " 6.7", " 6.7", " 6.8", " 7.1", " 7.1", " 7.4" );

leaderName54 = new Array( "R.Halladay", "D.Haren", "R.Dickey", "D.Braden", "S.Marcum", "C.Lee", "M.Buehrle", "C.Pavano", "S.Baker", "J.Hammel" );
leaderTeam54 = new Array( "TOA", "OAA", "NYN", "OAA", "TOA", "PHN", "CHA", "MNA", "MNA", "NYA" );
leaderData54 = new Array( " 1.6", " 1.7", " 1.9", " 2.0", " 2.1", " 2.2", " 2.2", " 2.2", " 2.3", " 2.3" );

leaderName55 = new Array( "F.Liriano", "C.Kershaw", "J.Sanchez", "T.Lincecum", "R.Oswalt", "J.Lester", "J.Verlander", "Y.Gallardo", "F.Hernandez", "J.Johnson" );
leaderTeam55 = new Array( "MNA", "LAN", "SFN", "SFN", "HON", "BOA", "DEA", "HON", "SEA", "CHA" );
leaderData55 = new Array( "10.1", " 9.9", " 9.9", " 9.4", " 9.2", " 9.2", " 8.9", " 8.9", " 8.7", " 8.6" );

leaderName56 = new Array( "C.Billingsley", "F.Liriano", "D.Braden", "C.Wilson", "D.Fister", "J.Garcia", "F.Hernandez", "J.Verlander", "C.Buchholz", "C.Pavano" );
leaderTeam56 = new Array( "LAN", "MNA", "OAA", "CLA", "SEA", "SLN", "SEA", "DEA", "BOA", "MNA" );
leaderData56 = new Array( " 0.42", " 0.49", " 0.53", " 0.53", " 0.54", " 0.54", " 0.54", " 0.55", " 0.56", " 0.61" );

