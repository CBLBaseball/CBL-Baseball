leaderName0 = new Array( "O.Infante", "J.Hamilton", "A.Ethier", "P.Polanco", "J.Reyes", "J.Votto", "R.Zimmerman", "M.Cabrera", "S.Rolen", "S.Castro" );
leaderTeam0 = new Array( "***", "ATN", "LAN", "PHN", "NYN", "CIN", "WAN", "SLN", "CIN", "CHN" );
leaderData0 = new Array( ".351", ".333", ".313", ".307", ".306", ".304", ".304", ".302", ".302", ".298" );

leaderName1 = new Array( "M.Scutaro", "B.Phillips", "C.Headley", "M.Kemp", "E.Andrus", "H.Pence", "D.Wright", "M.Byrd", "A.Beltre", "H.Kendrick" );
leaderTeam1 = new Array( "LAN", "CIN", "ATN", "LAN", "WAN", "HON", "NYN", "CHN", "HON", "SFN" );
leaderData1 = new Array( "648", "645", "632", "626", "617", "611", "605", "604", "601", "598" );

leaderName2 = new Array( "J.Bautista", "J.Votto", "D.Wright", "J.Werth", "A.Beltre", "M.Kemp", "R.Zimmerman", "A.Pujols", "R.Howard", "S.Victorino" );
leaderTeam2 = new Array( "PHN", "CIN", "NYN", "PHN", "HON", "LAN", "WAN", "PIN", "PHN", "PHN" );
leaderData2 = new Array( "146", "107", "107", "106", "98", "97", "95", "92", "90", "90" );

leaderName3 = new Array( "M.Byrd", "J.Hamilton", "J.Reyes", "O.Infante", "J.Votto", "J.Bautista", "A.Beltre", "M.Cabrera", "R.Zimmerman", "A.Pujols" );
leaderTeam3 = new Array( "CHN", "ATN", "NYN", "***", "CIN", "PHN", "HON", "SLN", "WAN", "PIN" );
leaderData3 = new Array( "179", "178", "176", "175", "173", "172", "171", "171", "167", "166" );

leaderName4 = new Array( "M.Cabrera", "J.Werth", "A.Beltre", "A.Soriano", "J.Bautista", "G.Sanchez", "T.Tulowitzki", "R.Zimmerman", "A.McCutchen", "H.Kendrick" );
leaderTeam4 = new Array( "SLN", "PHN", "HON", "CHN", "PHN", "HON", "HON", "WAN", "PIN", "SFN" );
leaderData4 = new Array( "53", "47", "44", "43", "42", "41", "41", "41", "40", "40" );

leaderName5 = new Array( "D.Fowler", "S.Victorino", "R.Furcal", "B.Dewitt", "J.Bay", "M.Bourn", "J.Reyes", "J.Bruce", "M.Kemp", "L.Morrison" );
leaderTeam5 = new Array( "WAN", "PHN", "CIN", "LAN", "PIN", "HON", "NYN", "CIN", "LAN", "SLN" );
leaderData5 = new Array( "19", "10", "9", "9", "9", "8", "8", "7", "7", "7" );

leaderName6 = new Array( "J.Bautista", "J.Votto", "A.Dunn", "M.Kemp", "A.Pujols", "J.Kubel", "J.Hamilton", "P.Fielder", "A.Ethier", "J.Drew" );
leaderTeam6 = new Array( "PHN", "CIN", "***", "LAN", "PIN", "SLN", "ATN", "WAN", "LAN", "SLN" );
leaderData6 = new Array( "60", "45", "43", "42", "42", "35", "34", "34", "33", "33" );

leaderName7 = new Array( "J.Bautista", "J.Hamilton", "J.Votto", "J.Kubel", "A.Pujols", "A.Dunn", "P.Fielder", "A.Beltre", "M.Kemp", "D.Wright" );
leaderTeam7 = new Array( "PHN", "ATN", "CIN", "SLN", "PIN", "***", "WAN", "HON", "LAN", "NYN" );
leaderData7 = new Array( "136", "114", "108", "108", "107", "104", "104", "102", "100", "98" );

leaderName8 = new Array( "J.Bautista", "J.Votto", "P.Fielder", "R.Zimmerman", "C.Pena", "B.Zobrist", "J.Werth", "D.Wright", "I.Davis", "J.Willingham" );
leaderTeam8 = new Array( "PHN", "CIN", "WAN", "WAN", "LAN", "SLN", "PHN", "NYN", "NYN", "NYN" );
leaderData8 = new Array( "109", "103", "96", "94", "92", "89", "87", "84", "83", "83" );

leaderName9 = new Array( "M.Cabrera", "J.Hamilton", "J.Votto", "H.Pence", "J.Bautista", "H.Kendrick", "R.Ludwick", "J.Thome", "N.Cruz", "R.Zimmerman" );
leaderTeam9 = new Array( "SLN", "ATN", "CIN", "HON", "PHN", "SFN", "***", "***", "SDN", "WAN" );
leaderData9 = new Array( "18", "12", "11", "10", "10", "10", "9", "8", "8", "8" );

leaderName10 = new Array( "A.Dunn", "B.Upton", "I.Davis", "J.Werth", "R.Howard", "M.Kemp", "C.Pena", "K.Johnson", "D.Stubbs", "C.Rasmus" );
leaderTeam10 = new Array( "***", "SFN", "NYN", "PHN", "PHN", "LAN", "LAN", "SDN", "CIN", "***" );
leaderData10 = new Array( "191", "171", "169", "163", "161", "158", "158", "158", "156", "155" );

leaderName11 = new Array( "C.Utley", "M.Byrd", "P.Fielder", "C.Quentin", "B.Phillips", "T.Hafner", "A.Kearns", "J.Werth", "R.Barajas", "J.Willingham" );
leaderTeam11 = new Array( "PHN", "CHN", "WAN", "HON", "CIN", "PIN", "SDN", "PHN", "NYN", "NYN" );
leaderData11 = new Array( "26", "20", "19", "17", "15", "15", "15", "14", "12", "12" );

leaderName12 = new Array( "O.Hudson", "J.Reyes", "Y.Escobar", "T.Gwynn Jr", "C.Gomez", "D.Eckstein", "C.Izturis", "E.Aybar", "E.Andrus", "O.Infante" );
leaderTeam12 = new Array( "NYN", "NYN", "ATN", "SDN", "NYN", "***", "PIN", "SLN", "WAN", "***" );
leaderData12 = new Array( "64", "50", "44", "26", "21", "18", "17", "17", "17", "15" );

leaderName13 = new Array( "M.Bourn", "B.Upton", "E.Andrus", "J.Reyes", "S.Victorino", "R.Theriot", "R.Furcal", "E.Aybar", "B.Phillips", "A.McCutchen" );
leaderTeam13 = new Array( "HON", "SFN", "WAN", "NYN", "PHN", "CHN", "CIN", "SLN", "CIN", "PIN" );
leaderData13 = new Array( "68", "40", "39", "38", "35", "26", "26", "24", "23", "23" );

leaderName14 = new Array( "M.Bourn", "S.Podsednik", "C.Patterson", "J.Tabata", "E.Andrus", "J.Reyes", "N.Cruz", "R.Furcal", "B.Upton", "S.Victorino" );
leaderTeam14 = new Array( "HON", "SFN", "HON", "PIN", "WAN", "NYN", "SDN", "CIN", "SFN", "PHN" );
leaderData14 = new Array( ".89", ".85", ".84", ".83", ".81", ".81", ".81", ".79", ".77", ".76" );

leaderName15 = new Array( "R.Howard", "A.Pujols", "C.Headley", "P.Polanco", "D.Lee", "A.Beltre", "J.Werth", "H.Kendrick", "B.Posey", "J.Kubel" );
leaderTeam15 = new Array( "PHN", "PIN", "ATN", "PHN", "CHN", "HON", "PHN", "SFN", "SFN", "SLN" );
leaderData15 = new Array( "29", "26", "23", "22", "21", "21", "21", "21", "21", "21" );

leaderName16 = new Array( "R.Theriot", "S.Castro", "C.Dickerson", "J.Bruce", "B.Phillips", "J.Votto", "J.Bautista", "R.Howard", "C.Utley", "J.Werth" );
leaderTeam16 = new Array( "CHN", "CHN", "CHN", "CIN", "CIN", "CIN", "PHN", "PHN", "PHN", "PHN" );
leaderData16 = new Array( "6", "4", "3", "3", "3", "3", "3", "3", "3", "3" );

leaderName17 = new Array( "V.Martinez", "J.Francoeur", "G.Soto", "", "", "", "", "", "", "" );
leaderTeam17 = new Array( "PHN", "PHN", "CHN", "", "", "", "", "", "", "" );
leaderData17 = new Array( ".292", ".238", ".083", "0", "0", "0", "0", "0", "0", "0" );

leaderName18 = new Array( "J.Bautista", "J.Hamilton", "J.Votto", "J.Drew", "A.Ethier", "A.Pujols", "M.Cabrera", "S.Rolen", "T.Tulowitzki", "A.Beltre" );
leaderTeam18 = new Array( "PHN", "ATN", "CIN", "SLN", "LAN", "PIN", "SLN", "CIN", "HON", "HON" );
leaderData18 = new Array( ".682", ".607", ".605", ".580", ".575", ".564", ".553", ".542", ".540", ".531" );

leaderName19 = new Array( "J.Bautista", "J.Votto", "R.Zimmerman", "O.Infante", "J.Hamilton", "J.Drew", "M.Cabrera", "A.Pujols", "J.Werth", "S.Rolen" );
leaderTeam19 = new Array( "PHN", "CIN", "WAN", "***", "ATN", "SLN", "SLN", "PIN", "PHN", "CIN" );
leaderData19 = new Array( ".412", ".408", ".406", ".388", ".387", ".381", ".380", ".380", ".375", ".375" );

leaderName20 = new Array( "J.Bautista", "J.Votto", "J.Hamilton", "R.Zimmerman", "J.Drew", "A.Ethier", "M.Cabrera", "S.Rolen", "A.Pujols", "B.McCann" );
leaderTeam20 = new Array( "PHN", "CIN", "ATN", "WAN", "SLN", "LAN", "SLN", "CIN", "PIN", "ATN" );
leaderData20 = new Array( "10.6", " 9.4", " 8.6", " 8.3", " 8.2", " 7.7", " 7.5", " 7.2", " 7.2", " 6.6" );

leaderName21 = new Array( "J.Bautista", "J.Votto", "J.Hamilton", "R.Zimmerman", "J.Drew", "A.Pujols", "M.Cabrera", "A.Ethier", "S.Rolen", "J.Werth" );
leaderTeam21 = new Array( "PHN", "CIN", "ATN", "WAN", "SLN", "PIN", "SLN", "LAN", "CIN", "PHN" );
leaderData21 = new Array( "1.218", "1.112", "1.019", "1.003", ".994", ".964", ".935", ".931", ".905", ".883" );

leaderName22 = new Array( "J.Bautista", "J.Votto", "A.Pujols", "J.Hamilton", "A.Beltre", "M.Cabrera", "M.Kemp", "A.Ethier", "A.Dunn", "R.Zimmerman" );
leaderTeam22 = new Array( "PHN", "CIN", "PIN", "ATN", "HON", "SLN", "LAN", "LAN", "***", "WAN" );
leaderData22 = new Array( "398", "344", "327", "324", "319", "313", "311", "303", "295", "291" );

leaderName23 = new Array( "S.Castro", "V.Martinez", "M.Olivo", "S.Victorino", "M.Byrd", "A.McCutchen", "C.Hart", "I.Desmond", "J.Baker", "D.Fowler" );
leaderTeam23 = new Array( "CHN", "PHN", "HON", "PHN", "CHN", "PIN", "PIN", "SFN", "CHN", "WAN" );
leaderData23 = new Array( ".419", ".362", ".360", ".357", ".352", ".336", ".333", ".331", ".328", ".320" );

leaderName24 = new Array( "A.Pujols", "D.Stubbs", "E.Encarnacion", "V.Martinez", "J.Bruce", "K.Fukudome", "J.Votto", "M.Kemp", "J.Bautista", "S.Victorino" );
leaderTeam24 = new Array( "PIN", "CIN", "LAN", "PHN", "CIN", "***", "CIN", "LAN", "PHN", "PHN" );
leaderData24 = new Array( "17", "14", "14", "13", "12", "11", "11", "11", "11", "11" );

leaderName25 = new Array( "J.Hamilton", "O.Infante", "J.Tabata", "J.Votto", "J.Carroll", "R.Furcal", "J.Reyes", "J.Drew", "A.Ethier", "J.Bautista" );
leaderTeam25 = new Array( "ATN", "***", "PIN", "CIN", "SDN", "CIN", "NYN", "SLN", "LAN", "PHN" );
leaderData25 = new Array( ".352", ".350", ".348", ".335", ".334", ".334", ".331", ".330", ".328", ".314" );

leaderName26 = new Array( "J.Bautista", "A.Dunn", "J.Votto", "P.Fielder", "A.Ethier", "M.Kemp", "J.Drew", "J.Kubel", "J.Hamilton", "A.Beltre" );
leaderTeam26 = new Array( "PHN", "***", "CIN", "WAN", "LAN", "LAN", "SLN", "SLN", "ATN", "HON" );
leaderData26 = new Array( "49", "40", "34", "33", "31", "31", "30", "29", "26", "26" );

leaderName27 = new Array( "A.Wainwright", "T.Hudson", "C.Hamels", "B.Arroyo", "D.Price", "C.Kershaw", "D.Lowe", "Y.Gallardo", "C.Lee", "T.Hanson" );
leaderTeam27 = new Array( "SLN", "ATN", "PHN", "SLN", "HON", "LAN", "NYN", "HON", "PHN", "ATN" );
leaderData27 = new Array( "19", "18", "18", "17", "16", "16", "16", "15", "15", "14" );

leaderName28 = new Array( "R.Dempster", "A.Burnett", "R.Wells", "E.Santana", "J.Niese", "T.Lincecum", "T.Gorzelanny", "J.Cueto", "C.Carpenter", "H.Kuroda" );
leaderTeam28 = new Array( "CHN", "CHN", "CHN", "HON", "PIN", "SFN", "***", "CIN", "LAN", "LAN" );
leaderData28 = new Array( "20", "17", "17", "14", "14", "14", "13", "13", "13", "13" );

leaderName29 = new Array( "A.Wainwright", "D.Lowe", "C.Hamels", "B.Arroyo", "J.Garcia", "Y.Gallardo", "C.Lee", "T.Hudson", "R.Lopez", "J.Chacin" );
leaderTeam29 = new Array( "SLN", "NYN", "PHN", "SLN", "SLN", "HON", "PHN", "ATN", "CIN", "HON" );
leaderData29 = new Array( ".792", ".696", ".692", ".680", ".667", ".652", ".652", ".643", ".625", ".625" );

leaderName30 = new Array( "A.Wainwright", "C.Billingsley", "R.Oswalt", "C.Carpenter", "B.Arroyo", "C.Kershaw", "M.Cain", "T.Hudson", "J.Sanchez", "C.Hamels" );
leaderTeam30 = new Array( "SLN", "LAN", "HON", "LAN", "SLN", "LAN", "SFN", "ATN", "SFN", "PHN" );
leaderData30 = new Array( " 2.30", " 2.73", " 2.90", " 2.90", " 2.94", " 2.99", " 3.05", " 3.06", " 3.22", " 3.27" );

leaderName31 = new Array( "C.Carpenter", "T.Hudson", "A.Wainwright", "R.Dempster", "B.Arroyo", "L.Hernandez", "C.Hamels", "R.Oswalt", "E.Jackson", "C.Lee" );
leaderTeam31 = new Array( "LAN", "ATN", "SLN", "CHN", "SLN", "SLN", "PHN", "HON", "SDN", "PHN" );
leaderData31 = new Array( "242.0", "232.1", "227.1", "225.0", "220.1", "219.0", "217.2", "217.1", "214.0", "212.1" );

leaderName32 = new Array( "C.Carpenter", "R.Dempster", "T.Hudson", "E.Jackson", "L.Hernandez", "C.Hamels", "D.Price", "T.Hanson", "B.Arroyo", "A.Wainwright" );
leaderTeam32 = new Array( "LAN", "CHN", "ATN", "SDN", "SLN", "PHN", "HON", "ATN", "SLN", "SLN" );
leaderData32 = new Array( "1013", "1009", "971", "930", "926", "907", "900", "897", "893", "891" );

leaderName33 = new Array( "L.Ondrusek", "T.Clippard", "N.Masset", "J.Broxton", "R.Betancourt", "C.Marmol", "J.Hanrahan", "C.Breslow", "W.Lopez", "J.Benoit" );
leaderTeam33 = new Array( "CIN", "WAN", "CIN", "CIN", "SFN", "CHN", "PIN", "PHN", "LAN", "HON" );
leaderData33 = new Array( "70", "66", "62", "61", "61", "58", "58", "57", "55", "53" );

leaderName34 = new Array( "C.Carpenter", "R.Dempster", "T.Hanson", "T.Hudson", "D.Lowe", "J.Westbrook", "L.Hernandez", "A.Wainwright", "R.Wells", "R.Oswalt" );
leaderTeam34 = new Array( "LAN", "CHN", "ATN", "ATN", "NYN", "NYN", "SLN", "SLN", "CHN", "HON" );
leaderData34 = new Array( "35", "34", "33", "33", "33", "33", "33", "33", "32", "32" );

leaderName35 = new Array( "C.Lee", "T.Lincecum", "A.Wainwright", "R.Dempster", "J.Cueto", "C.Carpenter", "G.Floyd", "E.Jackson", "M.Cain", "B.Arroyo" );
leaderTeam35 = new Array( "PHN", "SFN", "SLN", "CHN", "CIN", "LAN", "***", "SDN", "SFN", "SLN" );
leaderData35 = new Array( "12", "7", "7", "6", "6", "6", "6", "6", "6", "6" );

leaderName36 = new Array( "F.Rodriguez", "N.Masset", "J.Benoit", "M.Capps", "F.Cordero", "J.Broxton", "C.Breslow", "J.Valverde", "C.Marmol", "T.Clippard" );
leaderTeam36 = new Array( "NYN", "CIN", "HON", "PIN", "SFN", "CIN", "PHN", "SDN", "CHN", "WAN" );
leaderData36 = new Array( "47", "44", "43", "43", "41", "39", "38", "38", "37", "37" );

leaderName37 = new Array( "J.Benoit", "F.Cordero", "F.Rodriguez", "J.Valverde", "M.Capps", "J.Broxton", "J.Axford", "N.Masset", "J.Putz", "C.Marmol" );
leaderTeam37 = new Array( "HON", "SFN", "NYN", "SDN", "PIN", "CIN", "LAN", "CIN", "ATN", "CHN" );
leaderData37 = new Array( "35", "34", "32", "31", "26", "24", "24", "23", "22", "18" );

leaderName38 = new Array( "J.Benoit", "J.Broxton", "M.Capps", "D.Storen", "R.Franklin", "J.Valverde", "J.Putz", "F.Rodriguez", "N.Masset", "J.Axford" );
leaderTeam38 = new Array( "HON", "CIN", "PIN", "WAN", "SLN", "SDN", "ATN", "NYN", "CIN", "LAN" );
leaderData38 = new Array( ".972", ".960", ".897", ".895", ".889", ".886", ".846", ".842", ".821", ".800" );

leaderName39 = new Array( "A.Wainwright", "T.Hudson", "T.Gorzelanny", "R.Wells", "C.Carpenter", "K.Medlen", "J.Tomlin", "J.Bonderman", "J.Cueto", "J.Chacin" );
leaderTeam39 = new Array( "SLN", "ATN", "***", "CHN", "LAN", "ATN", "***", "CIN", "CIN", "HON" );
leaderData39 = new Array( "4", "2", "2", "2", "2", "1", "1", "1", "1", "1" );

leaderName40 = new Array( "R.Dempster", "M.Pelfrey", "T.Hudson", "C.Carpenter", "E.Jackson", "J.Saunders", "D.Lowe", "P.Maholm", "J.Niese", "J.Westbrook" );
leaderTeam40 = new Array( "CHN", "***", "ATN", "LAN", "SDN", "WAN", "NYN", "PIN", "PIN", "NYN" );
leaderData40 = new Array( "240", "226", "216", "216", "215", "215", "214", "210", "210", "209" );

leaderName41 = new Array( "E.Santana", "R.Dempster", "J.Niese", "A.Burnett", "Z.Duke", "R.Wells", "M.Pelfrey", "P.Maholm", "E.Jackson", "J.Westbrook" );
leaderTeam41 = new Array( "HON", "CHN", "PIN", "CHN", "PIN", "CHN", "***", "PIN", "SDN", "NYN" );
leaderData41 = new Array( "132", "124", "116", "115", "115", "113", "113", "112", "112", "110" );

leaderName42 = new Array( "R.Dempster", "Z.Duke", "E.Santana", "A.Burnett", "M.Pelfrey", "R.Wells", "J.Niese", "E.Jackson", "P.Maholm", "J.Westbrook" );
leaderTeam42 = new Array( "CHN", "PIN", "HON", "CHN", "***", "CHN", "PIN", "SDN", "PIN", "NYN" );
leaderData42 = new Array( "117", "112", "109", "108", "108", "106", "106", "105", "104", "99" );

leaderName43 = new Array( "R.Dempster", "E.Santana", "J.Bonderman", "T.Hudson", "K.Millwood", "J.Westbrook", "R.Oswalt", "C.Hamels", "I.Kennedy", "Z.Duke" );
leaderTeam43 = new Array( "CHN", "HON", "CIN", "ATN", "CIN", "NYN", "HON", "PHN", "PHN", "PIN" );
leaderData43 = new Array( "40", "35", "30", "29", "29", "29", "27", "27", "27", "27" );

leaderName44 = new Array( "R.Dempster", "C.Zambrano", "J.Sanchez", "D.Price", "E.Jackson", "C.Hamels", "C.Narveson", "R.Wells", "B.Zito", "A.Burnett" );
leaderTeam44 = new Array( "CHN", "***", "SFN", "HON", "SDN", "PHN", "ATN", "CHN", "SFN", "CHN" );
leaderData44 = new Array( "107", "95", "95", "94", "90", "88", "86", "84", "83", "82" );

leaderName45 = new Array( "C.Kershaw", "R.Oswalt", "R.Dempster", "A.Wainwright", "C.Hamels", "T.Lincecum", "C.Lee", "C.Carpenter", "Y.Gallardo", "E.Jackson" );
leaderTeam45 = new Array( "LAN", "HON", "CHN", "SLN", "PHN", "SFN", "PHN", "LAN", "HON", "SDN" );
leaderData45 = new Array( "225", "223", "213", "213", "202", "200", "186", "185", "184", "182" );

leaderName46 = new Array( "A.Burnett", "A.Harang", "H.Kuroda", "E.Jackson", "I.Kennedy", "J.Sanchez", "T.Lincecum", "E.Santana", "B.Zito", "R.Rowland-Smith" );
leaderTeam46 = new Array( "CHN", "CHN", "LAN", "SDN", "PHN", "SFN", "SFN", "HON", "SFN", "CHN" );
leaderData46 = new Array( "15", "13", "13", "13", "12", "12", "11", "10", "10", "9" );

leaderName47 = new Array( "D.Price", "J.Cueto", "R.Oswalt", "Z.Duke", "C.Kershaw", "D.Lowe", "J.Garcia", "N.Robertson", "K.Medlen", "T.Wood" );
leaderTeam47 = new Array( "HON", "CIN", "HON", "PIN", "LAN", "NYN", "SLN", "***", "ATN", "CIN" );
leaderData47 = new Array( "6", "4", "4", "4", "3", "3", "3", "3", "2", "2" );

leaderName48 = new Array( "K.Millwood", "D.Price", "T.Lincecum", "B.Arroyo", "L.Hernandez", "T.Hudson", "R.Dempster", "Y.Gallardo", "C.Kershaw", "I.Kennedy" );
leaderTeam48 = new Array( "CIN", "HON", "SFN", "SLN", "SLN", "ATN", "CHN", "HON", "LAN", "PHN" );
leaderData48 = new Array( "1.00", "1.00", "1.00", "1.00", "1.00", ".88", ".88", ".88", ".88", ".88" );

leaderName49 = new Array( "T.Hanson", "E.Santana", "T.Lincecum", "A.Burnett", "J.Lannan", "J.Westbrook", "R.Wells", "S.O'Sullivan", "J.Moyer", "R.Dempster" );
leaderTeam49 = new Array( "ATN", "HON", "SFN", "CHN", "WAN", "NYN", "CHN", "***", "PHN", "CHN" );
leaderData49 = new Array( "38", "36", "34", "32", "31", "25", "24", "23", "22", "21" );

leaderName50 = new Array( "E.Jackson", "T.Lincecum", "T.Gorzelanny", "C.Hamels", "J.Lannan", "D.Bush", "A.Burnett", "R.Wells", "R.Dempster", "J.Westbrook" );
leaderTeam50 = new Array( "SDN", "SFN", "***", "PHN", "WAN", "SFN", "CHN", "CHN", "CHN", "NYN" );
leaderData50 = new Array( ".68", ".69", ".70", ".73", ".74", ".74", ".74", ".75", ".78", ".78" );

leaderName51 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderTeam51 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderData51 = new Array( "", "", "", "", "", "", "", "", "", "" );

leaderName52 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderTeam52 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderData52 = new Array( "", "", "", "", "", "", "", "", "", "" );

leaderName53 = new Array( "R.Oswalt", "C.Kershaw", "A.Wainwright", "J.Sanchez", "B.Arroyo", "M.Cain", "I.Kennedy", "C.Hamels", "J.Garcia", "C.Carpenter" );
leaderTeam53 = new Array( "HON", "LAN", "SLN", "SFN", "SLN", "SFN", "PHN", "PHN", "SLN", "LAN" );
leaderData53 = new Array( " 6.2", " 6.4", " 6.5", " 6.7", " 6.7", " 6.8", " 7.4", " 7.5", " 7.7", " 8.0" );

leaderName54 = new Array( "R.Dickey", "C.Lee", "H.Kuroda", "J.Saunders", "J.Cueto", "A.Wainwright", "M.Cain", "T.Lincecum", "T.Hudson", "D.Lowe" );
leaderTeam54 = new Array( "NYN", "PHN", "LAN", "WAN", "CIN", "SLN", "SFN", "SFN", "ATN", "NYN" );
leaderData54 = new Array( " 1.9", " 2.2", " 2.4", " 2.5", " 2.5", " 2.6", " 2.6", " 2.7", " 2.8", " 2.8" );

leaderName55 = new Array( "C.Kershaw", "J.Sanchez", "T.Lincecum", "R.Oswalt", "Y.Gallardo", "R.Dempster", "A.Wainwright", "C.Hamels", "M.Cain", "C.Billingsley" );
leaderTeam55 = new Array( "LAN", "SFN", "SFN", "HON", "HON", "CHN", "SLN", "PHN", "SFN", "LAN" );
leaderData55 = new Array( " 9.9", " 9.9", " 9.4", " 9.2", " 8.9", " 8.5", " 8.4", " 8.4", " 8.3", " 8.0" );

leaderName56 = new Array( "C.Billingsley", "J.Garcia", "L.Hernandez", "A.Wainwright", "E.Jackson", "C.Carpenter", "C.Kershaw", "T.Hanson", "Y.Gallardo", "D.Price" );
leaderTeam56 = new Array( "LAN", "SLN", "SLN", "SLN", "SDN", "LAN", "LAN", "ATN", "HON", "HON" );
leaderData56 = new Array( " 0.42", " 0.54", " 0.70", " 0.71", " 0.71", " 0.74", " 0.79", " 0.91", " 0.91", " 0.91" );

