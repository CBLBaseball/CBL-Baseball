sub = new Array( "AL", "NL" );
sublong = new Array( "American League", "National League" );

AL = new Array( "ALEast", "ALCentral", "ALWest" );
NL = new Array( "NLEast", "NLCentral", "NLWest" );

ALALEast = new Array( "BAA", "BOA", "NYA", "TOA" );

BAA = new Array("ALEast", "Baltimore", "Orioles", "Baltimore Orioles (BAA)", "2011", "162", "92", "70", ".568", ".568", ".568" );
BOA = new Array("ALEast", "Boston", "Red Sox", "Boston Red Sox (BOA)", "2011", "162", "69", "93", ".426", ".457", ".395" );
NYA = new Array("ALEast", "New York (AL)", "Yankees", "New York (AL) Yankees (NYA)", "2011", "162", "84", "78", ".519", ".593", ".444" );
TOA = new Array("ALEast", "Toronto", "Blue Jays", "Toronto Blue Jays (TOA)", "2011", "162", "80", "82", ".494", ".457", ".531" );
ALALCentral = new Array( "CHA", "CLA", "DEA", "MNA" );

CHA = new Array("ALCentral", "Chicago (AL)", "White Sox", "Chicago (AL) White Sox (CHA)", "2011", "162", "76", "86", ".469", ".407", ".531" );
CLA = new Array("ALCentral", "Cleveland", "Indians", "Cleveland Indians (CLA)", "2011", "162", "70", "92", ".432", ".457", ".407" );
DEA = new Array("ALCentral", "Detroit", "Tigers", "Detroit Tigers (DEA)", "2011", "162", "64", "98", ".395", ".407", ".383" );
MNA = new Array("ALCentral", "Minnesota", "Twins", "Minnesota Twins (MNA)", "2011", "162", "89", "73", ".549", ".457", ".642" );
ALALWest = new Array( "KCA", "LAA", "OAA", "SEA" );

KCA = new Array("ALWest", "Kansas City", "Royals", "Kansas City Royals (KCA)", "2011", "162", "74", "88", ".457", ".432", ".481" );
LAA = new Array("ALWest", "Los Angeles(AL)", "Angels", "Los Angeles(AL) Angels (LAA)", "2011", "162", "82", "80", ".506", ".395", ".617" );
OAA = new Array("ALWest", "Oakland", "Athletics", "Oakland Athletics (OAA)", "2011", "162", "102", "60", ".630", ".593", ".667" );
SEA = new Array("ALWest", "Seattle", "Mariners", "Seattle Mariners (SEA)", "2011", "162", "91", "71", ".562", ".457", ".667" );
NLNLEast = new Array( "ATN", "NYN", "PHN", "WAN" );

ATN = new Array("NLEast", "Atlanta", "Braves", "Atlanta Braves (ATN)", "2011", "162", "81", "81", ".500", ".519", ".481" );
NYN = new Array("NLEast", "New York (NL)", "Mets", "New York (NL) Mets (NYN)", "2011", "162", "96", "66", ".593", ".531", ".654" );
PHN = new Array("NLEast", "Philadelphia", "Phillies", "Philadelphia Phillies (PHN)", "2011", "162", "95", "67", ".586", ".556", ".617" );
WAN = new Array("NLEast", "Washington", "Nationals", "Washington Nationals (WAN)", "2011", "162", "76", "86", ".469", ".457", ".481" );
NLNLCentral = new Array( "CHN", "CIN", "PIN", "SLN" );

CHN = new Array("NLCentral", "Chicago (NL)", "Cubs", "Chicago (NL) Cubs (CHN)", "2011", "162", "56", "106", ".346", ".395", ".296" );
CIN = new Array("NLCentral", "Cincinnati", "Reds", "Cincinnati Reds (CIN)", "2011", "162", "87", "75", ".537", ".395", ".679" );
PIN = new Array("NLCentral", "Pittsburgh", "Pirates", "Pittsburgh Pirates (PIN)", "2011", "162", "59", "103", ".364", ".370", ".358" );
SLN = new Array("NLCentral", "St. Louis", "Cardinals", "St. Louis Cardinals (SLN)", "2011", "162", "94", "68", ".580", ".580", ".580" );
NLNLWest = new Array( "HON", "LAN", "SDN", "SFN" );

HON = new Array("NLWest", "Houston", "Astros", "Houston Astros (HON)", "2011", "162", "87", "75", ".537", ".580", ".494" );
LAN = new Array("NLWest", "Los Angeles(NL)", "Dodgers", "Los Angeles(NL) Dodgers (LAN)", "2011", "162", "86", "76", ".531", ".469", ".593" );
SDN = new Array("NLWest", "San Diego", "Padres", "San Diego Padres (SDN)", "2011", "162", "88", "74", ".543", ".556", ".531" );
SFN = new Array("NLWest", "San Francisco", "Giants", "San Francisco Giants (SFN)", "2011", "162", "66", "96", ".407", ".383", ".432" );
