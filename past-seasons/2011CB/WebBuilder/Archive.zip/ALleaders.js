leaderName0 = new Array( "C.Crawford", "R.Braun", "C.Gonzalez", "R.Cano", "M.Prado", "B.Butler", "M.Young", "A.Gonzalez", "V.Guerrero", "J.Mauer" );
leaderTeam0 = new Array( "SEA", "CHA", "OAA", "NYA", "OAA", "KCA", "MNA", "BAA", "BAA", "MNA" );
leaderData0 = new Array( ".329", ".325", ".321", ".316", ".314", ".312", ".311", ".308", ".305", ".301" );

leaderName1 = new Array( "I.Suzuki", "M.Young", "R.Cano", "N.Markakis", "R.Braun", "D.Jeter", "R.Weeks", "A.Gonzalez", "C.McGehee", "D.Uggla" );
leaderTeam1 = new Array( "SEA", "MNA", "NYA", "BAA", "CHA", "NYA", "MNA", "BOA", "NYA", "LAA" );
leaderData1 = new Array( "676", "663", "643", "642", "637", "627", "626", "618", "618", "613" );

leaderName2 = new Array( "R.Braun", "R.Cano", "A.Huff", "C.Gonzalez", "R.Weeks", "D.Uggla", "A.Torres", "N.Markakis", "A.Gonzalez", "I.Suzuki" );
leaderTeam2 = new Array( "CHA", "NYA", "CHA", "OAA", "MNA", "LAA", "OAA", "BAA", "BAA", "SEA" );
leaderData2 = new Array( "112", "106", "104", "103", "102", "101", "101", "100", "98", "96" );

leaderName3 = new Array( "R.Braun", "M.Young", "R.Cano", "C.Crawford", "C.Gonzalez", "I.Suzuki", "N.Markakis", "A.Gonzalez", "B.Butler", "C.McGehee" );
leaderTeam3 = new Array( "CHA", "MNA", "NYA", "SEA", "OAA", "SEA", "BAA", "BAA", "KCA", "NYA" );
leaderData3 = new Array( "207", "206", "203", "199", "193", "193", "189", "183", "179", "171" );

leaderName4 = new Array( "B.Butler", "R.Braun", "B.Abreu", "M.Prado", "C.Young", "A.Gonzalez", "R.Cano", "D.Barton", "A.Torres", "D.Young" );
leaderTeam4 = new Array( "KCA", "CHA", "NYA", "OAA", "BAA", "BOA", "NYA", "OAA", "OAA", "MNA" );
leaderData4 = new Array( "55", "50", "48", "43", "42", "42", "41", "41", "41", "39" );

leaderName5 = new Array( "S.Drew", "D.Span", "C.Granderson", "A.Jackson", "C.Gonzalez", "A.Torres", "W.Venable", "A.Escobar", "A.Pagan", "J.Damon" );
leaderTeam5 = new Array( "MNA", "MNA", "DEA", "DEA", "OAA", "OAA", "CHA", "DEA", "KCA", "NYA" );
leaderData5 = new Array( "12", "10", "9", "9", "9", "9", "8", "8", "8", "8" );

leaderName6 = new Array( "A.Gonzalez", "D.Ortiz", "C.Gonzalez", "M.Teixeira", "M.Reynolds", "P.Konerko", "D.Uggla", "V.Guerrero", "R.Weeks", "L.Scott" );
leaderTeam6 = new Array( "BAA", "BOA", "OAA", "NYA", "TOA", "CHA", "LAA", "BAA", "MNA", "BAA" );
leaderData6 = new Array( "39", "39", "39", "38", "37", "36", "36", "33", "32", "31" );

leaderName7 = new Array( "P.Konerko", "C.Gonzalez", "C.Crawford", "B.Abreu", "A.Gonzalez", "M.Teixeira", "A.Rodriguez", "D.Young", "D.Uggla", "R.Weeks" );
leaderTeam7 = new Array( "CHA", "OAA", "SEA", "NYA", "BAA", "NYA", "SEA", "MNA", "LAA", "MNA" );
leaderData7 = new Array( "121", "113", "112", "111", "110", "109", "109", "103", "102", "100" );

leaderName8 = new Array( "D.Barton", "A.Huff", "M.Teixeira", "D.Uggla", "R.Weeks", "B.Abreu", "L.Berkman", "S.Choo", "P.Konerko", "D.Ortiz" );
leaderTeam8 = new Array( "OAA", "CHA", "NYA", "LAA", "MNA", "NYA", "SEA", "CLA", "CHA", "BOA" );
leaderData8 = new Array( "126", "87", "87", "86", "81", "76", "74", "73", "72", "71" );

leaderName9 = new Array( "C.Crawford", "D.Young", "B.Butler", "J.Mauer", "R.Cano", "C.Gonzalez", "A.Pagan", "J.Pierre", "A.Gonzalez", "M.Cuddyer" );
leaderTeam9 = new Array( "SEA", "MNA", "KCA", "MNA", "NYA", "OAA", "KCA", "KCA", "BAA", "MNA" );
leaderData9 = new Array( "20", "18", "15", "14", "14", "14", "12", "11", "9", "9" );

leaderName10 = new Array( "M.Reynolds", "R.Weeks", "A.Laroche", "A.Jackson", "D.Uggla", "N.Swisher", "C.Young", "B.Abreu", "D.Ortiz", "M.Teixeira" );
leaderTeam10 = new Array( "TOA", "MNA", "CLA", "DEA", "LAA", "OAA", "BAA", "NYA", "BOA", "NYA" );
leaderData10 = new Array( "194", "183", "173", "168", "161", "159", "153", "150", "142", "142" );

leaderName11 = new Array( "J.Pierre", "R.Weeks", "M.Teixeira", "J.Wilson*", "K.Youkilis", "J.Kendall", "A.Huff", "H.Ramirez", "J.Guillen", "S.Rodriguez" );
leaderTeam11 = new Array( "KCA", "MNA", "NYA", "CLA", "BOA", "KCA", "CHA", "LAA", "BOA", "CHA" );
leaderData11 = new Array( "27", "25", "17", "16", "15", "13", "12", "11", "10", "10" );

leaderName12 = new Array( "J.Pierre", "G.Blanco", "A.Pagan", "B.Ryan", "J.Kendall", "W.Valdez", "D.Eckstein", "A.Jackson", "I.Suzuki", "O.Cabrera" );
leaderTeam12 = new Array( "KCA", "KCA", "KCA", "***", "KCA", "SEA", "***", "DEA", "SEA", "KCA" );
leaderData12 = new Array( "50", "33", "26", "23", "22", "22", "18", "17", "16", "15" );

leaderName13 = new Array( "J.Pierre", "C.Crawford", "I.Suzuki", "A.Pagan", "R.Davis", "A.Jackson", "C.Figgins", "A.Torres", "C.Gonzalez", "B.Gardner" );
leaderTeam13 = new Array( "KCA", "SEA", "SEA", "KCA", "MNA", "DEA", "LAA", "OAA", "OAA", "NYA" );
leaderData13 = new Array( "98", "69", "61", "52", "50", "44", "41", "41", "36", "35" );

leaderName14 = new Array( "B.Gardner", "A.Rios", "H.Ramirez", "N.Morgan", "A.Torres", "I.Suzuki", "C.Crawford", "W.Venable", "C.Pennington", "F.Gutierrez" );
leaderTeam14 = new Array( "NYA", "TOA", "LAA", "OAA", "OAA", "SEA", "SEA", "CHA", "OAA", "SEA" );
leaderData14 = new Array( ".90", ".89", ".86", ".82", ".82", ".81", ".81", ".81", ".81", ".81" );

leaderName15 = new Array( "D.Jeter", "C.McGehee", "V.Guerrero", "T.Hunter", "R.Cano", "N.Markakis", "A.Huff", "A.Gonzalez", "R.Braun", "A.Gonzalez" );
leaderTeam15 = new Array( "NYA", "NYA", "BAA", "LAA", "NYA", "BAA", "CHA", "BAA", "CHA", "BOA" );
leaderData15 = new Array( "32", "32", "30", "27", "26", "24", "23", "21", "21", "20" );

leaderName16 = new Array( "A.Cabrera", "S.Drew", "A.Jones", "M.Aviles", "G.Blum", "J.Morneau", "I.Suzuki", "J.Loney", "T.Hunter", "M.Tejada" );
leaderTeam16 = new Array( "CLA", "MNA", "SEA", "TOA", "TOA", "MNA", "SEA", "TOA", "LAA", "TOA" );
leaderData16 = new Array( "10", "8", "8", "7", "7", "6", "6", "6", "5", "5" );

leaderName17 = new Array( "M.Fontenot", "S.Rodriguez", "J.Smoak", "M.Bradley", "", "", "", "", "", "" );
leaderTeam17 = new Array( "CHA", "CHA", "SEA", "SEA", "", "", "", "", "", "" );
leaderData17 = new Array( ".364", ".238", ".238", ".200", "0", "0", "0", "0", "0", "0" );

leaderName18 = new Array( "C.Gonzalez", "D.Ortiz", "R.Braun", "A.Gonzalez", "P.Konerko", "V.Guerrero", "C.Crawford", "R.Cano", "D.Uggla", "A.Huff" );
leaderTeam18 = new Array( "OAA", "BOA", "CHA", "BAA", "CHA", "BAA", "SEA", "NYA", "LAA", "CHA" );
leaderData18 = new Array( ".610", ".596", ".551", ".542", ".541", ".535", ".533", ".515", ".512", ".508" );

leaderName19 = new Array( "C.Crawford", "A.Huff", "D.Barton", "R.Braun", "B.Butler", "R.Cano", "D.Ortiz", "A.Gonzalez", "J.Mauer", "C.Gonzalez" );
leaderTeam19 = new Array( "SEA", "CHA", "OAA", "CHA", "KCA", "NYA", "BOA", "BAA", "MNA", "OAA" );
leaderData19 = new Array( ".394", ".387", ".385", ".384", ".382", ".381", ".378", ".376", ".370", ".370" );

leaderName20 = new Array( "D.Ortiz", "C.Crawford", "C.Gonzalez", "R.Braun", "A.Gonzalez", "P.Konerko", "A.Huff", "R.Cano", "B.Butler", "A.Torres" );
leaderTeam20 = new Array( "BOA", "SEA", "OAA", "CHA", "BAA", "CHA", "CHA", "NYA", "KCA", "OAA" );
leaderData20 = new Array( " 8.4", " 8.2", " 8.2", " 7.7", " 7.2", " 7.0", " 7.0", " 6.9", " 6.7", " 6.6" );

leaderName21 = new Array( "C.Crawford", "C.Gonzalez", "D.Ortiz", "R.Braun", "A.Torres", "P.Konerko", "A.Gonzalez", "A.Huff", "D.Uggla", "R.Cano" );
leaderTeam21 = new Array( "SEA", "OAA", "BOA", "CHA", "OAA", "CHA", "BAA", "CHA", "LAA", "NYA" );
leaderData21 = new Array( "1.075", "1.048", "1.022", ".941", ".932", ".905", ".905", ".900", ".873", ".867" );

leaderName22 = new Array( "C.Gonzalez", "R.Braun", "R.Cano", "A.Gonzalez", "C.Crawford", "D.Uggla", "P.Konerko", "D.Ortiz", "A.Huff", "R.Weeks" );
leaderTeam22 = new Array( "OAA", "CHA", "NYA", "BAA", "SEA", "LAA", "CHA", "BOA", "CHA", "MNA" );
leaderData22 = new Array( "367", "351", "331", "322", "322", "314", "307", "301", "297", "295" );

leaderName23 = new Array( "A.Gonzalez", "M.Ordonez", "N.Markakis", "V.Guerrero", "I.Kinsler", "M.Young", "W.Betemit", "C.Crisp", "D.Freese", "J.Buck" );
leaderTeam23 = new Array( "BAA", "DEA", "BAA", "BAA", "TOA", "MNA", "KCA", "NYA", "***", "TOA" );
leaderData23 = new Array( ".422", ".385", ".378", ".376", ".364", ".355", ".352", ".348", ".347", ".345" );

leaderName24 = new Array( "D.Young", "M.Ordonez", "M.Teixeira", "M.Morse", "M.Reynolds", "V.Guerrero", "D.Uggla", "H.Matsui", "K.Youkilis", "M.Napoli" );
leaderTeam24 = new Array( "MNA", "DEA", "NYA", "BOA", "TOA", "BAA", "LAA", "NYA", "BOA", "LAA" );
leaderData24 = new Array( "16", "14", "13", "12", "12", "11", "11", "11", "10", "10" );

leaderName25 = new Array( "D.Dejesus", "C.Crawford", "Y.Torrealba", "R.Cano", "J.Mauer", "L.Scott", "C.Gonzalez", "R.Braun", "B.Butler", "A.Jones" );
leaderTeam25 = new Array( "KCA", "SEA", "SEA", "NYA", "MNA", "BAA", "OAA", "CHA", "KCA", "SEA" );
leaderData25 = new Array( ".354", ".351", ".345", ".340", ".335", ".331", ".330", ".326", ".323", ".319" );

leaderName26 = new Array( "D.Ortiz", "A.Gonzalez", "M.Thames", "C.Gonzalez", "L.Scott", "P.Konerko", "C.Granderson", "D.Uggla", "M.Teixeira", "M.Reynolds" );
leaderTeam26 = new Array( "BOA", "BAA", "NYA", "OAA", "BAA", "CHA", "DEA", "LAA", "NYA", "TOA" );
leaderData26 = new Array( "38", "34", "30", "29", "28", "27", "26", "25", "25", "25" );

leaderName27 = new Array( "F.Hernandez", "D.Haren", "J.Danks", "A.Sanchez", "F.Liriano", "G.Gonzalez", "M.Scherzer", "U.Jimenez", "C.Sabathia", "C.Wilson" );
leaderTeam27 = new Array( "SEA", "OAA", "CHA", "LAA", "MNA", "OAA", "TOA", "BAA", "CLA", "CLA" );
leaderData27 = new Array( "20", "19", "15", "15", "15", "15", "15", "14", "14", "14" );

leaderName28 = new Array( "F.Carmona", "J.Santana", "C.Sabathia", "R.Porcello", "C.Lewis", "R.Romero", "C.Richard", "B.Myers", "C.Pavano", "R.Halladay" );
leaderTeam28 = new Array( "***", "***", "CLA", "DEA", "CHA", "CLA", "DEA", "KCA", "MNA", "TOA" );
leaderData28 = new Array( "18", "18", "17", "16", "15", "15", "15", "15", "14", "14" );

leaderName29 = new Array( "J.Arrieta", "D.Haren", "F.Liriano", "U.Jimenez", "B.Duensing", "J.Shields", "P.Hughes", "F.Hernandez", "G.Gonzalez", "M.Scherzer" );
leaderTeam29 = new Array( "BAA", "OAA", "MNA", "BAA", "MNA", "MNA", "NYA", "SEA", "OAA", "TOA" );
leaderData29 = new Array( ".750", ".704", ".682", ".667", ".667", ".667", ".667", ".667", ".652", ".652" );

leaderName30 = new Array( "F.Hernandez", "J.Verlander", "T.Cahill", "J.Weaver", "J.Johnson", "T.Lilly", "D.Braden", "J.Danks", "F.Liriano", "M.Scherzer" );
leaderTeam30 = new Array( "SEA", "DEA", "OAA", "LAA", "CHA", "***", "OAA", "CHA", "MNA", "TOA" );
leaderData30 = new Array( " 2.39", " 2.63", " 2.83", " 3.09", " 3.10", " 3.17", " 3.21", " 3.51", " 3.55", " 3.56" );

leaderName31 = new Array( "R.Halladay", "C.Sabathia", "F.Hernandez", "D.Haren", "J.Weaver", "J.Verlander", "B.Myers", "Z.Greinke", "F.Carmona", "U.Jimenez" );
leaderTeam31 = new Array( "TOA", "CLA", "SEA", "OAA", "LAA", "DEA", "KCA", "KCA", "***", "BAA" );
leaderData31 = new Array( "250.1", "249.1", "249.0", "233.2", "233.1", "229.2", "227.2", "222.1", "222.0", "221.1" );

leaderName32 = new Array( "C.Sabathia", "R.Halladay", "F.Hernandez", "D.Haren", "J.Lackey", "F.Carmona", "J.Weaver", "U.Jimenez", "B.Myers", "Z.Greinke" );
leaderTeam32 = new Array( "CLA", "TOA", "SEA", "OAA", "LAA", "***", "LAA", "BAA", "KCA", "KCA" );
leaderData32 = new Array( "1058", "1037", "1010", "961", "957", "954", "953", "949", "946", "941" );

leaderName33 = new Array( "D.Oliver", "N.Feliz", "E.Meek", "B.Thomas", "J.Chamberlain", "J.Papelbon", "J.Soria", "H.Bell", "B.Duensing", "J.Crain" );
leaderTeam33 = new Array( "***", "BAA", "BAA", "DEA", "NYA", "BOA", "KCA", "MNA", "MNA", "NYA" );
leaderData33 = new Array( "66", "61", "61", "59", "58", "55", "54", "54", "54", "54" );

leaderName34 = new Array( "D.Haren", "F.Hernandez", "U.Jimenez", "M.Buehrle", "F.Carmona", "C.Sabathia", "Z.Greinke", "B.Myers", "R.Halladay", "M.Garza" );
leaderTeam34 = new Array( "OAA", "SEA", "BAA", "CHA", "***", "CLA", "KCA", "KCA", "TOA", "BAA" );
leaderData34 = new Array( "34", "34", "33", "33", "33", "33", "33", "33", "33", "32" );

leaderName35 = new Array( "C.Sabathia", "R.Halladay", "F.Hernandez", "F.Liriano", "J.Johnson", "J.Santana", "B.Myers", "T.Cahill", "J.Danks", "J.Weaver" );
leaderTeam35 = new Array( "CLA", "TOA", "SEA", "MNA", "CHA", "***", "KCA", "OAA", "CHA", "LAA" );
leaderData35 = new Array( "17", "12", "11", "10", "9", "9", "9", "9", "8", "8" );

leaderName36 = new Array( "N.Feliz", "J.Soria", "J.Papelbon", "H.Bell", "C.Perez", "B.Wilson", "B.Fuentes", "N.Figueroa", "V.Mazzaro", "M.Rivera" );
leaderTeam36 = new Array( "BAA", "KCA", "BOA", "MNA", "CLA", "TOA", "LAA", "LAA", "SEA", "NYA" );
leaderData36 = new Array( "50", "46", "45", "43", "38", "37", "34", "32", "32", "31" );

leaderName37 = new Array( "J.Papelbon", "N.Feliz", "H.Bell", "J.Soria", "B.Wilson", "C.Perez", "B.Fuentes", "A.Bailey", "R.Soriano", "D.Aardsma" );
leaderTeam37 = new Array( "BOA", "BAA", "MNA", "KCA", "TOA", "CLA", "LAA", "OAA", "DEA", "SEA" );
leaderData37 = new Array( "37", "35", "32", "29", "27", "26", "25", "24", "22", "20" );

leaderName38 = new Array( "A.Bailey", "C.Perez", "H.Street", "N.Feliz", "J.Papelbon", "J.Soria", "B.Wilson", "B.Fuentes", "D.Aardsma", "H.Bell" );
leaderTeam38 = new Array( "OAA", "CLA", "OAA", "BAA", "BOA", "KCA", "TOA", "LAA", "SEA", "MNA" );
leaderData38 = new Array( ".960", ".929", ".900", ".854", ".841", ".829", ".794", ".781", ".769", ".762" );

leaderName39 = new Array( "C.Sabathia", "T.Cahill", "U.Jimenez", "G.Gonzalez", "F.Hernandez", "R.Halladay", "M.Garza", "D.Matsuzaka", "J.Danks", "Z.Greinke" );
leaderTeam39 = new Array( "CLA", "OAA", "BAA", "OAA", "SEA", "TOA", "BAA", "BOA", "CHA", "KCA" );
leaderData39 = new Array( "4", "4", "3", "3", "3", "3", "2", "2", "2", "2" );

leaderName40 = new Array( "R.Halladay", "M.Buehrle", "C.Pavano", "C.Sabathia", "J.Lackey", "F.Carmona", "J.Shields", "J.Lester", "C.Richard", "J.Garland" );
leaderTeam40 = new Array( "TOA", "CHA", "MNA", "CLA", "LAA", "***", "MNA", "BOA", "DEA", "LAA" );
leaderData40 = new Array( "268", "250", "246", "239", "239", "237", "235", "232", "225", "224" );

leaderName41 = new Array( "C.Lewis", "J.Lester", "C.Richard", "J.Lackey", "R.Romero", "C.Sabathia", "M.Garza", "F.Carmona", "C.Pavano", "M.Buehrle" );
leaderTeam41 = new Array( "CHA", "BOA", "DEA", "LAA", "CLA", "CLA", "BAA", "***", "MNA", "CHA" );
leaderData41 = new Array( "136", "126", "126", "124", "121", "117", "116", "115", "114", "113" );

leaderName42 = new Array( "C.Lewis", "C.Richard", "J.Lackey", "R.Romero", "C.Sabathia", "J.Lester", "C.Pavano", "M.Garza", "R.Halladay", "M.Buehrle" );
leaderTeam42 = new Array( "CHA", "DEA", "LAA", "CLA", "CLA", "BOA", "MNA", "BAA", "TOA", "CHA" );
leaderData42 = new Array( "124", "123", "115", "113", "111", "108", "107", "106", "105", "104" );

leaderName43 = new Array( "M.Garza", "S.Marcum", "B.Enright", "C.Lewis", "C.Richard", "R.Nolasco", "B.Matusz", "R.Porcello", "P.Hughes", "A.Pettitte" );
leaderTeam43 = new Array( "BAA", "TOA", "DEA", "CHA", "DEA", "NYA", "BAA", "DEA", "NYA", "NYA" );
leaderData43 = new Array( "40", "33", "32", "30", "29", "27", "26", "26", "26", "26" );

leaderName44 = new Array( "C.Wilson", "G.Gonzalez", "R.Romero", "J.Lackey", "A.Sanchez", "C.Richard", "C.Sabathia", "K.Davies", "U.Jimenez", "J.Lester" );
leaderTeam44 = new Array( "CLA", "OAA", "CLA", "LAA", "LAA", "DEA", "CLA", "KCA", "BAA", "BOA" );
leaderData44 = new Array( "107", "105", "92", "90", "89", "87", "86", "85", "84", "84" );

leaderName45 = new Array( "F.Hernandez", "J.Verlander", "F.Liriano", "J.Weaver", "D.Haren", "U.Jimenez", "J.Lester", "Z.Greinke", "C.Sabathia", "C.Lewis" );
leaderTeam45 = new Array( "SEA", "DEA", "MNA", "LAA", "OAA", "BAA", "BOA", "KCA", "CLA", "CHA" );
leaderData45 = new Array( "240", "226", "224", "221", "206", "204", "201", "195", "194", "192" );

leaderName46 = new Array( "R.Romero", "F.Hernandez", "U.Jimenez", "C.Lewis", "F.Liriano", "C.Sabathia", "R.Porcello", "T.Pena", "R.Perez", "J.Lester" );
leaderTeam46 = new Array( "CLA", "SEA", "BAA", "CHA", "MNA", "CLA", "DEA", "CHA", "BAA", "BOA" );
leaderData46 = new Array( "20", "19", "15", "15", "15", "14", "14", "12", "11", "11" );

leaderName47 = new Array( "T.Cahill", "U.Jimenez", "B.Fuentes", "B.Moehler", "G.Gonzalez", "B.Hawksworth", "J.Vargas", "M.Buehrle", "A.Galarraga", "R.Porcello" );
leaderTeam47 = new Array( "OAA", "BAA", "LAA", "***", "OAA", "OAA", "OAA", "CHA", "DEA", "DEA" );
leaderData47 = new Array( "5", "4", "4", "4", "4", "4", "4", "3", "3", "3" );

leaderName48 = new Array( "M.Buehrle", "J.Danks", "C.Richard", "K.Davies", "T.Cahill", "S.Marcum", "P.Hughes", "J.Garland", "T.Lilly", "W.Rodriguez" );
leaderTeam48 = new Array( "CHA", "CHA", "DEA", "KCA", "OAA", "TOA", "NYA", "LAA", "***", "LAA" );
leaderData48 = new Array( "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", ".90", ".86", ".80", ".80" );

leaderName49 = new Array( "F.Carmona", "T.Lilly", "J.Lackey", "J.Hammel", "J.Verlander", "C.Pavano", "J.Niemann", "D.Matsuzaka", "M.Scherzer", "B.Myers" );
leaderTeam49 = new Array( "***", "***", "LAA", "NYA", "DEA", "MNA", "TOA", "BOA", "TOA", "KCA" );
leaderData49 = new Array( "56", "40", "40", "40", "34", "34", "34", "29", "29", "27" );

leaderName50 = new Array( "A.Sanchez", "J.Wright", "J.Weaver", "R.Porcello", "D.Haren", "R.Halladay", "J.De La Rosa", "K.Davies", "B.Myers", "C.Volstad" );
leaderTeam50 = new Array( "LAA", "***", "LAA", "DEA", "OAA", "TOA", "***", "KCA", "KCA", "***" );
leaderData50 = new Array( ".42", ".59", ".63", ".67", ".70", ".70", ".71", ".72", ".73", ".74" );

leaderName51 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderTeam51 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderData51 = new Array( "", "", "", "", "", "", "", "", "", "" );

leaderName52 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderTeam52 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderData52 = new Array( "", "", "", "", "", "", "", "", "", "" );

leaderName53 = new Array( "T.Cahill", "F.Hernandez", "J.Verlander", "T.Lilly", "J.Johnson", "J.Danks", "C.Wilson", "P.Hughes", "G.Gonzalez", "C.Buchholz" );
leaderTeam53 = new Array( "OAA", "SEA", "DEA", "***", "CHA", "CHA", "CLA", "NYA", "OAA", "BOA" );
leaderData53 = new Array( " 6.6", " 7.1", " 7.1", " 7.6", " 7.7", " 7.7", " 8.0", " 8.0", " 8.1", " 8.2" );

leaderName54 = new Array( "R.Halladay", "D.Haren", "D.Braden", "S.Marcum", "M.Buehrle", "C.Pavano", "S.Baker", "J.Hammel", "J.Shields", "J.Weaver" );
leaderTeam54 = new Array( "TOA", "OAA", "OAA", "TOA", "CHA", "MNA", "MNA", "NYA", "MNA", "LAA" );
leaderData54 = new Array( " 1.6", " 1.7", " 2.0", " 2.1", " 2.2", " 2.2", " 2.3", " 2.3", " 2.3", " 2.4" );

leaderName55 = new Array( "F.Liriano", "J.Lester", "J.Verlander", "F.Hernandez", "J.Johnson", "M.Scherzer", "J.Weaver", "J.Shields", "U.Jimenez", "C.Lewis" );
leaderTeam55 = new Array( "MNA", "BOA", "DEA", "SEA", "CHA", "TOA", "LAA", "MNA", "BAA", "CHA" );
leaderData55 = new Array( "10.1", " 9.2", " 8.9", " 8.7", " 8.6", " 8.6", " 8.5", " 8.5", " 8.3", " 8.3" );

leaderName56 = new Array( "F.Liriano", "D.Braden", "C.Wilson", "D.Fister", "F.Hernandez", "J.Verlander", "C.Buchholz", "C.Pavano", "J.Lackey", "A.Sanchez" );
leaderTeam56 = new Array( "MNA", "OAA", "CLA", "SEA", "SEA", "DEA", "BOA", "MNA", "LAA", "LAA" );
leaderData56 = new Array( " 0.49", " 0.53", " 0.53", " 0.54", " 0.54", " 0.55", " 0.56", " 0.61", " 0.64", " 0.67" );

